/*
  # Fix compliance tasks profile relationship

  1. Database Changes
    - Add foreign key relationship between compliance_tasks and profiles tables
    - Update compliance_tasks to reference profiles.user_id instead of users.id directly
  
  2. Security
    - Maintain existing RLS policies
    - Ensure proper data access controls
*/

-- Add foreign key constraint if it doesn't exist
DO $$
BEGIN
  -- Check if the foreign key constraint already exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'compliance_tasks_user_id_profiles_fkey'
    AND table_name = 'compliance_tasks'
  ) THEN
    -- Add the foreign key constraint to link compliance_tasks.user_id to profiles.user_id
    ALTER TABLE compliance_tasks 
    ADD CONSTRAINT compliance_tasks_user_id_profiles_fkey 
    FOREIGN KEY (user_id) REFERENCES profiles(user_id) ON DELETE CASCADE;
  END IF;
END $$;