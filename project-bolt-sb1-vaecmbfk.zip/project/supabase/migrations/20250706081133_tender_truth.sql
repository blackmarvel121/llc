/*
  # Fix Payment Gateways Checkout Display

  1. Changes
    - Set all payment gateways to disabled by default
    - Add indexes for better performance
    - Ensure proper constraint for payment gateway types
    
  2. Security
    - Maintains existing RLS policies
*/

-- Ensure all gateways have proper enabled status
UPDATE payment_gateways
SET enabled = false
WHERE type IN ('stripe', 'razorpay', 'paypal');

-- Add an index on the type column for faster lookups if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'payment_gateways_type_idx'
  ) THEN
    CREATE INDEX payment_gateways_type_idx ON payment_gateways(type);
  END IF;
END $$;

-- Add an index on the enabled column for faster filtering if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'payment_gateways_enabled_idx'
  ) THEN
    CREATE INDEX payment_gateways_enabled_idx ON payment_gateways(enabled);
  END IF;
END $$;

-- Update the type check constraint to include all payment types if needed
DO $$
BEGIN
  -- Check if the constraint needs to be updated
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'payment_gateways_type_check' 
    AND conrelid = 'payment_gateways'::regclass
    AND pg_get_constraintdef(oid) LIKE '%paypal%'
  ) THEN
    -- Alter the constraint to include all payment types
    ALTER TABLE payment_gateways DROP CONSTRAINT IF EXISTS payment_gateways_type_check;
    ALTER TABLE payment_gateways ADD CONSTRAINT payment_gateways_type_check 
      CHECK (type IN ('stripe', 'razorpay', 'paypal', 'square'));
  END IF;
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Error updating constraint: %', SQLERRM;
END $$;