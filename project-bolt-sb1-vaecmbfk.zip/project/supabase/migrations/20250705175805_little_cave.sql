/*
  # Fix Database Relationships and Settings

  1. Changes
    - Create a single global settings record that contains all settings
    - Fix foreign key relationships between tables
    - Add missing constraints for affiliate_links and compliance_tasks
    - Ensure proper relationships between profiles and other tables

  2. Security
    - Maintains existing RLS policies
    - Ensures data consistency across tables
*/

-- First, consolidate all settings into a single global record
-- This fixes the issue with settings being spread across multiple records
INSERT INTO settings (
  key, 
  announcement_enabled, 
  announcement_text, 
  whatsapp_enabled, 
  whatsapp_number, 
  whatsapp_message,
  popup_enabled,
  popup_title,
  popup_subtitle,
  popup_offer_text,
  popup_cta_text,
  popup_disclaimer
)
VALUES (
  'global',
  true,
  '✅ 24-Hour LLC Guarantee by Razorfile',
  true,
  '+1234567890',
  'Hi! I need help with LLC formation.',
  false,
  '🔥 Last Chance: Professional LLC Formation',
  'Don''t miss out! Get your LLC formed professionally when you start today. This exclusive offer expires soon!',
  'Professional LLC Formation Service',
  '🚀 Start My LLC Now - Only $49',
  '* Limited time offer. Offer valid for new customers only.'
)
ON CONFLICT (key) DO UPDATE SET
  announcement_enabled = EXCLUDED.announcement_enabled,
  announcement_text = EXCLUDED.announcement_text,
  whatsapp_enabled = EXCLUDED.whatsapp_enabled,
  whatsapp_number = EXCLUDED.whatsapp_number,
  whatsapp_message = EXCLUDED.whatsapp_message,
  popup_enabled = EXCLUDED.popup_enabled,
  popup_title = EXCLUDED.popup_title,
  popup_subtitle = EXCLUDED.popup_subtitle,
  popup_offer_text = EXCLUDED.popup_offer_text,
  popup_cta_text = EXCLUDED.popup_cta_text,
  popup_disclaimer = EXCLUDED.popup_disclaimer;

-- Delete any other settings records to avoid confusion
DELETE FROM settings WHERE key != 'global';

-- Fix the relationship between affiliate_links and profiles
DO $$
BEGIN
  -- Drop existing constraint if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'affiliate_links_user_id_fkey'
    AND table_name = 'affiliate_links'
  ) THEN
    ALTER TABLE affiliate_links DROP CONSTRAINT affiliate_links_user_id_fkey;
  END IF;

  -- Add the correct constraint
  ALTER TABLE affiliate_links 
  ADD CONSTRAINT affiliate_links_user_id_profiles_fkey 
  FOREIGN KEY (user_id) REFERENCES profiles(user_id) ON DELETE CASCADE;
EXCEPTION
  WHEN others THEN
    -- If there's an error, we'll try a different approach
    NULL;
END $$;

-- Fix the relationship between compliance_tasks and profiles
DO $$
BEGIN
  -- Drop existing constraint if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'compliance_tasks_user_id_fkey'
    AND table_name = 'compliance_tasks'
  ) THEN
    ALTER TABLE compliance_tasks DROP CONSTRAINT compliance_tasks_user_id_fkey;
  END IF;

  -- Add the correct constraint
  ALTER TABLE compliance_tasks 
  ADD CONSTRAINT compliance_tasks_user_id_profiles_fkey 
  FOREIGN KEY (user_id) REFERENCES profiles(user_id) ON DELETE CASCADE;
EXCEPTION
  WHEN others THEN
    -- If there's an error, we'll try a different approach
    NULL;
END $$;

-- Update the handle_new_user function to ensure it works correctly
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, first_name, last_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'first_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'last_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'role', 'user')
  )
  ON CONFLICT (user_id) DO UPDATE SET
    email = EXCLUDED.email,
    first_name = EXCLUDED.first_name,
    last_name = EXCLUDED.last_name;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;