/*
  # Add sample document records for existing orders
  
  1. New Data
    - Add sample document records linked to existing orders
    - Include different document types (articles, ein, operating_agreement)
    - Use realistic file URLs and paths
    
  2. Changes
    - Insert document records for existing orders
    - Ensure proper relationships between documents, orders, and users
*/

-- Insert real document records for existing orders
-- First, get existing orders and users to link documents to
DO $$
DECLARE
  order_rec RECORD;
BEGIN
  -- Loop through existing orders
  -- Use table alias to avoid ambiguous column references
  FOR order_rec IN SELECT o.id, o.user_id FROM orders o LIMIT 10 LOOP
    -- Insert Articles of Organization document
    INSERT INTO documents (
      user_id,
      order_id,
      name,
      type,
      file_url,
      file_path,
      uploaded_at
    ) VALUES (
      order_rec.user_id,
      order_rec.id,
      'Articles of Organization',
      'articles',
      'https://www.irs.gov/pub/irs-pdf/f1120s.pdf',
      '/documents/articles/' || order_rec.id || '.pdf',
      now() - interval '2 days'
    );
    
    -- Insert EIN Confirmation document
    INSERT INTO documents (
      user_id,
      order_id,
      name,
      type,
      file_url,
      file_path,
      uploaded_at
    ) VALUES (
      order_rec.user_id,
      order_rec.id,
      'EIN Confirmation Letter',
      'ein',
      'https://www.irs.gov/pub/irs-pdf/fss4.pdf',
      '/documents/ein/' || order_rec.id || '.pdf',
      now() - interval '1 day'
    );
    
    -- Insert Operating Agreement document
    INSERT INTO documents (
      user_id,
      order_id,
      name,
      type,
      file_url,
      file_path,
      uploaded_at
    ) VALUES (
      order_rec.user_id,
      order_rec.id,
      'Operating Agreement',
      'operating_agreement',
      'https://www.irs.gov/pub/irs-pdf/f8832.pdf',
      '/documents/operating_agreement/' || order_rec.id || '.pdf',
      now()
    );
  END LOOP;
END $$;