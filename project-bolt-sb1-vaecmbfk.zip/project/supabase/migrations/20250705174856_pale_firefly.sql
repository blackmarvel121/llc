-- Update the global settings record to include all popup fields
UPDATE settings 
SET 
  popup_enabled = false,
  popup_title = '🔥 Last Chance: FREE EIN Worth $275!',
  popup_subtitle = 'Don''t miss out! Get your LLC formed with a FREE EIN number (normally $275) when you start today. This exclusive offer expires soon!',
  popup_offer_text = 'FREE EIN Number - Save $275 on federal tax ID',
  popup_cta_text = '🚀 Claim FREE EIN Now - Only $49',
  popup_disclaimer = '* Limited time offer. EIN normally costs $275. Offer valid for new customers only.'
WHERE key = 'global';

-- If global settings don't exist, create them
INSERT INTO settings (
  key, 
  announcement_enabled, 
  announcement_text, 
  whatsapp_enabled, 
  whatsapp_number, 
  whatsapp_message,
  popup_enabled,
  popup_title,
  popup_subtitle,
  popup_offer_text,
  popup_cta_text,
  popup_disclaimer
)
SELECT 
  'global',
  true,
  '✅ 24-Hour LLC Guarantee by Razorfile',
  true,
  '+1234567890',
  'Hi! I need help with LLC formation.',
  false,
  '🔥 Last Chance: FREE EIN Worth $275!',
  'Don''t miss out! Get your LLC formed with a FREE EIN number (normally $275) when you start today. This exclusive offer expires soon!',
  'FREE EIN Number - Save $275 on federal tax ID',
  '🚀 Claim FREE EIN Now - Only $49',
  '* Limited time offer. EIN normally costs $275. Offer valid for new customers only.'
WHERE NOT EXISTS (SELECT 1 FROM settings WHERE key = 'global');