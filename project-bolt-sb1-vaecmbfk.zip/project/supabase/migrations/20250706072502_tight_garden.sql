/*
  # Add Razorpay Payment Gateway

  1. New Data
    - Add Razorpay payment gateway to payment_gateways table
    
  2. Security
    - Maintains existing RLS policies
*/

-- Insert Razorpay payment gateway if it doesn't exist
INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key) 
SELECT 'Razorpay', 'razorpay', false, '', ''
WHERE NOT EXISTS (
  SELECT 1 FROM payment_gateways WHERE type = 'razorpay'
);