/*
  # Fix user signup error by adding profile creation trigger

  1. Changes
    - Add trigger function to automatically create profile when user signs up
    - Ensure profile is created with user's email from auth.users
    - Handle the user_id foreign key relationship properly

  2. Security
    - Maintains existing RLS policies
    - Ensures data consistency between auth.users and profiles tables
*/

-- Create or replace the trigger function to handle new user creation
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, role)
  VALUES (NEW.id, NEW.email, 'user');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Create trigger to automatically create profile when user signs up
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();