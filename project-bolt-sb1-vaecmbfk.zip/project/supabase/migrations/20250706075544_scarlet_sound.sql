/*
  # Fix Payment Gateway Integration

  1. Changes
    - Add PayPal as a payment gateway option
    - Ensure all gateways have proper settings
    - Fix enabled status for all gateways
    
  2. Security
    - Maintains existing RLS policies
*/

-- First check if PayPal gateway exists
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM payment_gateways WHERE type = 'paypal') THEN
    -- Insert PayPal payment gateway
    INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key, webhook_secret, settings) 
    VALUES (
      'PayPal', 
      'paypal', 
      true, 
      'your_paypal_client_id', 
      'your_paypal_secret', 
      '',
      jsonb_build_object(
        'currency', 'USD',
        'description', 'LLC Formation Services',
        'mode', 'sandbox'
      )
    );
  ELSE
    -- Update existing PayPal gateway
    UPDATE payment_gateways
    SET name = 'PayPal', 
        settings = jsonb_build_object(
          'currency', 'USD',
          'description', 'LLC Formation Services',
          'mode', 'sandbox'
        )
    WHERE type = 'paypal';
  END IF;
END $$;

-- Make sure all gateways have proper settings
UPDATE payment_gateways
SET settings = jsonb_build_object(
  'currency', CASE WHEN type = 'razorpay' THEN 'INR' ELSE 'USD' END,
  'description', 'LLC Formation Services',
  'mode', 'sandbox'
)
WHERE settings IS NULL OR settings = '{}'::jsonb;

-- Ensure all gateways have proper enabled status based on having keys
UPDATE payment_gateways
SET enabled = (public_key != '' AND secret_key != '')
WHERE enabled IS NULL;