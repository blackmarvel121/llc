/*
  # Fix infinite recursion in profiles RLS policies

  1. Problem
    - The "Admins can read all profiles" policy creates infinite recursion
    - It queries the profiles table within its own policy condition
    - This causes circular dependency when checking admin status

  2. Solution
    - Drop the problematic policy that causes recursion
    - Create a new policy that avoids self-referencing the profiles table
    - Use JWT claims or simpler logic to check admin status

  3. Changes
    - Remove recursive admin policy
    - Create non-recursive admin access policy
    - Maintain existing user access to own profiles
*/

-- First, drop all existing policies that might cause conflicts
DROP POLICY IF EXISTS "Admins can read all profiles" ON profiles;
DROP POLICY IF EXISTS "Admin access to all profiles" ON profiles;
DROP POLICY IF EXISTS "Profile access policy" ON profiles;

-- Keep the existing "Users can read own profile" policy as it already exists
-- and doesn't cause recursion issues

-- Create a new admin policy that doesn't cause recursion
-- This policy allows admin users to read all profiles without querying profiles table
CREATE POLICY "Admin can read all profiles" 
  ON profiles 
  FOR SELECT 
  TO authenticated 
  USING (
    -- Check if current user has admin role via JWT claims or auth metadata
    -- This avoids querying the profiles table and prevents recursion
    (
      auth.jwt() ->> 'role' = 'admin'
      OR 
      auth.jwt() -> 'user_metadata' ->> 'role' = 'admin'
      OR
      auth.jwt() -> 'app_metadata' ->> 'role' = 'admin'
    )
  );