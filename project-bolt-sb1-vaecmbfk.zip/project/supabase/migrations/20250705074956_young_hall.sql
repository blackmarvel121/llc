/*
  # Create settings table for application configuration

  1. New Tables
    - `settings`
      - `id` (uuid, primary key)
      - `key` (text, unique)
      - `announcement_enabled` (boolean)
      - `announcement_text` (text)
      - `whatsapp_enabled` (boolean)
      - `whatsapp_number` (text)
      - `whatsapp_message` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `settings` table
    - Add policy for admins to manage settings
    - Add policy for anyone to read settings

  3. Triggers
    - Add updated_at trigger for automatic timestamp updates

  4. Default Data
    - Insert default announcement and WhatsApp settings
*/

CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  announcement_enabled boolean DEFAULT true,
  announcement_text text DEFAULT '✅ 24-Hour LLC Guarantee by Razorfile',
  whatsapp_enabled boolean DEFAULT true,
  whatsapp_number text DEFAULT '+1234567890',
  whatsapp_message text DEFAULT 'Hi! I need help with LLC formation.',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$
BEGIN
  DROP POLICY IF EXISTS "Admins can manage settings" ON settings;
  DROP POLICY IF EXISTS "Anyone can read settings" ON settings;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create policies
CREATE POLICY "Admins can manage settings"
  ON settings
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.user_id = auth.uid() AND profiles.role = 'admin'
  ));

CREATE POLICY "Anyone can read settings"
  ON settings
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Create or replace the trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS update_settings_updated_at ON settings;

-- Create trigger for updated_at
CREATE TRIGGER update_settings_updated_at
  BEFORE UPDATE ON settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert default settings (only if they don't exist)
INSERT INTO settings (key, announcement_enabled, announcement_text, whatsapp_enabled, whatsapp_number, whatsapp_message) 
SELECT 'announcement', true, '✅ 24-Hour LLC Guarantee by Razorfile', false, '', ''
WHERE NOT EXISTS (SELECT 1 FROM settings WHERE key = 'announcement');

INSERT INTO settings (key, announcement_enabled, announcement_text, whatsapp_enabled, whatsapp_number, whatsapp_message) 
SELECT 'whatsapp', false, '', true, '+1234567890', 'Hi! I need help with LLC formation.'
WHERE NOT EXISTS (SELECT 1 FROM settings WHERE key = 'whatsapp');