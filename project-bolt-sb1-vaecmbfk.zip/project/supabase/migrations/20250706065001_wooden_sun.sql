/*
  # Add sample compliance tasks

  1. New Data
    - Add sample compliance tasks for existing users
    - Create tasks with different due dates and statuses
    - Link tasks to users and orders

  2. Security
    - Maintains existing RLS policies
*/

-- Insert sample compliance tasks for existing users
DO $$
DECLARE
  user_rec RECORD;
  order_rec RECORD;
BEGIN
  -- Loop through existing users
  FOR user_rec IN SELECT id FROM auth.users LIMIT 10 LOOP
    -- Get a random order for this user
    SELECT id INTO order_rec FROM orders WHERE user_id = user_rec.id LIMIT 1;
    
    -- Only proceed if we found an order
    IF order_rec.id IS NOT NULL THEN
      -- Annual Report task (due in future)
      INSERT INTO compliance_tasks (
        user_id,
        order_id,
        title,
        description,
        due_date,
        is_completed,
        completed_at
      ) VALUES (
        user_rec.id,
        order_rec.id,
        'File Annual Report',
        'Submit your annual report to maintain good standing with the state',
        now() + interval '6 months',
        false,
        null
      );
      
      -- Tax filing reminder (due soon)
      INSERT INTO compliance_tasks (
        user_id,
        order_id,
        title,
        description,
        due_date,
        is_completed,
        completed_at
      ) VALUES (
        user_rec.id,
        order_rec.id,
        'Quarterly Tax Filing',
        'Submit your quarterly estimated tax payments',
        now() + interval '2 weeks',
        false,
        null
      );
      
      -- Completed task
      INSERT INTO compliance_tasks (
        user_id,
        order_id,
        title,
        description,
        due_date,
        is_completed,
        completed_at
      ) VALUES (
        user_rec.id,
        order_rec.id,
        'Obtain Business License',
        'Apply for local business license',
        now() - interval '1 month',
        true,
        now() - interval '1 week'
      );
    END IF;
  END LOOP;
END $$;