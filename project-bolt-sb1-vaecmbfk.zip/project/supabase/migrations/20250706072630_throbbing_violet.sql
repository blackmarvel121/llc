/*
  # Create payment_events table for tracking payment gateway events

  1. New Tables
    - `payment_events`
      - `id` (uuid, primary key)
      - `gateway` (text) - payment gateway name
      - `event_type` (text) - type of event
      - `payment_id` (text) - payment ID from gateway
      - `order_id` (text) - order ID from gateway
      - `amount` (numeric) - payment amount
      - `status` (text) - payment status
      - `raw_data` (jsonb) - raw event data
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `payment_events` table
    - Add policies for admin access only
*/

CREATE TABLE IF NOT EXISTS payment_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  gateway text NOT NULL,
  event_type text NOT NULL,
  payment_id text,
  order_id text,
  amount numeric,
  status text,
  raw_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE payment_events ENABLE ROW LEVEL SECURITY;

-- Create policy for admin access
CREATE POLICY "Admins can manage payment events"
  ON payment_events
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.user_id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );