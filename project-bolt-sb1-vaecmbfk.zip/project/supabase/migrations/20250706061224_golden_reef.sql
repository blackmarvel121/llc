/*
  # Add company_name column to orders table

  1. Changes
    - Add company_name column to orders table to store the company name from checkout
    - This allows us to display the company name in the orders list and details
    
  2. Security
    - Maintains existing RLS policies
*/

-- Add company_name column to orders table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'orders' AND column_name = 'company_name'
  ) THEN
    ALTER TABLE orders ADD COLUMN company_name text DEFAULT '';
  END IF;
END $$;