/*
  # Add Stripe Integration

  1. Changes
    - Update Stripe gateway configuration
    - Create a function to handle Stripe webhook events
    - Add necessary indexes for better performance
*/

-- Update Stripe gateway configuration
UPDATE payment_gateways
SET enabled = true,
    name = 'Stripe',
    settings = jsonb_build_object(
      'currency', 'USD',
      'description', 'LLC Formation Services',
      'payment_method_types', jsonb_build_array('card')
    )
WHERE type = 'stripe';

-- Create a function to handle Stripe webhook events
CREATE OR REPLACE FUNCTION handle_stripe_webhook(payload JSONB)
RETURNS JSONB AS $$
DECLARE
  event_type TEXT;
  payment_intent_id TEXT;
  payment_status TEXT;
  db_order_id UUID;
BEGIN
  -- Extract event type and payment intent ID
  event_type := payload->>'type';
  
  -- Handle different event types
  IF event_type = 'payment_intent.succeeded' THEN
    payment_intent_id := (payload->'data'->'object'->>'id');
    payment_status := 'paid';
    
    -- Update the order status
    UPDATE orders
    SET payment_status = payment_status,
        status = 'processing'
    WHERE payment_id = payment_intent_id
    RETURNING id INTO db_order_id;
    
    -- Return success response
    RETURN jsonb_build_object(
      'success', TRUE,
      'message', 'Payment succeeded',
      'order_id', db_order_id
    );
  ELSIF event_type = 'payment_intent.payment_failed' THEN
    payment_intent_id := (payload->'data'->'object'->>'id');
    payment_status := 'failed';
    
    -- Update the order status
    UPDATE orders
    SET payment_status = payment_status
    WHERE payment_id = payment_intent_id
    RETURNING id INTO db_order_id;
    
    -- Return failure response
    RETURN jsonb_build_object(
      'success', TRUE,
      'message', 'Payment failed',
      'order_id', db_order_id
    );
  ELSE
    -- Unhandled event type
    RETURN jsonb_build_object(
      'success', TRUE,
      'message', 'Unhandled event type: ' || event_type
    );
  END IF;
  
EXCEPTION WHEN OTHERS THEN
  -- Return error response
  RETURN jsonb_build_object(
    'success', FALSE,
    'message', 'Error processing webhook: ' || SQLERRM
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create indexes for better performance if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'orders_payment_id_idx'
  ) THEN
    CREATE INDEX orders_payment_id_idx ON orders(payment_id);
  END IF;
END $$;