/*
  # Add popup settings to settings table

  1. Changes
    - Add popup_enabled column to settings table
    - Add popup_title, popup_subtitle, popup_offer_text, popup_cta_text, popup_disclaimer columns
    - Update existing settings records with popup fields

  2. Security
    - Maintains existing RLS policies
*/

-- Add popup-related columns to settings table if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'settings' AND column_name = 'popup_enabled') THEN
    ALTER TABLE settings ADD COLUMN popup_enabled boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'settings' AND column_name = 'popup_title') THEN
    ALTER TABLE settings ADD COLUMN popup_title text DEFAULT '🔥 Last Chance: FREE EIN Worth $275!';
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'settings' AND column_name = 'popup_subtitle') THEN
    ALTER TABLE settings ADD COLUMN popup_subtitle text DEFAULT 'Don''t miss out! Get your LLC formed with a FREE EIN number (normally $275) when you start today. This exclusive offer expires soon!';
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'settings' AND column_name = 'popup_offer_text') THEN
    ALTER TABLE settings ADD COLUMN popup_offer_text text DEFAULT 'FREE EIN Number - Save $275 on federal tax ID';
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'settings' AND column_name = 'popup_cta_text') THEN
    ALTER TABLE settings ADD COLUMN popup_cta_text text DEFAULT '🚀 Claim FREE EIN Now - Only $49';
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'settings' AND column_name = 'popup_disclaimer') THEN
    ALTER TABLE settings ADD COLUMN popup_disclaimer text DEFAULT '* Limited time offer. EIN normally costs $275. Offer valid for new customers only.';
  END IF;
END $$;

-- Insert urgency popup settings if they don't exist
INSERT INTO settings (key, popup_enabled, popup_title, popup_subtitle, popup_offer_text, popup_cta_text, popup_disclaimer)
VALUES (
  'urgency_popup',
  false,
  '🔥 Last Chance: FREE EIN Worth $275!',
  'Don''t miss out! Get your LLC formed with a FREE EIN number (normally $275) when you start today. This exclusive offer expires soon!',
  'FREE EIN Number - Save $275 on federal tax ID',
  '🚀 Claim FREE EIN Now - Only $49',
  '* Limited time offer. EIN normally costs $275. Offer valid for new customers only.'
)
ON CONFLICT (key) DO NOTHING;