/*
  # Fix infinite recursion in RLS policies

  1. Problem
    - The profiles table policies are causing infinite recursion
    - Admin check policies on other tables reference profiles table
    - This creates circular dependencies

  2. Solution
    - Simplify profiles table policies to avoid recursion
    - Use direct auth.uid() checks instead of self-referencing queries
    - Ensure admin policies don't create circular references

  3. Changes
    - Update profiles table policies to use direct auth checks
    - Maintain security while avoiding recursion
*/

-- Drop existing problematic policies on profiles table
DROP POLICY IF EXISTS "Admins can read all profiles" ON profiles;
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;

-- Create new simplified policies for profiles table
-- These avoid recursion by using direct auth.uid() checks
CREATE POLICY "Users can read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create a separate admin read policy that doesn't cause recursion
-- This uses a direct role check without subqueries
CREATE POLICY "Admins can read all profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p 
      WHERE p.user_id = auth.uid() 
      AND p.role = 'admin'
      AND p.id != profiles.id  -- Prevent self-reference
    )
    OR auth.uid() = user_id  -- Users can still read their own
  );

-- Update support_tickets policies to be more direct
DROP POLICY IF EXISTS "Admins can read all tickets" ON support_tickets;
DROP POLICY IF EXISTS "Admins can update tickets" ON support_tickets;

-- Create new admin policies that are less likely to cause recursion
CREATE POLICY "Admins can read all tickets"
  ON support_tickets
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id  -- Users can read their own
    OR EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.user_id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update tickets"
  ON support_tickets
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.user_id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Ensure the function for updating timestamps exists
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';