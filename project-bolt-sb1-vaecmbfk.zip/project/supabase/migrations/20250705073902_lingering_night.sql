/*
  # Insert Initial Data

  This migration adds initial data to the database including:
  - Default packages
  - US states information
  - Common add-ons
  - FAQ entries
  - Default settings
*/

-- Insert default packages
INSERT INTO packages (name, description, price, features, is_popular, includes_ein, includes_registered_agent, same_day_filing) VALUES
  ('Basic', 'Perfect for getting started', 49, ARRAY['LLC Formation', 'State Filing', 'Email Support', 'Basic Templates'], false, false, false, false),
  ('Standard', 'Most popular choice', 99, ARRAY['Everything in Basic', 'EIN Number', 'Registered Agent (1 Year)', 'Operating Agreement', 'Priority Support'], true, true, true, false),
  ('Premium', 'Complete business package', 199, ARRAY['Everything in Standard', 'Same-Day Filing', 'Banking Resolution', 'ITIN Application', 'Compliance Monitoring', 'Phone Support'], false, true, true, true);

-- Insert US states
INSERT INTO states (name, code, filing_fee, turnaround_time, monthly_price, yearly_price, one_time_price) VALUES
  ('Alabama', 'AL', 200, '3-5 business days', 49, 499, 49),
  ('Alaska', 'AK', 250, '5-7 business days', 49, 499, 49),
  ('Arizona', 'AZ', 50, '1-3 business days', 49, 499, 49),
  ('Arkansas', 'AR', 45, '2-4 business days', 49, 499, 49),
  ('California', 'CA', 70, '3-5 business days', 49, 499, 49),
  ('Colorado', 'CO', 50, '1-3 business days', 49, 499, 49),
  ('Connecticut', 'CT', 120, '3-5 business days', 49, 499, 49),
  ('Delaware', 'DE', 90, '1-2 business days', 49, 499, 49),
  ('Florida', 'FL', 125, '2-3 business days', 49, 499, 49),
  ('Georgia', 'GA', 100, '2-4 business days', 49, 499, 49),
  ('Hawaii', 'HI', 50, '5-7 business days', 49, 499, 49),
  ('Idaho', 'ID', 100, '3-5 business days', 49, 499, 49),
  ('Illinois', 'IL', 150, '4-6 business days', 49, 499, 49),
  ('Indiana', 'IN', 95, '2-4 business days', 49, 499, 49),
  ('Iowa', 'IA', 50, '3-5 business days', 49, 499, 49),
  ('Kansas', 'KS', 160, '3-5 business days', 49, 499, 49),
  ('Kentucky', 'KY', 40, '2-4 business days', 49, 499, 49),
  ('Louisiana', 'LA', 100, '3-5 business days', 49, 499, 49),
  ('Maine', 'ME', 175, '4-6 business days', 49, 499, 49),
  ('Maryland', 'MD', 100, '2-4 business days', 49, 499, 49),
  ('Massachusetts', 'MA', 520, '5-7 business days', 49, 499, 49),
  ('Michigan', 'MI', 50, '2-4 business days', 49, 499, 49),
  ('Minnesota', 'MN', 135, '3-5 business days', 49, 499, 49),
  ('Mississippi', 'MS', 50, '3-5 business days', 49, 499, 49),
  ('Missouri', 'MO', 50, '2-4 business days', 49, 499, 49),
  ('Montana', 'MT', 35, '3-5 business days', 49, 499, 49),
  ('Nebraska', 'NE', 105, '3-5 business days', 49, 499, 49),
  ('Nevada', 'NV', 75, '1-3 business days', 49, 499, 49),
  ('New Hampshire', 'NH', 100, '3-5 business days', 49, 499, 49),
  ('New Jersey', 'NJ', 125, '3-5 business days', 49, 499, 49),
  ('New Mexico', 'NM', 50, '2-4 business days', 49, 499, 49),
  ('New York', 'NY', 200, '4-6 business days', 49, 499, 49),
  ('North Carolina', 'NC', 125, '2-4 business days', 49, 499, 49),
  ('North Dakota', 'ND', 135, '3-5 business days', 49, 499, 49),
  ('Ohio', 'OH', 99, '2-4 business days', 49, 499, 49),
  ('Oklahoma', 'OK', 100, '3-5 business days', 49, 499, 49),
  ('Oregon', 'OR', 100, '3-5 business days', 49, 499, 49),
  ('Pennsylvania', 'PA', 125, '3-5 business days', 49, 499, 49),
  ('Rhode Island', 'RI', 150, '4-6 business days', 49, 499, 49),
  ('South Carolina', 'SC', 110, '2-4 business days', 49, 499, 49),
  ('South Dakota', 'SD', 150, '3-5 business days', 49, 499, 49),
  ('Tennessee', 'TN', 300, '3-5 business days', 49, 499, 49),
  ('Texas', 'TX', 300, '2-3 business days', 49, 499, 49),
  ('Utah', 'UT', 70, '2-4 business days', 49, 499, 49),
  ('Vermont', 'VT', 125, '4-6 business days', 49, 499, 49),
  ('Virginia', 'VA', 100, '2-4 business days', 49, 499, 49),
  ('Washington', 'WA', 200, '3-5 business days', 49, 499, 49),
  ('West Virginia', 'WV', 100, '3-5 business days', 49, 499, 49),
  ('Wisconsin', 'WI', 130, '3-5 business days', 49, 499, 49),
  ('Wyoming', 'WY', 100, '1-2 business days', 49, 499, 49);

-- Insert common add-ons
INSERT INTO addons (name, description, price, category) VALUES
  ('EIN Number', 'Get your Federal Tax ID number', 49, 'tax'),
  ('Registered Agent', 'Professional registered agent service for 1 year', 99, 'compliance'),
  ('Operating Agreement', 'Customized operating agreement for your LLC', 79, 'legal'),
  ('ITIN Application', 'Individual Taxpayer Identification Number application', 199, 'tax'),
  ('Banking Resolution', 'Corporate banking resolution for business accounts', 39, 'banking'),
  ('Expedited Processing', 'Same-day state filing (where available)', 149, 'service'),
  ('Business License Research', 'Research required business licenses for your industry', 89, 'compliance'),
  ('Trademark Search', 'Basic trademark search for your business name', 79, 'legal'),
  ('Annual Report Filing', 'Annual report filing service', 69, 'compliance'),
  ('Compliance Monitoring', 'Ongoing compliance monitoring and reminders', 149, 'compliance');

-- Insert FAQ entries
INSERT INTO faqs (question, answer, order_index) VALUES
  ('How long does it take to form an LLC?', 'We guarantee your LLC will be filed within 24 hours. Most states process within 1-3 business days, but some may take longer.', 1),
  ('What is included in the $49 package?', 'Our basic package includes state filing, preparation of Articles of Organization, and email support. EIN and Registered Agent services are available as add-ons.', 2),
  ('Do I need a registered agent?', 'Yes, every LLC needs a registered agent. You can serve as your own registered agent or hire our professional registered agent service.', 3),
  ('What states do you file in?', 'We file LLCs in all 50 states. Each state has different filing fees and processing times.', 4),
  ('What is an EIN and do I need one?', 'An EIN (Employer Identification Number) is a federal tax ID for your business. You need one to open a business bank account, hire employees, or file taxes.', 5),
  ('What happens after I place my order?', 'We will prepare and file your LLC documents within 24 hours. You will receive email updates throughout the process and can track your order in your dashboard.', 6),
  ('Do you offer refunds?', 'Yes, we offer a 100% satisfaction guarantee. If you are not satisfied with our service, we will provide a full refund within 30 days.', 7),
  ('What is the difference between an LLC and a Corporation?', 'An LLC provides personal liability protection with fewer formalities than a corporation. LLCs have flexible management structure and pass-through taxation.', 8),
  ('Can I change my LLC name after formation?', 'Yes, you can change your LLC name by filing an amendment with the state. We can help you with this process for an additional fee.', 9),
  ('What ongoing requirements does my LLC have?', 'Most states require annual reports and fees. Some states also require publication or other compliance requirements. We provide compliance monitoring to help you stay on track.', 10);

-- Insert default settings
INSERT INTO settings (key, announcement_enabled, announcement_text, whatsapp_enabled, whatsapp_number, whatsapp_message) VALUES
  ('announcement', true, '✅ 24-Hour LLC Guarantee by Razorfile', true, '+1234567890', 'Hi! I need help with LLC formation.'),
  ('whatsapp', true, '✅ 24-Hour LLC Guarantee by Razorfile', true, '+1234567890', 'Hi! I need help with LLC formation.');