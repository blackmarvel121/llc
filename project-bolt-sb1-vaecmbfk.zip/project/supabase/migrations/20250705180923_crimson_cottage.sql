/*
  # Fix Settings Table Permissions and Consolidate Data

  1. Problem
    - The settings table has permission issues causing "permission denied for table users" errors
    - Multiple settings records with different keys causing confusion
    - Foreign key constraints referencing auth.users directly causing permission issues

  2. Solution
    - Consolidate all settings into a single 'global' record
    - Simplify RLS policies to only use profiles table for admin verification
    - Fix foreign key constraints to reference profiles.user_id instead of auth.users directly

  3. Changes
    - Create or update a single global settings record
    - Drop problematic policies and create simpler ones
    - Update foreign key constraints
*/

-- First, ensure we have a single global settings record with all fields
INSERT INTO settings (
  key, 
  announcement_enabled, 
  announcement_text, 
  whatsapp_enabled, 
  whatsapp_number, 
  whatsapp_message,
  popup_enabled,
  popup_title,
  popup_subtitle,
  popup_offer_text,
  popup_cta_text,
  popup_disclaimer
)
VALUES (
  'global',
  true,
  '✅ 24-Hour LLC Guarantee by Razorfile',
  true,
  '+1234567890',
  'Hi! I need help with LLC formation.',
  false,
  '🔥 Last Chance: Professional LLC Formation',
  'Don''t miss out! Get your LLC formed professionally when you start today. This exclusive offer expires soon!',
  'Professional LLC Formation Service',
  '🚀 Start My LLC Now - Only $49',
  '* Limited time offer. Offer valid for new customers only.'
)
ON CONFLICT (key) DO UPDATE SET
  announcement_enabled = EXCLUDED.announcement_enabled,
  announcement_text = EXCLUDED.announcement_text,
  whatsapp_enabled = EXCLUDED.whatsapp_enabled,
  whatsapp_number = EXCLUDED.whatsapp_number,
  whatsapp_message = EXCLUDED.whatsapp_message,
  popup_enabled = EXCLUDED.popup_enabled,
  popup_title = EXCLUDED.popup_title,
  popup_subtitle = EXCLUDED.popup_subtitle,
  popup_offer_text = EXCLUDED.popup_offer_text,
  popup_cta_text = EXCLUDED.popup_cta_text,
  popup_disclaimer = EXCLUDED.popup_disclaimer;

-- Delete any other settings records to avoid confusion
DELETE FROM settings WHERE key != 'global';

-- Drop existing policies that might cause permission issues
DROP POLICY IF EXISTS "Admins can delete settings" ON settings;
DROP POLICY IF EXISTS "Admins can insert settings" ON settings;
DROP POLICY IF EXISTS "Admins can update settings" ON settings;
DROP POLICY IF EXISTS "Admins can manage settings" ON settings;

-- Create new simplified admin policies using only profiles table
CREATE POLICY "Admins can manage settings"
  ON settings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.user_id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Ensure "Anyone can read settings" policy exists
DROP POLICY IF EXISTS "Anyone can read settings" ON settings;
CREATE POLICY "Anyone can read settings"
  ON settings
  FOR SELECT
  TO anon, authenticated
  USING (true);