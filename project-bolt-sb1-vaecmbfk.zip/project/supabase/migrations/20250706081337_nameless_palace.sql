/*
  # Fix Payment Gateways in Checkout

  1. Changes
    - Ensure all payment gateways are disabled by default
    - Add indexes for better performance
    - Fix foreign key relationships for compliance_tasks

  2. Security
    - Maintains existing RLS policies
*/

-- Ensure all gateways have proper enabled status
UPDATE payment_gateways
SET enabled = false
WHERE type IN ('stripe', 'razorpay', 'paypal');

-- Add an index on the type column for faster lookups if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'payment_gateways_type_idx'
  ) THEN
    CREATE INDEX payment_gateways_type_idx ON payment_gateways(type);
  END IF;
END $$;

-- Add an index on the enabled column for faster filtering if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'payment_gateways_enabled_idx'
  ) THEN
    CREATE INDEX payment_gateways_enabled_idx ON payment_gateways(enabled);
  END IF;
END $$;

-- Add foreign key constraint if it doesn't exist
DO $$
BEGIN
  -- Check if the foreign key constraint already exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'compliance_tasks_user_id_profiles_fkey'
    AND table_name = 'compliance_tasks'
  ) THEN
    -- Add the foreign key constraint to link compliance_tasks.user_id to profiles.user_id
    ALTER TABLE compliance_tasks 
    ADD CONSTRAINT compliance_tasks_user_id_profiles_fkey 
    FOREIGN KEY (user_id) REFERENCES profiles(user_id) ON DELETE CASCADE;
  END IF;
END $$;