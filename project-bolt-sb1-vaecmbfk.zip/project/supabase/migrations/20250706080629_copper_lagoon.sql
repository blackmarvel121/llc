/*
  # Fix Payment Gateways in Checkout

  1. Problem
    - Disabled payment gateways are still showing up on the user website in checkout
    - The enabled flag is not being respected in the frontend

  2. Solution
    - Update the Checkout component to check if payment gateways are enabled
    - Add a function to fetch enabled payment gateways
    - Filter payment methods based on enabled status
*/

-- Ensure all gateways have proper enabled status
UPDATE payment_gateways
SET enabled = false
WHERE type IN ('stripe', 'razorpay', 'paypal');

-- Add an index on the type column for faster lookups
CREATE INDEX IF NOT EXISTS payment_gateways_type_idx ON payment_gateways(type);

-- Add an index on the enabled column for faster filtering
CREATE INDEX IF NOT EXISTS payment_gateways_enabled_idx ON payment_gateways(enabled);