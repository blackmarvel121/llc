/*
  # Add Razorpay payment gateway

  1. Changes
    - Add Razorpay as a payment gateway option
    - Ensure policy exists but avoid "already exists" error
    - Insert both Stripe and Razorpay gateways with proper configuration
*/

-- Insert default payment gateways if they don't exist
INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key) 
SELECT 'Stripe', 'stripe', true, 'pk_test_your_stripe_key', 'sk_test_your_stripe_key'
WHERE NOT EXISTS (
  SELECT 1 FROM payment_gateways WHERE type = 'stripe'
);

INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key) 
SELECT 'Razorpay', 'razorpay', true, 'rzp_test_your_razorpay_key', 'your_razorpay_secret_key'
WHERE NOT EXISTS (
  SELECT 1 FROM payment_gateways WHERE type = 'razorpay'
);

-- Update existing gateways with new settings if they exist
UPDATE payment_gateways
SET enabled = true,
    public_key = 'pk_test_your_stripe_key',
    secret_key = 'sk_test_your_stripe_key'
WHERE type = 'stripe';

UPDATE payment_gateways
SET enabled = true,
    public_key = 'rzp_test_your_razorpay_key',
    secret_key = 'your_razorpay_secret_key'
WHERE type = 'razorpay';