/*
  # Add PayPal Gateway and Fix Payment Gateway Configuration

  1. New Data
    - Add PayPal as a payment gateway option
    - Set default values for PayPal configuration
    - Ensure it's properly configured in the database

  2. Security
    - Maintains existing RLS policies
*/

-- First check if PayPal gateway exists
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM payment_gateways WHERE type = 'paypal') THEN
    -- Insert PayPal payment gateway
    INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key, webhook_secret, settings) 
    VALUES (
      'PayPal', 
      'paypal', 
      true, 
      'your_paypal_client_id', 
      'your_paypal_secret', 
      '',
      jsonb_build_object(
        'currency', 'USD',
        'description', 'LLC Formation Services',
        'mode', 'sandbox'
      )
    );
  ELSE
    -- Update existing PayPal gateway
    UPDATE payment_gateways
    SET name = 'PayPal', 
        enabled = true,
        settings = jsonb_build_object(
          'currency', 'USD',
          'description', 'LLC Formation Services',
          'mode', 'sandbox'
        )
    WHERE type = 'paypal';
  END IF;
END $$;

-- Make sure all gateways have proper settings
UPDATE payment_gateways
SET settings = jsonb_build_object(
  'currency', CASE WHEN type = 'razorpay' THEN 'INR' ELSE 'USD' END,
  'description', 'LLC Formation Services',
  'mode', 'sandbox'
)
WHERE settings IS NULL OR settings = '{}'::jsonb;

-- Ensure all gateways have proper enabled status
UPDATE payment_gateways
SET enabled = true
WHERE type IN ('stripe', 'razorpay', 'paypal');

-- Update the type check constraint to include paypal if needed
DO $$
BEGIN
  -- Check if the constraint needs to be updated
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'payment_gateways_type_check' 
    AND conrelid = 'payment_gateways'::regclass
    AND pg_get_constraintdef(oid) LIKE '%paypal%'
  ) THEN
    -- Alter the constraint to include paypal
    ALTER TABLE payment_gateways DROP CONSTRAINT IF EXISTS payment_gateways_type_check;
    ALTER TABLE payment_gateways ADD CONSTRAINT payment_gateways_type_check 
      CHECK (type IN ('stripe', 'razorpay', 'paypal', 'square'));
  END IF;
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Error updating constraint: %', SQLERRM;
END $$;