/*
  # Add payment gateways table for Stripe integration

  1. New Tables
    - `payment_gateways`
      - `id` (uuid, primary key)
      - `name` (text)
      - `type` (text) - stripe, razorpay, etc.
      - `enabled` (boolean)
      - `public_key` (text)
      - `secret_key` (text)
      - `webhook_secret` (text, optional)
      - `settings` (jsonb, optional)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `payment_gateways` table
    - Add policies for admin access only

  3. Default Data
    - Insert default Stripe gateway
*/

-- Create payment_gateways table if it doesn't exist
CREATE TABLE IF NOT EXISTS payment_gateways (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('stripe', 'razorpay', 'paypal', 'square')),
  enabled boolean DEFAULT false,
  public_key text DEFAULT '',
  secret_key text DEFAULT '',
  webhook_secret text DEFAULT '',
  settings jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relname = 'payment_gateways'
    AND n.nspname = 'public'
    AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE payment_gateways ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Drop existing policy if it exists and create new one
DO $$
BEGIN
  DROP POLICY IF EXISTS "Admins can manage payment gateways" ON payment_gateways;
  
  CREATE POLICY "Admins can manage payment gateways"
    ON payment_gateways
    FOR ALL
    TO authenticated
    USING (
      EXISTS (
        SELECT 1 FROM profiles 
        WHERE profiles.user_id = auth.uid() 
        AND profiles.role = 'admin'
      )
    );
END $$;

-- Create trigger for updated_at if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_payment_gateways_updated_at'
  ) THEN
    CREATE TRIGGER update_payment_gateways_updated_at
      BEFORE UPDATE ON payment_gateways
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

-- Insert default payment gateway if it doesn't exist
INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key) 
SELECT 'Stripe', 'stripe', true, 'pk_test_your_public_key', 'sk_test_your_secret_key'
WHERE NOT EXISTS (
  SELECT 1 FROM payment_gateways WHERE type = 'stripe'
);