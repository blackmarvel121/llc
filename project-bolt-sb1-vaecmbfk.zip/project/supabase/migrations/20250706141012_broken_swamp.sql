/*
  # Add geo_tracking table for visitor analytics

  1. New Tables
    - `geo_tracking`
      - `id` (uuid, primary key)
      - `country` (text)
      - `state` (text)
      - `city` (text)
      - `visitors` (integer)
      - `conversions` (integer)
      - `revenue` (numeric)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `geo_tracking` table
    - Add policies for admin access only
*/

CREATE TABLE IF NOT EXISTS geo_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country text NOT NULL,
  state text,
  city text,
  visitors integer DEFAULT 0,
  conversions integer DEFAULT 0,
  revenue numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE geo_tracking ENABLE ROW LEVEL SECURITY;

-- Create policy for admin access
CREATE POLICY "Admins can manage geo tracking"
  ON geo_tracking
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.user_id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Create trigger for updated_at
CREATE TRIGGER update_geo_tracking_updated_at
  BEFORE UPDATE ON geo_tracking
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert sample data for testing
INSERT INTO geo_tracking (country, state, city, visitors, conversions, revenue)
VALUES 
  ('United States', 'California', 'Los Angeles', 1247, 89, 12450),
  ('United States', 'New York', 'New York', 892, 67, 9340),
  ('United States', 'Texas', 'Houston', 743, 52, 7280),
  ('United States', 'Florida', 'Miami', 634, 41, 5730),
  ('United States', 'Delaware', 'Wilmington', 521, 38, 4980),
  ('United States', 'Wyoming', 'Cheyenne', 489, 35, 4550),
  ('Canada', 'Ontario', 'Toronto', 456, 28, 3920),
  ('United Kingdom', 'England', 'London', 389, 23, 3220),
  ('Australia', 'New South Wales', 'Sydney', 267, 18, 2520),
  ('Germany', 'Bavaria', 'Munich', 234, 15, 2100)
ON CONFLICT (id) DO NOTHING;