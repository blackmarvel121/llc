/*
  # Add Razorpay Payment Gateway

  1. New Data
    - Add Razorpay as a payment gateway option
    - Set default values for Razorpay configuration
    - Ensure it's disabled by default until configured

  2. Security
    - Maintains existing RLS policies
*/

-- Insert Razorpay payment gateway if it doesn't exist
INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key, webhook_secret) 
SELECT 'Razorpay', 'razorpay', false, '', '', ''
WHERE NOT EXISTS (
  SELECT 1 FROM payment_gateways WHERE type = 'razorpay'
);

-- Update Razorpay gateway if it exists but needs configuration updates
UPDATE payment_gateways
SET name = 'Razorpay', 
    settings = jsonb_build_object(
      'currency', 'INR',
      'description', 'LLC Formation Services',
      'theme_color', '#3b82f6'
    )
WHERE type = 'razorpay';