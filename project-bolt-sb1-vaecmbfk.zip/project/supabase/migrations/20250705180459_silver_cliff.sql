/*
  # Fix Settings Table and WhatsApp Settings

  1. Problem
    - The current settings table structure is causing issues with saving settings
    - Multiple settings records with different keys are causing conflicts
    - The MIN function on UUID is causing errors

  2. Solution
    - Consolidate all settings into a single global record
    - Fix the settings table structure
    - Update the WhatsAppSettings component to use the correct key
    - Ensure all components reference the global settings record

  3. Changes
    - Create a single global settings record with all settings fields
    - Update references to use the global key
    - Fix foreign key relationships
*/

-- First, ensure we have a single global settings record with all fields
INSERT INTO settings (
  key, 
  announcement_enabled, 
  announcement_text, 
  whatsapp_enabled, 
  whatsapp_number, 
  whatsapp_message,
  popup_enabled,
  popup_title,
  popup_subtitle,
  popup_offer_text,
  popup_cta_text,
  popup_disclaimer
)
VALUES (
  'global',
  true,
  '✅ 24-Hour LLC Guarantee by Razorfile',
  true,
  '+1234567890',
  'Hi! I need help with LLC formation.',
  false,
  '🔥 Last Chance: Professional LLC Formation',
  'Don''t miss out! Get your LLC formed professionally when you start today. This exclusive offer expires soon!',
  'Professional LLC Formation Service',
  '🚀 Start My LLC Now - Only $49',
  '* Limited time offer. Offer valid for new customers only.'
)
ON CONFLICT (key) DO UPDATE SET
  announcement_enabled = EXCLUDED.announcement_enabled,
  announcement_text = EXCLUDED.announcement_text,
  whatsapp_enabled = EXCLUDED.whatsapp_enabled,
  whatsapp_number = EXCLUDED.whatsapp_number,
  whatsapp_message = EXCLUDED.whatsapp_message,
  popup_enabled = EXCLUDED.popup_enabled,
  popup_title = EXCLUDED.popup_title,
  popup_subtitle = EXCLUDED.popup_subtitle,
  popup_offer_text = EXCLUDED.popup_offer_text,
  popup_cta_text = EXCLUDED.popup_cta_text,
  popup_disclaimer = EXCLUDED.popup_disclaimer;

-- Delete any other settings records to avoid confusion
DELETE FROM settings WHERE key != 'global';

-- Update the handle_new_user function to ensure it works correctly with metadata
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, first_name, last_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'first_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'last_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'role', 'user')
  )
  ON CONFLICT (user_id) DO UPDATE SET
    email = EXCLUDED.email,
    first_name = EXCLUDED.first_name,
    last_name = EXCLUDED.last_name;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;