/*
  # Fix Support Tickets RLS Policy

  1. Problem
    - Users cannot create support tickets due to RLS policy issues
    - The current policy has incorrect WITH CHECK clause
    - Error: "new row violates row-level security policy for table support_tickets"

  2. Solution
    - Drop existing problematic policies
    - Create new policies with correct WITH CHECK clause
    - Ensure users can create and read their own tickets
    - Maintain admin access to all tickets
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Users can create tickets" ON support_tickets;
DROP POLICY IF EXISTS "Users can read own tickets" ON support_tickets;

-- Create new policies with correct WITH CHECK clause
CREATE POLICY "Users can create tickets"
  ON support_tickets
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read own tickets"
  ON support_tickets
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Ensure admin policies are correct
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'support_tickets' 
    AND policyname = 'Admins can read all tickets'
  ) THEN
    CREATE POLICY "Admins can read all tickets"
      ON support_tickets
      FOR SELECT
      TO authenticated
      USING (
        EXISTS (
          SELECT 1 FROM profiles 
          WHERE profiles.user_id = auth.uid() 
          AND profiles.role = 'admin'
        )
      );
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'support_tickets' 
    AND policyname = 'Admins can update tickets'
  ) THEN
    CREATE POLICY "Admins can update tickets"
      ON support_tickets
      FOR UPDATE
      TO authenticated
      USING (
        EXISTS (
          SELECT 1 FROM profiles 
          WHERE profiles.user_id = auth.uid() 
          AND profiles.role = 'admin'
        )
      );
  END IF;
END $$;