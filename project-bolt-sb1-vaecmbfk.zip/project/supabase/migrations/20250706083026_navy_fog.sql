/*
  # Fix Order Management in Admin Panel

  1. Problem
    - The relationship between orders and users is not properly established
    - Admin panel cannot fetch user data for orders

  2. Solution
    - Add company_name column to orders table if it doesn't exist
    - Ensure proper foreign key relationships between orders and users
    - Create indexes for better performance

  3. Changes
    - Add company_name column to orders table
    - Add indexes on user_id, package_id, and state_id columns
*/

-- Add company_name column to orders table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'orders' AND column_name = 'company_name'
  ) THEN
    ALTER TABLE orders ADD COLUMN company_name text DEFAULT '';
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS orders_user_id_idx ON orders(user_id);
CREATE INDEX IF NOT EXISTS orders_package_id_idx ON orders(package_id);
CREATE INDEX IF NOT EXISTS orders_state_id_idx ON orders(state_id);
CREATE INDEX IF NOT EXISTS orders_status_idx ON orders(status);
CREATE INDEX IF NOT EXISTS orders_payment_status_idx ON orders(payment_status);
CREATE INDEX IF NOT EXISTS orders_created_at_idx ON orders(created_at);

-- Ensure foreign key relationships are properly established
DO $$
BEGIN
  -- Check if the foreign key constraint already exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'orders_user_id_fkey'
    AND table_name = 'orders'
  ) THEN
    -- Add the foreign key constraint to link orders.user_id to auth.users.id
    ALTER TABLE orders 
    ADD CONSTRAINT orders_user_id_fkey 
    FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;