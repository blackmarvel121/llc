/*
  # Initialize Payment Gateways

  1. New Data
    - Add default payment gateway entries for Stripe, Razorpay, PayPal, and Square
    - Set all gateways to disabled by default
    - Provide empty keys that can be configured in the admin panel
    
  2. Security
    - Maintains existing RLS policies
*/

-- Insert default payment gateways if they don't exist
-- Use id as the conflict target since there's no unique constraint on type
INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key, webhook_secret, settings)
VALUES 
  ('Stripe', 'stripe', false, '', '', '', '{}')
ON CONFLICT DO NOTHING;

INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key, webhook_secret, settings)
VALUES 
  ('Razorpay', 'razorpay', false, '', '', '', '{}')
ON CONFLICT DO NOTHING;

INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key, webhook_secret, settings)
VALUES 
  ('PayPal', 'paypal', false, '', '', '', '{}')
ON CONFLICT DO NOTHING;

INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key, webhook_secret, settings)
VALUES 
  ('Square', 'square', false, '', '', '', '{}')
ON CONFLICT DO NOTHING;