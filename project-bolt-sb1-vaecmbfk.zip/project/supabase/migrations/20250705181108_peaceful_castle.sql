/*
  # Fix Settings Table and Permissions

  1. Changes
    - Consolidate all settings into a single 'global' record
    - Fix RLS policies to prevent permission denied errors
    - Ensure all settings fields are properly defined
    - Remove references to the users table in policies

  2. Security
    - Simplify RLS policies to avoid recursion
    - Maintain public read access to settings
    - Restrict write access to admin users only
*/

-- First, ensure we have a single global settings record with all fields
INSERT INTO settings (
  key, 
  announcement_enabled, 
  announcement_text, 
  whatsapp_enabled, 
  whatsapp_number, 
  whatsapp_message,
  popup_enabled,
  popup_title,
  popup_subtitle,
  popup_offer_text,
  popup_cta_text,
  popup_disclaimer
)
VALUES (
  'global',
  true,
  '✅ 24-Hour LLC Guarantee by Razorfile',
  true,
  '+1234567890',
  'Hi! I need help with LLC formation.',
  false,
  '🔥 Professional LLC Formation',
  'Don''t miss out! Get your LLC formed professionally when you start today. This exclusive offer expires soon!',
  'Professional LLC Formation Service',
  '🚀 Start My LLC Now - Only $49',
  '* Limited time offer. Offer valid for new customers only.'
)
ON CONFLICT (key) DO UPDATE SET
  announcement_enabled = EXCLUDED.announcement_enabled,
  announcement_text = EXCLUDED.announcement_text,
  whatsapp_enabled = EXCLUDED.whatsapp_enabled,
  whatsapp_number = EXCLUDED.whatsapp_number,
  whatsapp_message = EXCLUDED.whatsapp_message,
  popup_enabled = EXCLUDED.popup_enabled,
  popup_title = EXCLUDED.popup_title,
  popup_subtitle = EXCLUDED.popup_subtitle,
  popup_offer_text = EXCLUDED.popup_offer_text,
  popup_cta_text = EXCLUDED.popup_cta_text,
  popup_disclaimer = EXCLUDED.popup_disclaimer;

-- Delete any other settings records to avoid confusion
DELETE FROM settings WHERE key != 'global';

-- Drop all existing policies on settings table to start fresh
DROP POLICY IF EXISTS "Admins can delete settings" ON settings;
DROP POLICY IF EXISTS "Admins can insert settings" ON settings;
DROP POLICY IF EXISTS "Admins can update settings" ON settings;
DROP POLICY IF EXISTS "Admins can manage settings" ON settings;
DROP POLICY IF EXISTS "Anyone can read settings" ON settings;

-- Create simplified policies that won't cause permission issues
-- Allow anyone to read settings
CREATE POLICY "Anyone can read settings"
  ON settings
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Allow admins to manage settings
CREATE POLICY "Admins can manage settings"
  ON settings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.user_id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );