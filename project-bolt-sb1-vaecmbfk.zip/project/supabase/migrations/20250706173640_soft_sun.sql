/*
  # Fix Razorpay Integration

  1. Changes
    - Update payment_gateways table to ensure Razorpay is properly configured
    - Add indexes for better performance
    - Ensure webhook_secret field is properly set
    
  2. Security
    - Maintains existing RLS policies
*/

-- Update Razorpay gateway configuration
UPDATE payment_gateways
SET enabled = true,
    name = 'Razorpay',
    settings = jsonb_build_object(
      'currency', 'INR',
      'description', 'LLC Formation Services',
      'theme_color', '#3B82F6'
    )
WHERE type = 'razorpay';

-- Create a function to handle Razorpay webhook events
CREATE OR REPLACE FUNCTION handle_razorpay_webhook(payload JSONB)
RETURNS JSONB AS $$
DECLARE
  event_type TEXT;
  payment_id TEXT;
  order_id TEXT;
  payment_status TEXT;
  db_order_id UUID;
BEGIN
  -- Extract event type and payment details
  event_type := payload->>'event';
  payment_id := payload->'payload'->'payment'->'entity'->>'id';
  order_id := payload->'payload'->'payment'->'entity'->>'order_id';
  
  -- Log the event
  INSERT INTO payment_events (
    gateway, 
    event_type, 
    payment_id, 
    order_id, 
    amount, 
    status, 
    raw_data
  ) VALUES (
    'razorpay',
    event_type,
    payment_id,
    order_id,
    (payload->'payload'->'payment'->'entity'->>'amount')::numeric / 100,
    payload->'payload'->'payment'->'entity'->>'status',
    payload
  );
  
  -- Handle different event types
  IF event_type = 'payment.authorized' OR event_type = 'payment.captured' THEN
    payment_status := 'paid';
    
    -- Update the order status
    UPDATE orders
    SET payment_status = payment_status,
        status = 'processing'
    WHERE payment_id = order_id
    RETURNING id INTO db_order_id;
    
    -- Return success response
    RETURN jsonb_build_object(
      'success', TRUE,
      'message', 'Payment processed successfully',
      'order_id', db_order_id
    );
  ELSIF event_type = 'payment.failed' THEN
    payment_status := 'failed';
    
    -- Update the order status
    UPDATE orders
    SET payment_status = payment_status
    WHERE payment_id = order_id
    RETURNING id INTO db_order_id;
    
    -- Return failure response
    RETURN jsonb_build_object(
      'success', TRUE,
      'message', 'Payment failed',
      'order_id', db_order_id
    );
  ELSE
    -- Unhandled event type
    RETURN jsonb_build_object(
      'success', TRUE,
      'message', 'Unhandled event type: ' || event_type
    );
  END IF;
  
EXCEPTION WHEN OTHERS THEN
  -- Return error response
  RETURN jsonb_build_object(
    'success', FALSE,
    'message', 'Error processing webhook: ' || SQLERRM
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create indexes for better performance if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'orders_payment_id_idx'
  ) THEN
    CREATE INDEX orders_payment_id_idx ON orders(payment_id);
  END IF;
END $$;