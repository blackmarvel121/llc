/*
  # Fix infinite recursion in settings table RLS policies

  1. Problem
    - The current RLS policy for settings table creates infinite recursion
    - When querying settings, it checks profiles table for admin role
    - This creates a circular dependency

  2. Solution
    - Simplify the settings table policies
    - Remove the admin check from the SELECT policy for settings
    - Allow anyone to read settings since they contain public configuration
    - Keep admin-only policies for INSERT/UPDATE/DELETE operations
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Admins can manage settings" ON settings;
DROP POLICY IF EXISTS "Anyone can read settings" ON settings;

-- Create new simplified policies
CREATE POLICY "Anyone can read settings"
  ON settings
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Admins can insert settings"
  ON settings
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.email IN (
        SELECT email FROM profiles 
        WHERE profiles.user_id = auth.uid() 
        AND profiles.role = 'admin'
      )
    )
  );

CREATE POLICY "Admins can update settings"
  ON settings
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.email IN (
        SELECT email FROM profiles 
        WHERE profiles.user_id = auth.uid() 
        AND profiles.role = 'admin'
      )
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.email IN (
        SELECT email FROM profiles 
        WHERE profiles.user_id = auth.uid() 
        AND profiles.role = 'admin'
      )
    )
  );

CREATE POLICY "Admins can delete settings"
  ON settings
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.email IN (
        SELECT email FROM profiles 
        WHERE profiles.user_id = auth.uid() 
        AND profiles.role = 'admin'
      )
    )
  );

-- Insert default settings if they don't exist
INSERT INTO settings (key, announcement_enabled, announcement_text, whatsapp_enabled, whatsapp_number, whatsapp_message)
VALUES (
  'global',
  true,
  '✅ 24-Hour LLC Guarantee by Razorfile',
  true,
  '+1234567890',
  'Hi! I need help with LLC formation.'
)
ON CONFLICT (key) DO NOTHING;