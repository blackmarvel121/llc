/*
  # Create payment gateways table

  1. New Tables
    - `payment_gateways`
      - `id` (uuid, primary key)
      - `name` (text)
      - `type` (text) - stripe, razorpay, paypal, square
      - `enabled` (boolean)
      - `public_key` (text)
      - `secret_key` (text)
      - `webhook_secret` (text, optional)
      - `settings` (jsonb, optional)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `payment_gateways` table
    - Add policies for admin access only

  3. Default Data
    - Insert default payment gateways
*/

-- Create payment_gateways table if it doesn't exist
CREATE TABLE IF NOT EXISTS payment_gateways (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('stripe', 'razorpay', 'paypal', 'square')),
  enabled boolean DEFAULT false,
  public_key text DEFAULT '',
  secret_key text DEFAULT '',
  webhook_secret text DEFAULT '',
  settings jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE payment_gateways ENABLE ROW LEVEL SECURITY;

-- Create policy for admin access
CREATE POLICY "Admins can manage payment gateways"
  ON payment_gateways
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.user_id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Create trigger for updated_at
CREATE TRIGGER update_payment_gateways_updated_at
  BEFORE UPDATE ON payment_gateways
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert default payment gateways
INSERT INTO payment_gateways (name, type, enabled, public_key, secret_key) 
VALUES 
  ('Stripe', 'stripe', false, '', ''),
  ('Razorpay', 'razorpay', false, '', ''),
  ('PayPal', 'paypal', false, '', '')
ON CONFLICT (id) DO NOTHING;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS payment_gateways_type_idx ON payment_gateways(type);
CREATE INDEX IF NOT EXISTS payment_gateways_enabled_idx ON payment_gateways(enabled);