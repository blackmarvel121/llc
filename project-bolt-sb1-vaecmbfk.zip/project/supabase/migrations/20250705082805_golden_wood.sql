/*
  # Fix Foreign Key Relationships

  1. Foreign Keys
    - Add foreign key from `affiliate_links.user_id` to `auth.users.id`
    - Add foreign key from `compliance_tasks.user_id` to `auth.users.id`
  
  2. Security
    - Maintains referential integrity with Supabase auth system
    - Ensures cascade deletion when users are deleted
*/

-- Add foreign key constraint from affiliate_links to auth.users
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'affiliate_links_user_id_fkey'
    AND table_name = 'affiliate_links'
  ) THEN
    ALTER TABLE affiliate_links 
    ADD CONSTRAINT affiliate_links_user_id_fkey 
    FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Add foreign key constraint from compliance_tasks to auth.users  
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'compliance_tasks_user_id_fkey'
    AND table_name = 'compliance_tasks'
  ) THEN
    ALTER TABLE compliance_tasks 
    ADD CONSTRAINT compliance_tasks_user_id_fkey 
    FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;