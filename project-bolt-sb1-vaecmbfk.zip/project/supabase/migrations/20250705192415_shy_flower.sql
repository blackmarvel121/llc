/*
  # Fix Database Schema and Settings

  1. Settings Consolidation
    - Ensure a single 'global' settings record exists with all required fields
    - Remove any duplicate settings records
    - Update all components to use the global settings record

  2. Foreign Key Relationships
    - Fix relationships for affiliate_links and compliance_tasks tables
    - Ensure proper references to auth.users

  3. User Creation Function
    - Update handle_new_user function to properly handle user metadata
    - Fix profile creation on user signup

  4. RLS Policies
    - Simplify Row Level Security policies to avoid recursion issues
    - Ensure proper access control for all tables
*/

-- First, ensure we have a single global settings record with all fields
INSERT INTO settings (
  key, 
  announcement_enabled, 
  announcement_text, 
  whatsapp_enabled, 
  whatsapp_number, 
  whatsapp_message,
  popup_enabled,
  popup_title,
  popup_subtitle,
  popup_offer_text,
  popup_cta_text,
  popup_disclaimer
)
VALUES (
  'global',
  true,
  '✅ 24-Hour LLC Guarantee by Razorfile',
  true,
  '+1234567890',
  'Hi! I need help with LLC formation.',
  false,
  '🔥 Professional LLC Formation',
  'Don''t miss out! Get your LLC formed professionally when you start today. This exclusive offer expires soon!',
  'Professional LLC Formation Service',
  '🚀 Start My LLC Now - Only $49',
  '* Limited time offer. Offer valid for new customers only.'
)
ON CONFLICT (key) DO UPDATE SET
  announcement_enabled = EXCLUDED.announcement_enabled,
  announcement_text = EXCLUDED.announcement_text,
  whatsapp_enabled = EXCLUDED.whatsapp_enabled,
  whatsapp_number = EXCLUDED.whatsapp_number,
  whatsapp_message = EXCLUDED.whatsapp_message,
  popup_enabled = EXCLUDED.popup_enabled,
  popup_title = EXCLUDED.popup_title,
  popup_subtitle = EXCLUDED.popup_subtitle,
  popup_offer_text = EXCLUDED.popup_offer_text,
  popup_cta_text = EXCLUDED.popup_cta_text,
  popup_disclaimer = EXCLUDED.popup_disclaimer;

-- Delete any other settings records to avoid confusion
DELETE FROM settings WHERE key != 'global';

-- Drop all existing policies on settings table to start fresh
DROP POLICY IF EXISTS "Admins can delete settings" ON settings;
DROP POLICY IF EXISTS "Admins can insert settings" ON settings;
DROP POLICY IF EXISTS "Admins can update settings" ON settings;
DROP POLICY IF EXISTS "Admins can manage settings" ON settings;
DROP POLICY IF EXISTS "Anyone can read settings" ON settings;

-- Create simplified policies that won't cause permission issues
-- Allow anyone to read settings
CREATE POLICY "Anyone can read settings"
  ON settings
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Allow admins to manage settings
CREATE POLICY "Admins can manage settings"
  ON settings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.user_id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Update the handle_new_user function to ensure it works correctly with metadata
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, first_name, last_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'first_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'last_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'role', 'user')
  )
  ON CONFLICT (user_id) DO UPDATE SET
    email = EXCLUDED.email,
    first_name = EXCLUDED.first_name,
    last_name = EXCLUDED.last_name;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Ensure the trigger is properly set up
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Fix foreign key relationships for affiliate_links and compliance_tasks
-- First, try to fix affiliate_links
DO $$
BEGIN
  -- Drop existing constraint if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'affiliate_links_user_id_fkey'
    AND table_name = 'affiliate_links'
  ) THEN
    ALTER TABLE affiliate_links DROP CONSTRAINT affiliate_links_user_id_fkey;
  END IF;

  -- Add constraint to auth.users
  ALTER TABLE affiliate_links 
  ADD CONSTRAINT affiliate_links_user_id_fkey 
  FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Error fixing affiliate_links constraint: %', SQLERRM;
END $$;

-- Fix compliance_tasks
DO $$
BEGIN
  -- Drop existing constraint if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'compliance_tasks_user_id_fkey'
    AND table_name = 'compliance_tasks'
  ) THEN
    ALTER TABLE compliance_tasks DROP CONSTRAINT compliance_tasks_user_id_fkey;
  END IF;

  -- Add constraint to auth.users
  ALTER TABLE compliance_tasks 
  ADD CONSTRAINT compliance_tasks_user_id_fkey 
  FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Error fixing compliance_tasks constraint: %', SQLERRM;
END $$;

-- Fix any issues with the profiles table
DO $$
BEGIN
  -- Ensure email is unique
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'profiles_email_key'
    AND table_name = 'profiles'
  ) THEN
    ALTER TABLE profiles ADD CONSTRAINT profiles_email_key UNIQUE (email);
  END IF;

  -- Ensure user_id is unique
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'profiles_user_id_key'
    AND table_name = 'profiles'
  ) THEN
    ALTER TABLE profiles ADD CONSTRAINT profiles_user_id_key UNIQUE (user_id);
  END IF;
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Error fixing profiles constraints: %', SQLERRM;
END $$;