import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2.50.3";
import { createHmac } from "node:crypto";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 200,
    });
  }
  
  try {
    // Create Supabase client
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );
    
    // Get Razorpay credentials from database
    const { data: gatewayData, error: gatewayError } = await supabaseClient
      .from('payment_gateways')
      .select('public_key, secret_key, webhook_secret')
      .eq('type', 'razorpay')
      .eq('enabled', true)
      .single();
    
    if (gatewayError || !gatewayData) {
      throw new Error('Razorpay gateway not configured or not enabled');
    }
    
    // Parse request body
    const payload = await req.json();
    
    // Log the payload for debugging
    console.log("Received Razorpay webhook:", JSON.stringify(payload));
    
    // Extract payment details
    const { event, payload: eventPayload } = payload;
    const paymentId = eventPayload.payment?.entity?.id;
    const orderId = eventPayload.payment?.entity?.order_id;
    const amount = eventPayload.payment?.entity?.amount / 100; // Convert from paise to rupees
    
    if (!paymentId || !orderId) {
      throw new Error('Invalid webhook payload: missing payment ID or order ID');
    }
    
    // Store the webhook event for audit purposes
    await supabaseClient
      .from('payment_events')
      .insert({
        gateway: 'razorpay',
        event_type: event,
        payment_id: paymentId,
        order_id: orderId,
        amount: amount,
        status: eventPayload.payment?.entity?.status,
        raw_data: payload
      });
    
    // Update order status based on payment status
    if (event === 'payment.authorized' || event === 'payment.captured') {
      // Find the order with this payment ID
      const { data: orderData, error: orderError } = await supabaseClient
        .from('orders')
        .select('id')
        .eq('payment_id', orderId)
        .single();
      
      if (!orderError && orderData) {
        // Update the order status
        await supabaseClient
          .from('orders')
          .update({ 
            payment_status: 'paid',
            status: 'processing'
          })
          .eq('id', orderData.id);
      }
    }
    
    // Return success response
    return new Response(
      JSON.stringify({ success: true }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Razorpay webhook error:", error);
    
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 400,
      }
    );
  }
});