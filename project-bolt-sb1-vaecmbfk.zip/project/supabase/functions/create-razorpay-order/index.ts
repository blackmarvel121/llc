import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2.50.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 200,
    });
  }
  
  try {
    // Create Supabase client
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );
    
    // Get Razorpay keys from database
    const { data: gatewayData, error: gatewayError } = await supabaseClient
      .from('payment_gateways')
      .select('public_key, secret_key')
      .eq('type', 'razorpay')
      .eq('enabled', true)
      .single();
    
    if (gatewayError) {
      console.error('Database error:', gatewayError);
      throw new Error('Error fetching Razorpay configuration');
    }
    
    if (!gatewayData) {
      throw new Error('Razorpay gateway not configured or not enabled');
    }
    
    if (!gatewayData.public_key || !gatewayData.secret_key) {
      throw new Error('Razorpay API keys not configured');
    }
    
    // Parse request body
    const { amount, currency = 'INR' } = await req.json();
    
    if (!amount) {
      throw new Error('Amount is required');
    }
    
    // Create Razorpay order
    const razorpayUrl = 'https://api.razorpay.com/v1/orders';
    
    // Create Basic Auth header
    const authString = `${gatewayData.public_key}:${gatewayData.secret_key}`;
    const auth = btoa(authString);
    
    const response = await fetch(razorpayUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        amount: Math.round(amount * 100), // Convert to paise
        currency,
        receipt: `receipt_${Date.now()}`,
        payment_capture: 1,
        notes: {
          service: 'LLC Formation'
        }
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      console.error('Razorpay API error:', errorData);
      throw new Error(`Razorpay API error: ${JSON.stringify(errorData)}`);
    }
    
    const orderData = await response.json();
    
    // Return order data
    return new Response(
      JSON.stringify({
        id: orderData.id,
        amount: orderData.amount,
        currency: orderData.currency,
        key: gatewayData.public_key,
        notes: orderData.notes
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 200,
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 400,
      }
    );
  }
});