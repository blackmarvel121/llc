import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2.50.3";
import Stripe from "npm:stripe@14.21.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 200,
    });
  }
  
  try {
    // Create Supabase client
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );
    
    // Get Stripe secret key from database
    const { data: gatewayData, error: gatewayError } = await supabaseClient
      .from('payment_gateways')
      .select('secret_key')
      .eq('type', 'stripe')
      .eq('enabled', true)
      .single();
    
    if (gatewayError) {
      console.error('Database error:', gatewayError);
      throw new Error('Error fetching Stripe configuration');
    }
    
    if (!gatewayData) {
      throw new Error('Stripe gateway not configured or not enabled');
    }
    
    if (!gatewayData.secret_key) {
      throw new Error('Stripe secret key not configured');
    }
    
    // Initialize Stripe
    const stripe = new Stripe(gatewayData.secret_key, {
      apiVersion: '2023-10-16',
    });
    
    // Parse request body
    const { amount, currency = 'usd' } = await req.json();
    
    if (!amount) {
      throw new Error('Amount is required');
    }
    
    // Create payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Convert to cents
      currency,
      automatic_payment_methods: {
        enabled: true,
      },
    });
    
    // Return payment intent client secret
    return new Response(
      JSON.stringify({
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id,
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 200,
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 400,
      }
    );
  }
});