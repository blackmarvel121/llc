import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2.50.3";
import { createHmac } from "npm:crypto@1.0.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 200,
    });
  }
  
  try {
    // Create Supabase client
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );
    
    // Get Razorpay secret key from database
    const { data: gatewayData, error: gatewayError } = await supabaseClient
      .from('payment_gateways')
      .select('secret_key, webhook_secret')
      .eq('type', 'razorpay')
      .eq('enabled', true)
      .single();
    
    if (gatewayError) {
      console.error('Database error:', gatewayError);
      throw new Error('Error fetching Razorpay configuration');
    }
    
    if (!gatewayData) {
      throw new Error('Razorpay gateway not configured or not enabled');
    }
    
    if (!gatewayData.secret_key) {
      throw new Error('Razorpay secret key not configured');
    }
    
    // Parse request body
    const { paymentId, orderId, signature, amount } = await req.json();
    
    if (!paymentId || !orderId || !signature) {
      throw new Error('Payment ID, Order ID, and Signature are required');
    }
    
    // Verify signature
    let generatedSignature;
    try {
      generatedSignature = createHmac('sha256', gatewayData.secret_key)
        .update(orderId + "|" + paymentId)
        .digest('hex');
    } catch (error) {
      console.error('Error generating signature:', error);
      throw new Error('Failed to verify payment signature');
    }
    
    const isValid = generatedSignature === signature;
    
    if (!isValid) {
      throw new Error('Invalid signature');
    }
    
    // Return verification result
    return new Response(
      JSON.stringify({
        success: true,
        paymentId,
        orderId,
        amount
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 200,
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 400,
      }
    );
  }
});