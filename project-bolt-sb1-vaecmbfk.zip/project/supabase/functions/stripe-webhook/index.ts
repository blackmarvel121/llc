import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2.50.3";
import Stripe from "npm:stripe@14.21.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 200,
    });
  }
  
  try {
    // Create Supabase client
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );
    
    // Get Stripe credentials from database
    const { data: gatewayData, error: gatewayError } = await supabaseClient
      .from('payment_gateways')
      .select('secret_key, webhook_secret')
      .eq('type', 'stripe')
      .eq('enabled', true)
      .single();
    
    if (gatewayError || !gatewayData) {
      throw new Error('Stripe gateway not configured or not enabled');
    }
    
    // Initialize Stripe
    const stripe = new Stripe(gatewayData.secret_key, {
      apiVersion: '2023-10-16',
    });
    
    // Get the request body and signature header
    const payload = await req.text();
    const signature = req.headers.get('stripe-signature');
    
    if (!signature) {
      throw new Error('Missing Stripe signature header');
    }
    
    // Verify the webhook signature
    let event;
    try {
      event = stripe.webhooks.constructEvent(
        payload,
        signature,
        gatewayData.webhook_secret
      );
    } catch (err) {
      console.error(`Webhook signature verification failed: ${err.message}`);
      throw new Error(`Webhook signature verification failed: ${err.message}`);
    }
    
    // Log the event for debugging
    console.log(`Received Stripe event: ${event.type}`);
    
    // Store the webhook event for audit purposes
    await supabaseClient
      .from('payment_events')
      .insert({
        gateway: 'stripe',
        event_type: event.type,
        payment_id: event.data.object.id,
        amount: event.data.object.amount / 100, // Convert from cents to dollars
        status: event.data.object.status,
        raw_data: event
      });
    
    // Handle different event types
    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      
      // Update order status
      const { data: orderData, error: orderError } = await supabaseClient
        .from('orders')
        .update({ 
          payment_status: 'paid',
          status: 'processing'
        })
        .eq('payment_id', paymentIntent.id)
        .select('id')
        .single();
      
      if (orderError) {
        console.error('Error updating order:', orderError);
      } else {
        console.log(`Updated order ${orderData.id} to paid status`);
      }
    } else if (event.type === 'payment_intent.payment_failed') {
      const paymentIntent = event.data.object;
      
      // Update order status
      const { error: orderError } = await supabaseClient
        .from('orders')
        .update({ payment_status: 'failed' })
        .eq('payment_id', paymentIntent.id);
      
      if (orderError) {
        console.error('Error updating order:', orderError);
      }
    }
    
    // Return a success response to Stripe
    return new Response(JSON.stringify({ received: true }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
      status: 200,
    });
  } catch (error) {
    console.error('Stripe webhook error:', error);
    
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 400,
      }
    );
  }
});