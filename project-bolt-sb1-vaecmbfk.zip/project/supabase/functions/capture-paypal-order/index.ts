import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2.50.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 200,
    });
  }
  
  try {
    // Create Supabase client
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );
    
    // Get PayPal credentials from database
    const { data: gatewayData, error: gatewayError } = await supabaseClient
      .from('payment_gateways')
      .select('public_key, secret_key')
      .eq('type', 'paypal')
      .eq('enabled', true)
      .single();
    
    if (gatewayError || !gatewayData) {
      throw new Error('PayPal gateway not configured');
    }
    
    // Parse request body
    const { orderId } = await req.json();
    
    if (!orderId) {
      throw new Error('Order ID is required');
    }
    
    // Capture PayPal order
    const paypalUrl = `https://api-m.sandbox.paypal.com/v2/checkout/orders/${orderId}/capture`;
    const auth = btoa(`${gatewayData.public_key}:${gatewayData.secret_key}`);
    
    const response = await fetch(paypalUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`PayPal API error: ${JSON.stringify(errorData)}`);
    }
    
    const captureData = await response.json();
    
    // Return capture data
    return new Response(
      JSON.stringify({
        id: captureData.id,
        status: captureData.status,
        paymentId: captureData.purchase_units[0]?.payments?.captures[0]?.id
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 200,
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 400,
      }
    );
  }
});