// This file handles payment gateway functionality

import { supabase } from './supabase';

export interface PaymentGateway {
  id: string;
  name: string;
  type: 'stripe' | 'razorpay' | 'paypal' | 'square';
  enabled: boolean;
  public_key: string;
  settings: any;
}

// Fetch all enabled payment gateways
export const getEnabledPaymentGateways = async (): Promise<PaymentGateway[]> => {
  try {
    const { data, error } = await supabase
      .from('payment_gateways')
      .select('*');
    
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching payment gateways:', error);
    return [];
  }
};

// Get a specific payment gateway by type
export const getPaymentGateway = async (type: string): Promise<PaymentGateway | null> => {
  try {
    const { data, error } = await supabase
      .from('payment_gateways')
      .select('*')
      .eq('type', type)
      .single();
    
    if (error) throw error;
    return data;
  } catch (error) {
    console.error(`Error fetching ${type} gateway:`, error);
    return null;
  }
};

// Update payment gateway status
export const updatePaymentGatewayStatus = async (id: string, enabled: boolean): Promise<boolean> => {
  try {
    const { error } = await supabase
      .from('payment_gateways')
      .update({ enabled })
      .eq('id', id);
    
    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error updating payment gateway status:', error);
    return false;
  }
};