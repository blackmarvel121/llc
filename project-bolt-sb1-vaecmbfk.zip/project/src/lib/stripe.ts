// This file will handle Stripe integration
// We'll use the Supabase Edge Functions to securely handle payments

interface CreatePaymentIntentResponse {
  clientSecret: string;
  paymentIntentId: string;
}

export const createPaymentIntent = async (amount: number, currency: string = 'usd') => {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-payment-intent`;
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        amount,
        currency
      })
    });
    
    if (!response.ok) {
      throw new Error('Failed to create payment intent');
    }
    
    const data: CreatePaymentIntentResponse = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating payment intent:', error);
    throw error;
  }
};

export const confirmPayment = async (paymentIntentId: string, paymentMethodId: string) => {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/confirm-payment`;
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        paymentIntentId,
        paymentMethodId
      })
    });
    
    if (!response.ok) {
      throw new Error('Failed to confirm payment');
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error confirming payment:', error);
    // Return a standardized error object
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
};