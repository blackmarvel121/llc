// This file will handle Razorpay integration
// We'll use the Supabase Edge Functions to securely handle payments

interface RazorpayOrderResponse {
  id: string;
  amount: number;
  currency: string;
  key: string;
}

export const createRazorpayOrder = async (amount: number, currency: string = 'INR') => {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-razorpay-order`;
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        amount,
        currency
      })
    });
    
    if (!response.ok) {
      throw new Error('Failed to create Razorpay order');
    }
    
    const data: RazorpayOrderResponse = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating Razorpay order:', error);
    throw error;
  }
};

export const verifyRazorpayPayment = async (
  paymentId: string, 
  orderId: string, 
  signature: string,
  amount: number
) => {
  try {
    // Use the new endpoint
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/razorpay-webhook`;
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        paymentId,
        orderId,
        signature,
        amount
      })
    });
    
    if (!response.ok) {
      throw new Error('Failed to verify Razorpay payment');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error verifying Razorpay payment:', error);
    // Return a standardized error object
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
};