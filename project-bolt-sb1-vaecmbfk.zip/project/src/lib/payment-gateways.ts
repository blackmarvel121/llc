// Payment gateway functionality

import { supabase } from './supabase';

export interface PaymentGateway {
  id: string;
  name: string;
  type: 'stripe' | 'razorpay' | 'paypal' | 'square';
  enabled: boolean;
  public_key: string;
  settings: any;
}

// Fetch all enabled payment gateways
export const getEnabledPaymentGateways = async (): Promise<PaymentGateway[]> => {
  try {
    const { data, error } = await supabase
      .from('payment_gateways')
      .select('*')
      .eq('enabled', true);
    
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching payment gateways:', error);
    return [];
  }
};

// Get a specific payment gateway by type
export const getPaymentGateway = async (type: string): Promise<PaymentGateway | null> => {
  try {
    const { data, error } = await supabase
      .from('payment_gateways')
      .select('*')
      .eq('type', type)
      .eq('enabled', true)
      .single();
    
    if (error) throw error;
    return data;
  } catch (error) {
    console.error(`Error fetching ${type} gateway:`, error);
    return null;
  }
};

// Process a payment with Stripe
export const processStripePayment = async (amount: number, currency: string = 'usd') => {
  try {
    // Get the Stripe gateway
    const gateway = await getPaymentGateway('stripe');
    if (!gateway || !gateway.enabled) {
      throw new Error('Stripe payment gateway is not available');
    }
    
    // Create a payment intent
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-payment-intent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        amount,
        currency
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to create payment intent');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error processing Stripe payment:', error);
    throw error;
  }
};

// Confirm a Stripe payment
export const confirmStripePayment = async (paymentIntentId: string, paymentMethodId: string) => {
  try {
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/confirm-payment`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        paymentIntentId,
        paymentMethodId
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to confirm payment');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error confirming payment:', error);
    throw error;
  }
};