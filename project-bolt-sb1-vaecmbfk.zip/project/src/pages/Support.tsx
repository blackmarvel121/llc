import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { MessageSquare, Phone, Mail, Clock, HelpCircle, FileText, Users, Zap } from 'lucide-react';
import { useWhatsApp } from '../hooks/useWhatsApp';

export const Support: React.FC = () => {
  const { openWhatsApp, isEnabled } = useWhatsApp();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
    alert('Thank you for your message! We\'ll get back to you within 24 hours.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const supportOptions = [
    {
      icon: MessageSquare,
      title: 'Live Chat',
      description: 'Get instant help from our support team',
      action: 'Start Chat',
      available: '24/7',
      color: 'bg-green-100 text-green-600',
      onClick: isEnabled ? openWhatsApp : undefined
    },
    {
      icon: Phone,
      title: 'Phone Support',
      description: 'Speak directly with our LLC experts',
      action: 'Call Now',
      available: 'Mon-Fri 9AM-6PM EST',
      color: 'bg-blue-100 text-blue-600',
      onClick: () => window.open('tel:1-800-RAZORFILE', '_self')
    },
    {
      icon: Mail,
      title: 'Email Support',
      description: 'Send us a detailed message',
      action: 'Send Email',
      available: 'Response within 24 hours',
      color: 'bg-purple-100 text-purple-600',
      onClick: () => window.open('mailto:support@razorfile.com', '_self')
    }
  ];

  const faqs = [
    {
      question: 'How long does LLC formation take?',
      answer: 'We guarantee to file your LLC within 24 hours. State processing times vary from 1-10 business days depending on the state.'
    },
    {
      question: 'What happens after I place my order?',
      answer: 'You\'ll receive an order confirmation immediately. We\'ll prepare and file your documents within 24 hours and keep you updated throughout the process.'
    },
    {
      question: 'Do you offer refunds?',
      answer: 'Yes! We offer a 30-day money-back guarantee on our service fees. State filing fees paid to government agencies are non-refundable.'
    },
    {
      question: 'Can I track my order status?',
      answer: 'Absolutely! You can track your order status in real-time through your account dashboard. You\'ll also receive email updates at each step.'
    },
    {
      question: 'What if my LLC application is rejected?',
      answer: 'While rejections are rare, if it happens, we\'ll work with you to resolve any issues and refile at no additional charge.'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <HelpCircle className="h-4 w-4" />
            <span>We're Here to Help</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Get Support for Your LLC Formation
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Our expert team is available 24/7 to help you with any questions about LLC formation, 
            compliance, or our services. Choose your preferred way to get in touch.
          </p>
        </div>

        {/* Support Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {supportOptions.map((option, index) => {
            const Icon = option.icon;
            return (
              <Card key={index} className="text-center hover:shadow-lg transition-all duration-300">
                <div className={`w-16 h-16 ${option.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <Icon className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {option.title}
                </h3>
                <p className="text-gray-600 mb-4">
                  {option.description}
                </p>
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-500 mb-4">
                  <Clock className="h-4 w-4" />
                  <span>{option.available}</span>
                </div>
                {option.onClick && (
                  <Button 
                    onClick={option.onClick}
                    className="w-full"
                  >
                    {option.action}
                  </Button>
                )}
              </Card>
            );
          })}
        </div>

        {/* Contact Form */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <Card>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Send Us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Name
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Subject
                </label>
                <select
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select a topic</option>
                  <option value="llc-formation">LLC Formation Question</option>
                  <option value="order-status">Order Status</option>
                  <option value="billing">Billing & Payments</option>
                  <option value="documents">Documents & Filing</option>
                  <option value="compliance">Compliance & Requirements</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Message
                </label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  rows={5}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Please describe your question or issue in detail..."
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Send Message
              </Button>
            </form>
          </Card>

          <div className="space-y-8">
            {/* Quick Stats */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Our Support Promise
              </h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <Zap className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">24-Hour Response</p>
                    <p className="text-sm text-gray-600">We respond to all inquiries within 24 hours</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <Users className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Expert Team</p>
                    <p className="text-sm text-gray-600">LLC formation specialists ready to help</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                    <FileText className="h-4 w-4 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Comprehensive Help</p>
                    <p className="text-sm text-gray-600">From formation to compliance guidance</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Contact Info */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Contact Information
              </h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-gray-400" />
                  <span className="text-gray-700">1-800-RAZORFILE</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-gray-400" />
                  <span className="text-gray-700">support@razorfile.com</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Clock className="h-5 w-5 text-gray-400" />
                  <span className="text-gray-700">Mon-Fri: 9 AM - 6 PM EST</span>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* FAQ Section */}
        <Card>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="border-b border-gray-200 pb-6 last:border-b-0">
                <h3 className="font-semibold text-gray-900 mb-2">
                  {faq.question}
                </h3>
                <p className="text-gray-600">
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};