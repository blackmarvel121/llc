import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { supabase, signIn, signUp } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useEffect, useCallback } from 'react';

export const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [pendingOrder, setPendingOrder] = useState<any>(null);
  
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  React.useEffect(() => {
    if (isAuthenticated) {
      // If there's a pending order, create it and navigate to orders
      const orderData = localStorage.getItem('pendingOrder');
      if (orderData) {
        navigate('/dashboard/orders');
      } else {
        navigate('/dashboard');
      }
    }
  }, [isAuthenticated, navigate]);

  // Function to create order after successful authentication
  const createOrderAfterAuth = useCallback(async (userId: string) => {
    if (!pendingOrder) return;
    
    console.log('Creating order after auth:', pendingOrder);
    
    try {
      // Get company and personal info from pendingOrder
      const companyInfo = pendingOrder?.companyInfo || {};
      const personalInfo = pendingOrder?.personalInfo || {};
      
      // Create the order
      const { data: order, error } = await supabase
        .from('orders')
        .insert([{
          user_id: userId,
          package_id: pendingOrder.packageId,
          state_id: pendingOrder.stateId,
          status: 'processing',
          payment_status: 'paid',
          status: 'pending',
          payment_status: 'pending',
          total_amount: pendingOrder.totalAmount * 100, // Store in cents
          company_name: companyInfo.companyName || '',
          payment_method: 'credit_card',
          payment_id: `pi_${Math.random().toString(36).substring(2, 15)}`
        }])
        .select()
        .single();

      if (error) throw error;
      
      // Add order addons if any
      if (pendingOrder.addons && pendingOrder.addons.length > 0) {
        const orderAddons = pendingOrder.addons.map(addonId => ({
          order_id: order.id,
          addon_id: addonId,
          price: 0 // We'll update this later
        }));

        await supabase.from('order_addons').insert(orderAddons);
      }
      
      // Clear pending order from localStorage
      localStorage.removeItem('pendingOrder');
      localStorage.removeItem('checkoutEmail');
      localStorage.removeItem('checkoutName');
      
    } catch (error) {
      console.error('Error creating order after auth:', error);
    }
  }, [pendingOrder, supabase]);

  // Check for checkout email and name in localStorage
  useEffect(() => {
    const checkoutEmail = localStorage.getItem('checkoutEmail');
    const checkoutName = localStorage.getItem('checkoutName');
    const orderData = localStorage.getItem('pendingOrder');
    
    if (orderData) {
      try {
        setPendingOrder(JSON.parse(orderData));
        setMessage('Please create an account or sign in to complete your order');
      } catch (e) {
        console.error('Error parsing pending order:', e);
      }
    }
    
    if (checkoutEmail) {
      setEmail(checkoutEmail);
      if (!message) setMessage('Please create an account to track your order');
      setIsLogin(false);
      
      if (checkoutName) {
        const [first, ...rest] = checkoutName.split(' ');
        setFirstName(first || '');
        setLastName(rest.join(' ') || '');
      }
    }
  }, [message]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (isLogin) {
        await signIn(email, password);

        const { data } = await supabase.auth.getUser();
        if (data.user && pendingOrder) {
          await createOrderAfterAuth(data.user.id);
          navigate('/dashboard/orders');
        } else {
          navigate('/dashboard');
        }
      } else {
        if (password !== confirmPassword) {
          throw new Error('Passwords do not match');
        }
        const { data } = await signUp(email, password, {
          first_name: firstName,
          last_name: lastName,
        });
        
        if (data.user && pendingOrder) {
          await createOrderAfterAuth(data.user.id);
          navigate('/dashboard/orders');
        } else {
          navigate('/dashboard');
        }
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full">
        <Card>
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">
              {pendingOrder 
                ? 'Complete Your Order' 
                : (isLogin ? 'Sign in to your account' : 'Create your account')}
            </h2>
            <p className="text-gray-600 mt-2">
              {pendingOrder 
                ? 'Create an account or sign in to track your order' 
                : (isLogin ? 'Welcome back!' : 'Get started with your LLC formation')}
            </p>
            
            {message && (
              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-blue-700 text-sm">{message}</p>
              </div>
            )}
            
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    First Name
                  </label>
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Last Name
                  </label>
                  <input
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
                minLength={6}
              />
            </div>

            {!isLogin && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                  minLength={6}
                />
              </div>
            )}

            <Button type="submit" className="w-full" loading={loading}>
              {isLogin 
                ? (pendingOrder ? 'Sign In & Complete Order' : 'Sign In') 
                : (pendingOrder ? 'Create Account & Complete Order' : 'Create Account')}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => setIsLogin(!isLogin)}
              className="text-blue-600 hover:text-blue-500"
            >
              {isLogin
                ? "Don't have an account? Sign up"
                : 'Already have an account? Sign in'}
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
};