import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import { Addon } from '../../types';
import { CheckCircle, Clock, AlertTriangle, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ComplianceTask {
  id: string;
  title: string;
  description: string;
  due_date: string;
  is_completed: boolean;
}

export const AddonsCompliance: React.FC = () => {
  const { user } = useAuth();
  const [addons, setAddons] = useState<Addon[]>([]);
  const [userPackages, setUserPackages] = useState<any[]>([]);
  const [complianceTasks, setComplianceTasks] = useState<ComplianceTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [excludedAddonNames] = useState<string[]>([
    'ITIN Application', 
    'Banking Resolution', 
    'Annual Report Filing',
    'Compliance Monitoring',
    'Business License Research',
    'Trademark Search'
  ]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        if (!user) return;
        
        setLoading(true);
        
        // Fetch addons
        const [addonsResponse, tasksResponse, ordersResponse] = await Promise.all([
          supabase.from('addons')
            .select('*')
            .eq('is_active', true)
            .not('name', 'in', `(${excludedAddonNames.map(name => `"${name}"`).join(',')})`),
          supabase.from('compliance_tasks')
            .select('*')
            .eq('user_id', user.id)
            .order('due_date', { ascending: true }),
          supabase.from('orders')
            .select(`
              id,
              package_id,
              packages(id, name, includes_ein, includes_registered_agent, same_day_filing)
            `)
            .eq('user_id', user.id)
            .eq('status', 'completed')
            .order('created_at', { ascending: false })
        ]);

        if (addonsResponse.error) throw addonsResponse.error;
        if (tasksResponse.error) throw tasksResponse.error;
        if (ordersResponse.error) throw ordersResponse.error;

        setAddons(addonsResponse.data || []);
        setComplianceTasks(tasksResponse.data || []);
        setUserPackages(ordersResponse.data || []);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const getTaskStatusIcon = (task: ComplianceTask) => {
    if (task.is_completed) {
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    }
    
    const dueDate = new Date(task.due_date);
    const now = new Date();
    const daysUntilDue = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilDue < 0) {
      return <AlertTriangle className="h-5 w-5 text-red-500" />;
    } else if (daysUntilDue <= 30) {
      return <Clock className="h-5 w-5 text-yellow-500" />;
    } else {
      return <Clock className="h-5 w-5 text-blue-500" />;
    }
  };

  const getTaskStatusText = (task: ComplianceTask) => {
    if (task.is_completed) {
      return 'Completed';
    }
    
    const dueDate = new Date(task.due_date);
    const now = new Date();
    const daysUntilDue = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilDue < 0) {
      return `Overdue by ${Math.abs(daysUntilDue)} days`;
    } else if (daysUntilDue === 0) {
      return 'Due today';
    } else {
      return `Due in ${daysUntilDue} days`;
    }
  };

  // Filter out addons that are already included in the user's packages
  const filteredAddons = addons.filter(addon => {
    // Check if the addon is already included in any of the user's packages
    const isIncluded = userPackages.some(order => {
      const pkg = order.packages;
      if (!pkg) return false;
      
      // Check if the addon is already included in the package
      if (addon.name.toLowerCase().includes('ein') && pkg.includes_ein) return true;
      if (addon.name.toLowerCase().includes('registered agent') && pkg.includes_registered_agent) return true;
      if (addon.name.toLowerCase().includes('expedited') && pkg.same_day_filing) return true;
      
      return false;
    });
    
    // Only show addons that are not already included
    return !isIncluded;
  });

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Add-ons & Compliance</h1>
        <p className="text-gray-600">
          Manage your add-on services and stay compliant with requirements
        </p>
      </div>

      {/* Compliance Tasks */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Compliance Tasks
        </h2>
        {complianceTasks.length === 0 ? (
          <Card className="text-center py-8">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              All caught up!
            </h3>
            <p className="text-gray-600">
              You have no pending compliance tasks
            </p>
          </Card>
        ) : (
          <div className="space-y-4">
            {complianceTasks.map((task) => (
              <Card key={task.id}>
                <div className="flex items-start space-x-4">
                  <div className="mt-1">
                    {getTaskStatusIcon(task)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-gray-900">
                        {task.title}
                      </h3>
                      <span className="text-sm text-gray-600">
                        <span className="font-medium">{getTaskStatusText(task)}</span>
                      </span>
                    </div>
                    <p className="text-gray-600 mt-1">
                      {task.description}
                    </p>
                    <p className="text-sm text-gray-500 mt-2">
                      Due: {new Date(task.due_date).toLocaleDateString()}
                    </p>
                  </div>
                  {!task.is_completed && (
                    <Button 
                      size="sm"
                      onClick={async () => {
                        try {
                          await supabase
                            .from('compliance_tasks')
                            .update({ 
                              is_completed: true,
                              completed_at: new Date().toISOString()
                            })
                            .eq('id', task.id);
                            
                          // Update local state
                          setComplianceTasks(prevTasks => 
                            prevTasks.map(t => 
                              t.id === task.id 
                                ? {...t, is_completed: true, completed_at: new Date().toISOString()} 
                                : t
                            )
                          );
                        } catch (error) {
                          console.error('Error updating task:', error);
                        }
                      }}
                    >
                      Mark Complete
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Available Add-ons */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-900">
            Available Add-ons
          </h2>
          <Button onClick={() => window.location.href = '/checkout'}>
            <Plus className="h-4 w-4 mr-2" />
            Browse All Add-ons
          </Button>
        </div>
        
        {filteredAddons.length === 0 ? (
          <Card className="text-center py-8">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              You have all available add-ons!
            </h3>
            <p className="text-gray-600 mb-6">
              Your current package includes all the essential add-ons.
            </p>
            <Link to="/checkout">
              <Button variant="outline">
                Browse Other Services
              </Button>
            </Link>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAddons.slice(0, 6).map((addon) => (
              // Skip excluded add-ons
              !excludedAddonNames.includes(addon.name) && (
              <Card key={addon.id} className="flex flex-col">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {addon.name}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    {addon.description}
                  </p>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-gray-900">
                      ${addon.price}
                    </span>
                    <span className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded capitalize">
                      {addon.category}
                    </span>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => window.location.href = `/checkout?addon=${addon.id}`}
                >
                  Add to Cart
                </Button>
              </Card>
              )
            ))}
          </div>
        )}
      </div>
    </div>
  );
};