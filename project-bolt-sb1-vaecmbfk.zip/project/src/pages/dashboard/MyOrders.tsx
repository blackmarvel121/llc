import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import { Order } from '../../types'; 
import { Calendar, DollarSign, Package, MapPin, CheckCircle, Clock } from 'lucide-react';
import { OrderStatusTracker } from '../../components/dashboard/OrderStatusTracker';
import { OrderDetails } from '../../components/dashboard/OrderDetails';

export const MyOrders: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true);
        // Get the current user from useAuth hook
        if (!user?.id) return;
        
        const { data, error } = await supabase
          .from('orders')
          .select(`
            *,
            packages(name),
            states(name, code)
          `)
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });

        if (error) throw error;
        setOrders(data || []);
      } catch (error) {
        console.error('Error fetching orders:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [user]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border border-green-200';
      case 'processing':
        return 'bg-blue-100 text-blue-800 border border-blue-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border border-yellow-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border border-gray-200';
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">My Orders</h1>
        <p className="text-gray-600">
          Track and manage your LLC formation orders
        </p>
      </div>

      {orders.length === 0 ? (
        <Card className="text-center py-12">
          <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No orders yet
          </h3>
          <p className="text-gray-600 mb-8">
            Start your LLC formation journey today
          </p>
          <Button onClick={() => navigate('/')}>Start New Order</Button>
        </Card>
      ) : (
        <div className="space-y-6">
          {orders.map((order) => (
            <Card key={order.id}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="bg-blue-100 p-3 rounded-full">
                    {order.status === 'completed' ? (
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    ) : order.status === 'processing' ? (
                      <Clock className="h-6 w-6 text-blue-600" />
                    ) : (
                      <Package className="h-6 w-6 text-blue-600" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {order.packages?.name} Package
                    </h3>
                    <p className="text-gray-600">
                      Order #{order.id.slice(0, 8)}
                    </p>
                    {order.company_name && (
                      <p className="text-sm text-gray-500">
                        {order.company_name}
                      </p>
                    )}
                  </div>
                </div>
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  {order.status === 'processing' && (
                    <span className="ml-1 w-2 h-2 bg-blue-600 rounded-full animate-pulse"></span>
                  )}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">State</p>
                    <p className="font-medium text-gray-900">
                      {order.states?.name || 'Unknown State'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <DollarSign className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Total</p>
                    <p className="font-medium text-gray-900">
                      ${(order.total_amount / 100).toFixed(2)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Calendar className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Order Date</p>
                    <p className="font-medium text-gray-900">
                      {new Date(order.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex space-x-3">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    // Show order details modal or navigate to details page
                    alert(`Order details for ${order.id}`);
                  }}
                >
                  View Details
                </Button>
                {order.status === 'completed' ? (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => navigate(`/dashboard/documents?orderId=${order.id}`)}
                  >
                    Download Documents
                  </Button>
                 ) : (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-blue-600 border-blue-300 hover:bg-blue-50" 
                    onClick={() => setSelectedOrder(order)}
                  >
                    Track Order
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
      
      {/* Order Details Modal */}
      {selectedOrder && (
        <OrderDetails 
          order={selectedOrder} 
          onClose={() => setSelectedOrder(null)} 
        />
      )}
    </div>
  );
};