import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import { Copy, DollarSign, Users, TrendingUp, Gift } from 'lucide-react';

interface AffiliateStats {
  clicks: number;
  conversions: number;
  totalEarned: number;
  commissionRate: number;
}

export const AffiliateProgram: React.FC = () => {
  const { user } = useAuth();
  const [affiliateCode, setAffiliateCode] = useState('');
  const [stats, setStats] = useState<AffiliateStats>({
    clicks: 0,
    conversions: 0,
    totalEarned: 0,
    commissionRate: 10
  });
  const [bonusCode, setBonusCode] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAffiliateData = async () => {
      if (!user) return;
      
      try {
        const { data, error } = await supabase
          .from('affiliate_links')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (error) {
          console.error('Error fetching affiliate data:', error);
          return;
        }

        if (data) {
          setAffiliateCode(data.code);
          setStats({
            clicks: data.clicks,
            conversions: data.conversions,
            totalEarned: data.total_earned,
            commissionRate: data.commission_rate
          });
        } else {
          // User doesn't have an affiliate link yet - could create one here
          console.log('No affiliate link found for user');
        }
      } catch (error) {
        console.error('Error fetching affiliate data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAffiliateData();
  }, [user]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // You could add a toast notification here
  };

  const referralLink = `https://razorfile.com/?ref=${affiliateCode}`;

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Affiliate Program</h1>
        <p className="text-gray-600">
          Earn money by referring customers to Razorfile
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <Users className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Clicks</h3>
            <p className="text-2xl font-bold text-gray-900">{stats.clicks}</p>
          </div>
        </Card>

        <Card className="flex items-center space-x-4">
          <div className="bg-green-100 p-3 rounded-full">
            <TrendingUp className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Conversions</h3>
            <p className="text-2xl font-bold text-gray-900">{stats.conversions}</p>
          </div>
        </Card>

        <Card className="flex items-center space-x-4">
          <div className="bg-yellow-100 p-3 rounded-full">
            <DollarSign className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Earned</h3>
            <p className="text-2xl font-bold text-gray-900">${stats.totalEarned}</p>
          </div>
        </Card>

        <Card className="flex items-center space-x-4">
          <div className="bg-purple-100 p-3 rounded-full">
            <Gift className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Commission Rate</h3>
            <p className="text-2xl font-bold text-gray-900">{stats.commissionRate}%</p>
          </div>
        </Card>
      </div>

      {/* Referral Link */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Your Referral Link
        </h3>
        <div className="flex items-center space-x-3">
          <input
            type="text"
            value={referralLink}
            readOnly
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
          />
          <Button
            variant="outline"
            onClick={() => copyToClipboard(referralLink)}
          >
            <Copy className="h-4 w-4 mr-2" />
            Copy
          </Button>
        </div>
        <p className="text-sm text-gray-600 mt-2">
          Share this link to earn {stats.commissionRate}% commission on every successful referral
        </p>
      </Card>

      {/* Bonus Code */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Bonus Promo Code
        </h3>
        <div className="flex items-center space-x-3">
          <input
            type="text"
            value={bonusCode}
            onChange={(e) => setBonusCode(e.target.value)}
            placeholder="Enter bonus code"
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg"
          />
          <Button>
            Apply Code
          </Button>
        </div>
        <p className="text-sm text-gray-600 mt-2">
          Have a bonus code? Enter it here to unlock special rewards
        </p>
      </Card>

      {/* How it Works */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          How It Works
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-blue-600 font-bold">1</span>
            </div>
            <h4 className="font-medium text-gray-900 mb-2">Share Your Link</h4>
            <p className="text-sm text-gray-600">
              Share your unique referral link with friends and family
            </p>
          </div>
          <div className="text-center">
            <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-green-600 font-bold">2</span>
            </div>
            <h4 className="font-medium text-gray-900 mb-2">They Sign Up</h4>
            <p className="text-sm text-gray-600">
              When someone uses your link to form their LLC
            </p>
          </div>
          <div className="text-center">
            <div className="bg-yellow-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-yellow-600 font-bold">3</span>
            </div>
            <h4 className="font-medium text-gray-900 mb-2">You Earn</h4>
            <p className="text-sm text-gray-600">
              Receive {stats.commissionRate}% commission on their purchase
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
};