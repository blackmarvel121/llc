import React, { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { FileText, Download, Upload, Eye } from 'lucide-react';

interface Document {
  id: string;
  name: string;
  type: string;
  file_url?: string;
  uploaded_at: string;
}

export const MyDocuments: React.FC = () => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId');
  const { user } = useAuth();

  const fetchDocuments = useCallback(async () => {
    try {
      setLoading(true);

      // Check if user is authenticated
      if (!user?.id) return;

      let query = supabase
        .from('documents')
        .select('*')
        .eq('user_id', user.id);

      // If orderId is provided, filter by order_id
      if (orderId) {
        console.log('Filtering documents by order ID:', orderId);
        query = query.eq('order_id', orderId);
      }
      
      const { data, error } = await query.order('uploaded_at', { ascending: false });

      if (error) throw error;
      setDocuments(data || []);
    } catch (error) {
      console.error('Error fetching documents:', error);
    } finally {
      setLoading(false);
    }
  }, [orderId, user]);

  useEffect(() => {
    fetchDocuments();
  }, [fetchDocuments]);

  const getDocumentIcon = (type: string) => {
    switch (type) {
      case 'ein':
        return '🆔';
      case 'articles':
        return '📄';
      case 'operating_agreement':
        return '📋';
      case 'certificate':
        return '🏆';
      default:
        return '📁';
    }
  };

  const getDocumentTypeLabel = (type: string) => {
    switch (type) {
      case 'ein':
        return 'EIN Number';
      case 'articles':
        return 'Articles of Organization';
      case 'operating_agreement':
        return 'Operating Agreement';
      case 'certificate':
        return 'Certificate of Formation';
      default:
        return 'Document';
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-48 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">My Documents</h1>
          <p className="text-gray-600">
            Access and manage your LLC formation documents
          </p>
        </div>
        <Button>
          <Upload className="h-4 w-4 mr-2" />
          Upload Document
        </Button>
      </div>

      {documents.length === 0 ? (
        <Card className="text-center py-12">
          <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No documents yet
          </h3>
          <p className="text-gray-600 mb-6">
            Your LLC formation documents will appear here once they're ready
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {documents.map((document) => (
            <Card key={document.id} className="flex flex-col">
              <div className="flex items-center space-x-3 mb-4">
                <div className="text-2xl">
                  {getDocumentIcon(document.type)}
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">
                    {document.name}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {getDocumentTypeLabel(document.type)}
                  </p>
                </div>
              </div>

              <div className="flex-1 mb-4">
                <p className="text-sm text-gray-600 mb-4">
                  Uploaded on {new Date(document.uploaded_at).toLocaleDateString()}
                </p>
                {document.file_url && (
                  <a 
                    href={document.file_url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-sm text-blue-600 hover:underline"
                  >
                    View Document URL
                  </a>
                )}
              </div>

              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1 hover:bg-blue-50"
                  onClick={() => document.file_url && window.open(document.file_url, '_blank', 'noopener,noreferrer')}
                  disabled={!document.file_url}
                >
                  <Eye className="h-4 w-4 mr-1" />
                  View
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1 hover:bg-green-50"
                  onClick={() => {
                    if (document.file_url) {
                      const link = document.createElement('a');
                      link.href = document.file_url;
                      link.download = document.name;
                      link.target = '_blank';
                      link.rel = 'noopener noreferrer';
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                    }
                  }}
                  disabled={!document.file_url}
                >
                  <Download className="h-4 w-4 mr-1" />
                  Download
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};