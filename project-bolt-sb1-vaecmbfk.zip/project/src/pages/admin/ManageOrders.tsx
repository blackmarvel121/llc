import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { Package, Search, Filter, Eye, Download, DollarSign, FileText, RefreshCw } from 'lucide-react';

interface Order {
  id: string;
  user_id: string;
  total_amount: number;
  status: string;
  payment_status: string;
  created_at: string;
  packages?: { name: string };
  states?: { name: string };
  users?: {
    profiles?: { 
      email: string; 
      first_name?: string; 
      last_name?: string; 
    };
  };
}

export const ManageOrders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showDocumentUpload, setShowDocumentUpload] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [documentForm, setDocumentForm] = useState({
    name: '',
    type: 'other' as 'ein' | 'articles' | 'operating_agreement' | 'certificate' | 'other',
    file_url: ''
  });

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      if (!refreshing) {
        setLoading(true);
      } else {
        setRefreshing(true);
      }
      
      const { data, error } = await supabase
        .from('orders')
        .select(`
          id,
          user_id,
          package_id,
          state_id,
          status,
          payment_status,
          total_amount,
          payment_method,
          payment_id,
          created_at,
          updated_at,
          company_name,
          packages:package_id(name),
          states:state_id(name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setOrders(data || []);
      
      // Fetch user profiles separately for each order
      if (data && data.length > 0) {
        const userIds = data.map(order => order.user_id).filter(Boolean);
        
        if (userIds.length > 0) {
          const { data: profilesData, error: profilesError } = await supabase
            .from('profiles')
            .select('user_id, email, first_name, last_name')
            .in('user_id', userIds);
            
          if (!profilesError && profilesData) {
            // Create a map of user_id to profile data
            const profileMap = profilesData.reduce((map, profile) => {
              map[profile.user_id] = profile;
              return map;
            }, {});
            
            // Add profile data to each order
            const ordersWithProfiles = data.map(order => ({
              ...order,
              profiles: profileMap[order.user_id] || null
            }));
            
            setOrders(ordersWithProfiles);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
      // Don't set empty orders on error to prevent data loss
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleDocumentUpload = async (orderId: string) => {
    try {
      const order = orders.find(o => o.id === orderId);
      if (!order) return;

      const { error } = await supabase
        .from('documents')
        .insert([{
          user_id: order.user_id,
          order_id: orderId,
          name: documentForm.name,
          type: documentForm.type,
          file_url: documentForm.file_url
        }]);

      if (error) throw error;
      
      setShowDocumentUpload(null);
      setDocumentForm({
        name: '',
        type: 'other',
        file_url: ''
      });
      alert('Document uploaded successfully!');
    } catch (error) {
      console.error('Error uploading document:', error);
      alert('Error uploading document');
    }
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.profiles?.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || order.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId);

      if (error) throw error;
      fetchOrders();
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const totalRevenue = orders
    .filter(order => order.payment_status === 'paid')
    .reduce((sum, order) => sum + order.total_amount, 0);

  const handleRefresh = () => {
    fetchOrders();
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Manage Orders</h1>
        <div className="flex justify-between items-center">
          <p className="text-gray-600">
            View and manage all customer orders
          </p>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleRefresh}
            loading={refreshing}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Data
          </Button>
        </div>
      </div>
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <Package className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Orders</h3>
            <p className="text-2xl font-bold text-gray-900">{orders.length}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-green-100 p-3 rounded-full">
            <Package className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Completed</h3>
            <p className="text-2xl font-bold text-gray-900">
              {orders.filter(o => o.status === 'completed').length}
            </p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-yellow-100 p-3 rounded-full">
            <Package className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Processing</h3>
            <p className="text-2xl font-bold text-gray-900">
              {orders.filter(o => o.status === 'processing').length}
            </p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-purple-100 p-3 rounded-full">
            <DollarSign className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Revenue</h3>
            <p className="text-2xl font-bold text-gray-900">
              ${(totalRevenue / 100).toLocaleString()}
            </p>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search orders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="processing">Processing</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Orders Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Order ID</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Customer</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Package</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">State</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Amount</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Payment</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Date</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.map((order) => (
                <tr key={order.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-mono text-sm">
                    #{order.id.slice(0, 8)}
                  </td>
                  <td className="py-3 px-4 max-w-[200px]">
                    <div>
                      <p className="font-medium text-gray-900">
                        {order.company_name || 'Unnamed LLC'}
                      </p>
                      <p className="text-sm text-gray-600 truncate">
                        {order.profiles?.email || 'Unknown User'}
                      </p>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-gray-900">
                    {order.packages?.name || 'Unknown'}
                  </td>
                  <td className="py-3 px-4 text-gray-900">
                    {order.states?.name || 'Unknown State'}
                  </td>
                  <td className="py-3 px-4 font-medium text-gray-900">
                    ${(order.total_amount / 100).toFixed(2)}
                  </td>
                  <td className="py-3 px-4">
                    <select
                      value={order.status}
                      onChange={(e) => handleStatusChange(order.id, e.target.value)}
                      className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}
                    >
                      <option value="pending">Pending</option>
                      <option value="processing">Processing</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getPaymentStatusColor(order.payment_status)}`}>
                      {order.payment_status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-600">
                    {new Date(order.created_at).toLocaleDateString()}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setShowDocumentUpload(order.id)}
                      >
                        <FileText className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Document Upload Modal */}
      {showDocumentUpload && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Upload Document
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Document Name
                </label>
                <input
                  type="text"
                  value={documentForm.name}
                  onChange={(e) => setDocumentForm({ ...documentForm, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Articles of Organization"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Document Type
                </label>
                <select
                  value={documentForm.type}
                  onChange={(e) => setDocumentForm({ ...documentForm, type: e.target.value as any })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="articles">Articles of Organization</option>
                  <option value="ein">EIN Number</option>
                  <option value="operating_agreement">Operating Agreement</option>
                  <option value="certificate">Certificate</option>
                  <option value="other">Other</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  File URL
                </label>
                <input
                  type="url"
                  value={documentForm.file_url}
                  onChange={(e) => setDocumentForm({ ...documentForm, file_url: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="https://example.com/document.pdf"
                />
              </div>
              
              <div className="flex space-x-3">
                <Button onClick={() => handleDocumentUpload(showDocumentUpload)}>
                  Upload Document
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowDocumentUpload(null);
                    setDocumentForm({
                      name: '',
                      type: 'other',
                      file_url: ''
                    });
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};