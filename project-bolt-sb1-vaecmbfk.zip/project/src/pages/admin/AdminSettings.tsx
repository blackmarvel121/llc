import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { Settings, MessageSquare, Bell, Globe, CreditCard, Zap } from 'lucide-react';

interface SettingsData {
  announcement_enabled: boolean;
  announcement_text: string;
  whatsapp_enabled: boolean;
  whatsapp_number: string;
  whatsapp_message: string;
  popup_enabled: boolean;
  popup_title: string;
  popup_subtitle: string;
  popup_offer_text: string;
  popup_cta_text: string;
  popup_disclaimer: string;
  popup_enabled: boolean;
}

export const AdminSettings: React.FC = () => {
  const [settings, setSettings] = useState<SettingsData>({
    announcement_enabled: false,
    announcement_text: '',
    whatsapp_enabled: false,
    whatsapp_number: '',
    whatsapp_message: '',
    popup_enabled: false,
    popup_title: '🔥 Last Chance: FREE EIN Worth $275!',
    popup_subtitle: "Don't miss out! Get your LLC formed with a FREE EIN number (normally $275) when you start today. This exclusive offer expires soon!",
    popup_offer_text: 'FREE EIN Number - Save $275 on federal tax ID',
    popup_cta_text: '🚀 Claim FREE EIN Now - Only $49',
    popup_disclaimer: '* Limited time offer. EIN normally costs $275. Offer valid for new customers only.'
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('settings')
        .select('*')
        .single();

      if (error) throw error;
      if (data) setSettings(data);
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = async () => {
    setSaving(true);
    try {
      // Update only the specific fields we want to change
      const { error: updateError } = await supabase
        .from('settings')
        .update({
          announcement_enabled: settings.announcement_enabled,
          announcement_text: settings.announcement_text,
          whatsapp_enabled: settings.whatsapp_enabled,
          whatsapp_number: settings.whatsapp_number,
          whatsapp_message: settings.whatsapp_message,
          popup_enabled: settings.popup_enabled,
          popup_title: settings.popup_title,
          popup_subtitle: settings.popup_subtitle,
          popup_offer_text: settings.popup_offer_text,
          popup_cta_text: settings.popup_cta_text,
          popup_disclaimer: settings.popup_disclaimer
        })
        .eq('key', 'global');
        
      if (updateError) throw updateError;
      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Error saving settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">System Settings</h1>
        <p className="text-gray-600">Configure system-wide settings and preferences</p>
      </div>

      {/* Announcement Settings */}
      <Card>
        <div className="flex items-center space-x-3 mb-6">
          <Bell className="h-6 w-6 text-gray-600" />
          <h2 className="text-xl font-semibold text-gray-900">Announcement Banner</h2>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="announcement_enabled"
              checked={settings.announcement_enabled}
              onChange={(e) => setSettings({
                ...settings,
                announcement_enabled: e.target.checked
              })}
              className="rounded"
            />
            <label htmlFor="announcement_enabled" className="font-medium text-gray-900">
              Enable announcement banner
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Announcement Text
            </label>
            <input
              type="text"
              value={settings.announcement_text}
              onChange={(e) => setSettings({
                ...settings,
                announcement_text: e.target.value
              })}
              placeholder="Enter announcement text..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </Card>

      {/* WhatsApp Settings */}
      <Card>
        <div className="flex items-center space-x-3 mb-6">
          <MessageSquare className="h-6 w-6 text-gray-600" />
          <h2 className="text-xl font-semibold text-gray-900">WhatsApp Integration</h2>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="whatsapp_enabled"
              checked={settings.whatsapp_enabled}
              onChange={(e) => setSettings({
                ...settings,
                whatsapp_enabled: e.target.checked
              })}
              className="rounded"
            />
            <label htmlFor="whatsapp_enabled" className="font-medium text-gray-900">
              Enable WhatsApp chat button
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              WhatsApp Number
            </label>
            <input
              type="text"
              value={settings.whatsapp_number}
              onChange={(e) => setSettings({
                ...settings,
                whatsapp_number: e.target.value
              })}
              placeholder="+1234567890"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Default Message
            </label>
            <textarea
              value={settings.whatsapp_message}
              onChange={(e) => setSettings({
                ...settings,
                whatsapp_message: e.target.value
              })}
              placeholder="Hi! I need help with LLC formation."
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </Card>

      {/* Urgency Popup Settings */}
      <Card>
        <div className="flex items-center space-x-3 mb-6">
          <Zap className="h-6 w-6 text-gray-600" />
          <h2 className="text-xl font-semibold text-gray-900">Urgency Popup</h2>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="popup_enabled"
              checked={settings.popup_enabled}
              onChange={(e) => setSettings({
                ...settings,
                popup_enabled: e.target.checked
              })}
              className="rounded"
            />
            <label htmlFor="popup_enabled" className="font-medium text-gray-900">
              Enable urgency popup
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Popup Title
            </label>
            <input
              type="text"
              value={settings.popup_title}
              onChange={(e) => setSettings({
                ...settings,
                popup_title: e.target.value
              })}
              placeholder="Enter popup title..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Popup Subtitle
            </label>
            <textarea
              value={settings.popup_subtitle}
              onChange={(e) => setSettings({
                ...settings,
                popup_subtitle: e.target.value
              })}
              placeholder="Enter popup subtitle..."
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Offer Text
            </label>
            <input
              type="text"
              value={settings.popup_offer_text}
              onChange={(e) => setSettings({
                ...settings,
                popup_offer_text: e.target.value
              })}
              placeholder="Enter offer text..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              CTA Button Text
            </label>
            <input
              type="text"
              value={settings.popup_cta_text}
              onChange={(e) => setSettings({
                ...settings,
                popup_cta_text: e.target.value
              })}
              placeholder="Enter CTA text..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Disclaimer Text
            </label>
            <textarea
              value={settings.popup_disclaimer}
              onChange={(e) => setSettings({
                ...settings,
                popup_disclaimer: e.target.value
              })}
              placeholder="Enter disclaimer text..."
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </Card>

      {/* System Information */}
      <Card>
        <div className="flex items-center space-x-3 mb-6">
          <Globe className="h-6 w-6 text-gray-600" />
          <h2 className="text-xl font-semibold text-gray-900">System Information</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-gray-900 mb-2">Database Status</h3>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-green-700">Connected</span>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-900 mb-2">API Status</h3>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-green-700">Operational</span>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-900 mb-2">Last Backup</h3>
            <span className="text-gray-600">2 hours ago</span>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-900 mb-2">Version</h3>
            <span className="text-gray-600">v1.0.0</span>
          </div>
        </div>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} loading={saving}>
          <Settings className="h-4 w-4 mr-2" />
          Save Settings
        </Button>
      </div>
    </div>
  );
};