import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Globe, MapPin, Users, TrendingUp, BarChart3, Filter, RefreshCw } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface GeoData {
  country: string;
  state?: string;
  city?: string;
  visitors: number;
  conversions: number;
  revenue: number;
}

export const GeoTracking: React.FC = () => {
  const [geoData, setGeoData] = useState<GeoData[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [viewType, setViewType] = useState<'country' | 'state' | 'city'>('country');

  useEffect(() => {
    fetchGeoData();
  }, []);

  const fetchGeoData = async () => {
    try {
      if (refreshing) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      
      // Fetch real geo tracking data from the database
      const { data, error } = await supabase
        .from('geo_tracking')
        .select('*')
        .order('visitors', { ascending: false });
      
      if (error) throw error;
      
      if (data && data.length > 0) {
        setGeoData(data);
      } else {
        // If no data, show empty state
        setGeoData([]);
      }
    } catch (error) {
      console.error('Error fetching geo data:', error);
      // Fallback to empty data if there's an error
      setGeoData([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchGeoData();
  };

  const aggregateData = () => {
    const aggregated = new Map<string, GeoData>();

    geoData.forEach(item => {
      let key: string;
      switch (viewType) {
        case 'country':
          key = item.country;
          break;
        case 'state':
          key = `${item.state}, ${item.country}`;
          break;
        case 'city':
          key = `${item.city}, ${item.state}`;
          break;
        default:
          key = item.country;
      }

      if (aggregated.has(key)) {
        const existing = aggregated.get(key)!;
        existing.visitors += item.visitors;
        existing.conversions += item.conversions;
        existing.revenue += item.revenue;
      } else {
        aggregated.set(key, {
          country: item.country,
          state: item.state,
          city: item.city,
          visitors: item.visitors,
          conversions: item.conversions,
          revenue: item.revenue
        });
      }
    });

    return Array.from(aggregated.values()).sort((a, b) => b.visitors - a.visitors);
  };

  const totalVisitors = geoData.reduce((sum, item) => sum + item.visitors, 0);
  const totalConversions = geoData.reduce((sum, item) => sum + item.conversions, 0);
  const totalRevenue = geoData.reduce((sum, item) => sum + item.revenue, 0);
  const conversionRate = totalVisitors > 0 ? (totalConversions / totalVisitors * 100).toFixed(1) : '0';

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Geo Tracking</h1>
          <p className="text-gray-600">Track visitor locations and performance by geography</p>
          <p className="text-sm text-gray-500 mt-1">
            Data is based on completed orders and estimated visitor information
          </p>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleRefresh}
          loading={refreshing}
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh Data
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <Users className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Visitors</h3>
            <p className="text-2xl font-bold text-gray-900">{totalVisitors.toLocaleString()}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-green-100 p-3 rounded-full">
            <TrendingUp className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Conversions</h3>
            <p className="text-2xl font-bold text-gray-900">{totalConversions}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-yellow-100 p-3 rounded-full">
            <BarChart3 className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Conversion Rate</h3>
            <p className="text-2xl font-bold text-gray-900">{conversionRate}%</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-purple-100 p-3 rounded-full">
            <Globe className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Revenue</h3>
            <p className="text-2xl font-bold text-gray-900">${totalRevenue.toLocaleString()}</p>
          </div>
        </Card>
      </div>

      {/* View Controls */}
      <Card>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-gray-500" />
            <span className="font-medium text-gray-900">View by:</span>
          </div>
          <div className="flex space-x-2">
            <Button
              variant={viewType === 'country' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setViewType('country')}
            >
              Country
            </Button>
            <Button
              variant={viewType === 'state' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setViewType('state')}
            >
              State
            </Button>
            <Button
              variant={viewType === 'city' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setViewType('city')}
            >
              City
            </Button>
          </div>
        </div>
      </Card>

      {/* Geographic Data Table */}
      {geoData.length === 0 ? (
        <Card className="text-center py-12">
          <Globe className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No geographic data available
          </h3>
          <p className="text-gray-600 mb-6">
            Data will appear here once you have orders with location information
          </p>
        </Card>
      ) : (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Location</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Visitors</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Conversions</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Conv. Rate</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Revenue ($)</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Avg. Value</th>
                </tr>
              </thead>
              <tbody>
                {aggregateData().map((item, index) => {
                  const convRate = item.visitors > 0 ? (item.conversions / item.visitors * 100).toFixed(1) : '0';
                  const avgValue = item.conversions > 0 ? (item.revenue / item.conversions).toFixed(0) : '0';
                  
                  let locationName: string;
                  switch (viewType) {
                    case 'country':
                      locationName = item.country;
                      break;
                    case 'state':
                      locationName = `${item.state}, ${item.country}`;
                      break;
                    case 'city':
                      locationName = `${item.city}, ${item.state}`;
                      break;
                    default:
                      locationName = item.country;
                  }

                  return (
                    <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <div className="flex items-center space-x-2">
                          <MapPin className="h-4 w-4 text-gray-400" />
                          <span className="font-medium text-gray-900">{locationName}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-gray-900">{item.visitors.toLocaleString()}</td>
                      <td className="py-3 px-4 text-gray-900">{item.conversions}</td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          parseFloat(convRate) > 5 
                            ? 'bg-green-100 text-green-800' 
                            : parseFloat(convRate) > 2 
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {convRate}%
                        </span>
                      </td>
                      <td className="py-3 px-4 font-medium text-gray-900">${Math.round(item.revenue).toLocaleString()}</td>
                      <td className="py-3 px-4 text-gray-900">${Math.round(parseFloat(avgValue))}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Top Performing Locations */}
      {geoData.length > 0 && (
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performing Locations</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {aggregateData().sort((a, b) => b.revenue - a.revenue).slice(0, 3).map((item, index) => {
              const convRate = item.visitors > 0 ? (item.conversions / item.visitors * 100).toFixed(1) : '0';
              
              let locationName: string;
              switch (viewType) {
                case 'country':
                  locationName = item.country;
                  break;
                case 'state':
                  locationName = `${item.state}, ${item.country}`;
                  break;
                case 'city':
                  locationName = `${item.city}, ${item.state}`;
                  break;
                default:
                  locationName = item.country;
              }

              return (
                <div key={index} className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-bold text-sm">#{index + 1}</span>
                    </div>
                    <h4 className="font-medium text-gray-900">{locationName}</h4>
                  </div>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Visitors:</span>
                      <span className="font-medium">{item.visitors.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Conversions:</span>
                      <span className="font-medium">{item.conversions}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Conv. Rate:</span>
                      <span className="font-medium text-green-600">{convRate}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Revenue:</span>
                      <span className="font-medium">${Math.round(item.revenue).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
};