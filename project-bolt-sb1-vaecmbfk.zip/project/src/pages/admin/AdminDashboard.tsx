import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { Users, Package, DollarSign, TrendingUp, Calendar, Settings, MessageSquare, FileText, RefreshCw } from 'lucide-react';

interface DashboardStats {
  totalUsers: number;
  totalOrders: number;
  totalRevenue: number;
  newUsersToday: number;
  ordersToday: number;
  revenueToday: number;
}

interface RecentOrder {
  id: string;
  total_amount: number;
  status: string;
  created_at: string;
  packages?: { name: string };
  states?: { name: string };
}

export const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalOrders: 0,
    totalRevenue: 0,
    newUsersToday: 0,
    ordersToday: 0,
    revenueToday: 0
  });
  const [recentOrders, setRecentOrders] = useState<RecentOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchStats = async () => {
    try {
      if (refreshing) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      
      const today = new Date().toISOString().split('T')[0];
      
      // Get total users
      const { count: totalUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      // Get new users today
      const { count: newUsersToday } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', today);

      // Get total orders
      const { count: totalOrders } = await supabase
        .from('orders')
        .select('*', { count: 'exact', head: true });

      // Get orders today
      const { count: ordersToday } = await supabase
        .from('orders')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', today);

      // Get total revenue
      const { data: revenueData } = await supabase
        .from('orders')
        .select('total_amount')
        .eq('payment_status', 'paid');

      const totalRevenue = revenueData?.reduce((sum, order) => sum + (order.total_amount || 0), 0) || 0;

      // Get revenue today
      const { data: revenueTodayData } = await supabase
        .from('orders')
        .select('total_amount')
        .eq('payment_status', 'paid')
        .gte('created_at', today);

      const revenueToday = revenueTodayData?.reduce((sum, order) => sum + (order.total_amount || 0), 0) || 0;

      // Get recent orders
      const { data: ordersData } = await supabase
        .from('orders')
        .select(`
          id,
          total_amount,
          status,
          created_at,
          packages(name),
          states(name)
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      setStats({
        totalUsers: totalUsers || 0,
        totalOrders: totalOrders || 0,
        totalRevenue: Math.round(totalRevenue / 100), // Convert cents to dollars
        newUsersToday: newUsersToday || 0,
        ordersToday: ordersToday || 0,
        revenueToday: Math.round(revenueToday / 100) // Convert cents to dollars
      });

      setRecentOrders(ordersData || []);
    } catch (error) {
      console.error('Error fetching stats:', error);
      // Don't set fallback data to avoid showing false information
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const handleManageUsers = () => {
    // Navigate to users management
    alert('User management functionality coming soon!');
  };

  const handleManageOrders = () => {
    // Navigate to orders management
    alert('Order management functionality coming soon!');
  };

  const handleManagePackages = () => {
    // Navigate to packages management
    alert('Package management functionality coming soon!');
  };

  const handleManageSettings = () => {
    // Navigate to settings
    alert('Settings functionality coming soon!');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-gray-600">
              Overview of your business metrics and performance
            </p>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={fetchStats}
            loading={refreshing}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Data
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Total Users */}
        <Card className="flex items-center space-x-4 hover:shadow-lg transition-shadow cursor-pointer" onClick={handleManageUsers}>
          <div className="bg-blue-100 p-3 rounded-full">
            <Users className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Users</h3>
            <p className="text-2xl font-bold text-gray-900">{stats.totalUsers.toLocaleString()}</p>
            <p className="text-sm text-gray-600">+{stats.newUsersToday} today</p>
          </div>
        </Card>

        {/* Total Orders */}
        <Card className="flex items-center space-x-4 hover:shadow-lg transition-shadow cursor-pointer" onClick={handleManageOrders}>
          <div className="bg-green-100 p-3 rounded-full">
            <Package className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Orders</h3>
            <p className="text-2xl font-bold text-gray-900">{stats.totalOrders.toLocaleString()}</p>
            <p className="text-sm text-gray-600">+{stats.ordersToday} today</p>
          </div>
        </Card>

        {/* Total Revenue */}
        <Card className="flex items-center space-x-4 hover:shadow-lg transition-shadow">
          <div className="bg-yellow-100 p-3 rounded-full">
            <DollarSign className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Revenue</h3>
            <p className="text-2xl font-bold text-gray-900">${stats.totalRevenue.toLocaleString()}</p>
            <p className="text-sm text-gray-600">+${stats.revenueToday.toLocaleString()} today</p>
          </div>
        </Card>

        {/* New Users Today */}
        <Card className="flex items-center space-x-4 hover:shadow-lg transition-shadow">
          <div className="bg-purple-100 p-3 rounded-full">
            <TrendingUp className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">New Users Today</h3>
            <p className="text-2xl font-bold text-gray-900">{stats.newUsersToday}</p>
            <p className="text-sm text-gray-600">Growth rate</p>
          </div>
        </Card>

        {/* Orders Today */}
        <Card className="flex items-center space-x-4 hover:shadow-lg transition-shadow">
          <div className="bg-indigo-100 p-3 rounded-full">
            <Calendar className="h-6 w-6 text-indigo-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Orders Today</h3>
            <p className="text-2xl font-bold text-gray-900">{stats.ordersToday}</p>
            <p className="text-sm text-gray-600">Active orders</p>
          </div>
        </Card>

        {/* Revenue Today */}
        <Card className="flex items-center space-x-4 hover:shadow-lg transition-shadow">
          <div className="bg-pink-100 p-3 rounded-full">
            <DollarSign className="h-6 w-6 text-pink-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Revenue Today</h3>
            <p className="text-2xl font-bold text-gray-900">${stats.revenueToday.toLocaleString()}</p>
            <p className="text-sm text-gray-600">Daily earnings</p>
          </div>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-900">
              Recent Orders
              <span className="text-xs text-gray-500 ml-2">
                Last updated: {new Date().toLocaleTimeString()}
              </span>
            </h3>
            <Button variant="outline" size="sm" onClick={handleManageOrders}>
              View All
            </Button>
          </div>
          <div className="space-y-3">
            {recentOrders.length > 0 ? recentOrders.map((order) => (
              <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer" onClick={() => handleManageOrders()}>
                <div>
                  <p className="font-medium text-gray-900">
                    {order.states?.name || 'Unknown State'} LLC
                  </p>
                  <p className="text-sm text-gray-600">
                    {order.packages?.name || 'Unknown Package'} Package
                  </p>
                  <p className="text-xs text-gray-500">
                    {new Date(order.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div className="text-right">
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                    {order.status}
                  </span>
                  <p className="text-sm font-medium text-gray-900 mt-1">
                    ${(order.total_amount / 100).toFixed(2)}
                  </p>
                </div>
              </div>
            )) : (
              <div className="text-center py-8 bg-gray-50 rounded-lg">
                <Package className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No recent orders found</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-3"
                  onClick={fetchStats}
                >
                  Refresh Data
                </Button>
              </div>
            )}
          </div>
        </Card>

        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Quick Actions
          </h3>
          <div className="space-y-3">
            <button 
              onClick={handleManageUsers}
              className="w-full flex items-center space-x-3 p-3 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors text-left"
            >
              <Users className="h-5 w-5 text-blue-600" />
              <span className="text-blue-700 font-medium">Manage Users</span>
            </button>
            <button 
              onClick={handleManageOrders}
              className="w-full flex items-center space-x-3 p-3 bg-green-50 hover:bg-green-100 rounded-lg transition-colors text-left"
            >
              <Package className="h-5 w-5 text-green-600" />
              <span className="text-green-700 font-medium">View Orders</span>
            </button>
            <button 
              onClick={handleManagePackages}
              className="w-full flex items-center space-x-3 p-3 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors text-left"
            >
              <FileText className="h-5 w-5 text-purple-600" />
              <span className="text-purple-700 font-medium">Manage Packages</span>
            </button>
            <button 
              onClick={handleManageSettings}
              className="w-full flex items-center space-x-3 p-3 bg-yellow-50 hover:bg-yellow-100 rounded-lg transition-colors text-left"
            >
              <Settings className="h-5 w-5 text-yellow-600" />
              <span className="text-yellow-700 font-medium">System Settings</span>
            </button>
          </div>
        </Card>
      </div>

      {/* System Status */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          System Status
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <div>
              <p className="font-medium text-green-900">Database</p>
              <p className="text-sm text-green-700">Operational</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <div>
              <p className="font-medium text-green-900">API Services</p>
              <p className="text-sm text-green-700">Operational</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <div>
              <p className="font-medium text-green-900">Payment Gateway</p>
              <p className="text-sm text-green-700">Operational</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};