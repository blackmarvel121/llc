import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { Shield, AlertTriangle, CheckCircle, Clock, Plus, Edit, Trash2 } from 'lucide-react';

interface ComplianceTask {
  id: string;
  user_id: string;
  order_id?: string;
  title: string;
  description?: string;
  due_date: string;
  is_completed: boolean;
  users?: {
    profiles?: {
      first_name?: string;
      last_name?: string;
      email?: string;
    };
  };
  completed_at?: string;
}

export const Compliance: React.FC = () => {
  const [tasks, setTasks] = useState<ComplianceTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewTask, setShowNewTask] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    due_date: '',
    user_id: ''
  });

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('compliance_tasks')
        .select(`
          id,
          user_id,
          order_id,
          title,
          description,
          due_date,
          is_completed,
          completed_at,
          created_at
        `);
      
      if (error) {
        console.error('Error fetching tasks:', error);
        return;
      }
      
      // Fetch user profiles separately
      const tasksData = data || [];
      setTasks(tasksData);
      
      if (tasksData.length > 0) {
        const userIds = tasksData.map(task => task.user_id).filter(Boolean);
        
        if (userIds.length > 0) {
          const { data: profilesData, error: profilesError } = await supabase
            .from('profiles')
            .select('user_id, email, first_name, last_name')
            .in('user_id', userIds);
            
          if (!profilesError && profilesData) {
            // Create a map of user_id to profile data
            const profileMap = profilesData.reduce((map, profile) => {
              map[profile.user_id] = profile;
              return map;
            }, {});
            
            // Add profile data to each task
            const tasksWithProfiles = tasksData.map(task => ({
              ...task,
              profiles: profileMap[task.user_id] || null
            }));
            
            setTasks(tasksWithProfiles);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { error } = await supabase
        .from('compliance_tasks')
        .insert([{
          title: newTask.title,
          description: newTask.description,
          due_date: newTask.due_date,
          user_id: newTask.user_id,
          is_completed: false
        }]);

      if (error) throw error;

      setNewTask({ title: '', description: '', due_date: '', user_id: '' });
      setShowNewTask(false);
      fetchTasks();
    } catch (error) {
      console.error('Error creating task:', error);
    }
  };

  const handleToggleComplete = async (taskId: string, isCompleted: boolean) => {
    try {
      const { error } = await supabase
        .from('compliance_tasks')
        .update({ 
          is_completed: !isCompleted,
          completed_at: !isCompleted ? new Date().toISOString() : null
        })
        .eq('id', taskId);

      if (error) throw error;
      fetchTasks();
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    if (confirm('Are you sure you want to delete this task?')) {
      try {
        const { error } = await supabase
          .from('compliance_tasks')
          .delete()
          .eq('id', taskId);

        if (error) throw error;
        fetchTasks();
      } catch (error) {
        console.error('Error deleting task:', error);
      }
    }
  };

  const getTaskStatus = (task: ComplianceTask) => {
    if (task.is_completed) {
      return { icon: CheckCircle, color: 'text-green-500', label: 'Completed' };
    }
    
    const dueDate = new Date(task.due_date);
    const now = new Date();
    const daysUntilDue = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilDue < 0) {
      return { icon: AlertTriangle, color: 'text-red-500', label: 'Overdue' };
    } else if (daysUntilDue <= 7) {
      return { icon: Clock, color: 'text-yellow-500', label: 'Due Soon' };
    } else {
      return { icon: Clock, color: 'text-blue-500', label: 'Pending' };
    }
  };

  const overdueTasks = tasks.filter(task => {
    if (task.is_completed) return false;
    const dueDate = new Date(task.due_date);
    return dueDate < new Date();
  });

  const dueSoonTasks = tasks.filter(task => {
    if (task.is_completed) return false;
    const dueDate = new Date(task.due_date);
    const now = new Date();
    const daysUntilDue = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilDue >= 0 && daysUntilDue <= 7;
  });

  const completedTasks = tasks.filter(task => task.is_completed);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Compliance Management</h1>
          <p className="text-gray-600">Track and manage compliance tasks for customers</p>
        </div>
        <Button onClick={() => setShowNewTask(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Task
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <Shield className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Tasks</h3>
            <p className="text-2xl font-bold text-gray-900">{tasks.length}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-red-100 p-3 rounded-full">
            <AlertTriangle className="h-6 w-6 text-red-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Overdue</h3>
            <p className="text-2xl font-bold text-gray-900">{overdueTasks.length}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-yellow-100 p-3 rounded-full">
            <Clock className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Due Soon</h3>
            <p className="text-2xl font-bold text-gray-900">{dueSoonTasks.length}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-green-100 p-3 rounded-full">
            <CheckCircle className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Completed</h3>
            <p className="text-2xl font-bold text-gray-900">{completedTasks.length}</p>
          </div>
        </Card>
      </div>

      {/* New Task Form */}
      {showNewTask && (
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Compliance Task</h3>
          <form onSubmit={handleCreateTask} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Task Title
              </label>
              <input
                type="text"
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Due Date
                </label>
                <input
                  type="date"
                  value={newTask.due_date}
                  onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  User ID
                </label>
                <input
                  type="text"
                  value={newTask.user_id}
                  onChange={(e) => setNewTask({ ...newTask, user_id: e.target.value })}
                  placeholder="Enter user ID"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
            <div className="flex space-x-3">
              <Button type="submit">Create Task</Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowNewTask(false)}
              >
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      )}

      {/* Tasks List */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Compliance Tasks</h3>
        <div className="space-y-4">
          {tasks.map((task) => {
            const status = getTaskStatus(task);
            const StatusIcon = status.icon;
            
            return (
              <div key={task.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    <div className="mt-1">
                      <StatusIcon className={`h-5 w-5 ${status.color}`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-gray-900">{task.title}</h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          task.is_completed 
                            ? 'bg-green-100 text-green-800'
                            : status.label === 'Overdue'
                            ? 'bg-red-100 text-red-800'
                            : status.label === 'Due Soon'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}>
                          {status.label}
                        </span>
                      </div>
                      {task.description && (
                        <p className="text-gray-600 mb-2">{task.description}</p>
                      )}
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <span>
                          Assigned to: {task.profiles?.first_name || ''} {task.profiles?.last_name || ''} ({task.profiles?.email || 'Unknown User'})
                        </span>
                        <span>Due: {new Date(task.due_date).toLocaleDateString()}</span>
                      </div>
                      {task.completed_at && (
                        <p className="text-sm text-green-600 mt-1">
                          Completed: {new Date(task.completed_at).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex space-x-2 ml-4">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleToggleComplete(task.id, task.is_completed)}
                    >
                      {task.is_completed ? 'Mark Incomplete' : 'Mark Complete'}
                    </Button>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleDeleteTask(task.id)}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
};