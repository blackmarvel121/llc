import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { MessageSquare, Phone, Settings, TestTube } from 'lucide-react';

interface WhatsAppSettings {
  whatsapp_enabled: boolean;
  whatsapp_number: string;
  whatsapp_message: string;
}

export const WhatsAppSettings: React.FC = () => {
  const [settings, setSettings] = useState<WhatsAppSettings>({
    whatsapp_enabled: false,
    whatsapp_number: '',
    whatsapp_message: 'Hi! I need help with LLC formation.'
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('settings')
        .select('whatsapp_enabled, whatsapp_number, whatsapp_message')
        .eq('key', 'global')
        .single();

      if (data) {
        setSettings({
          whatsapp_enabled: data.whatsapp_enabled || false,
          whatsapp_number: data.whatsapp_number || '',
          whatsapp_message: data.whatsapp_message || 'Hi! I need help with LLC formation.'
        });
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = async () => {
    setSaving(true);
    try {
      const { data, error } = await supabase
        .from('settings')
        .update({
          whatsapp_enabled: settings.whatsapp_enabled,
          whatsapp_number: settings.whatsapp_number,
          whatsapp_message: settings.whatsapp_message
        })
        .eq('key', 'global');
      
      if (error) throw error;
      
      console.log('Settings saved:', data);
      alert('WhatsApp settings saved successfully! The changes will be reflected on the website.');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Error saving settings');
    } finally {
      setSaving(false);
    }
  };

  const handleTestWhatsApp = () => {
    if (!settings.whatsapp_number) {
      alert('Please enter a WhatsApp number first');
      return;
    }

    const encodedMessage = encodeURIComponent('Test message from admin panel');
    const whatsappUrl = `https://wa.me/${settings.whatsapp_number.replace(/\D/g, '')}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">WhatsApp Settings</h1>
        <p className="text-gray-600">Configure WhatsApp integration for customer support</p>
      </div>

      {/* WhatsApp Configuration */}
      <Card>
        <div className="flex items-center space-x-3 mb-6">
          <MessageSquare className="h-6 w-6 text-green-600" />
          <h2 className="text-xl font-semibold text-gray-900">WhatsApp Configuration</h2>
        </div>
        
        <div className="space-y-6">
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              id="whatsapp_enabled"
              checked={settings.whatsapp_enabled}
              onChange={(e) => setSettings({
                ...settings,
                whatsapp_enabled: e.target.checked
              })}
              className="rounded"
            />
            <div>
              <label htmlFor="whatsapp_enabled" className="font-medium text-gray-900">
                Enable WhatsApp chat button on website
              </label>
              <p className="text-xs text-gray-500 mt-1">
                When disabled, the WhatsApp button will not appear on the website
              </p>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              WhatsApp Business Number
            </label>
            <div className="relative">
              <Phone className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={settings.whatsapp_number}
                onChange={(e) => setSettings({
                  ...settings,
                  whatsapp_number: e.target.value
                })}
                placeholder="+1234567890"
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <p className="text-sm text-gray-600 mt-1">
              Include country code (e.g., +1 for US, +44 for UK)
            </p>
            <p className="text-xs text-gray-500 mt-1">
              This is required for the WhatsApp button to work
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Default Message Template
            </label>
            <textarea
              value={settings.whatsapp_message}
              onChange={(e) => setSettings({
                ...settings,
                whatsapp_message: e.target.value
              })}
              placeholder="Hi! I need help with LLC formation."
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="text-sm text-gray-600 mt-1">
              This message will be pre-filled when customers click the WhatsApp button
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Keep it short and to the point
            </p>
          </div>
        </div>
      </Card>

      {/* Preview */}
      <Card>
        <div className="flex items-center space-x-3 mb-6">
          <TestTube className="h-6 w-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-900">Preview & Test</h2>
        </div>
        
        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium text-gray-900 mb-2">WhatsApp Button Preview</h3>
            <div className="flex items-center space-x-3">
              <div className={`p-3 rounded-full ${
                settings.whatsapp_enabled && settings.whatsapp_number ? 'bg-green-500' : 'bg-gray-400'
              }`}>
                <MessageSquare className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="font-medium text-gray-900">Chat with Support</p>
                <p className="text-sm text-gray-600">
                  {settings.whatsapp_enabled && settings.whatsapp_number ? 'Active' : 'Disabled'}
                  {settings.whatsapp_enabled && !settings.whatsapp_number && ' (No number provided)'}
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium text-gray-900 mb-2">Message Preview</h3>
            <div className="bg-white p-3 rounded-lg border border-gray-200">
              <p className="text-gray-700">{settings.whatsapp_message}</p>
            </div>
          </div>
          
          <Button 
            variant="outline" 
            onClick={handleTestWhatsApp}
            disabled={!settings.whatsapp_enabled || !settings.whatsapp_number}
          >
            <TestTube className="h-4 w-4 mr-2" />
            Test WhatsApp Integration
          </Button>
        </div>
      </Card>

      {/* Usage Statistics */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Usage Statistics</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-2xl font-bold text-green-600">247</p>
            <p className="text-sm text-green-700">Total Chats</p>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <p className="text-2xl font-bold text-blue-600">18</p>
            <p className="text-sm text-blue-700">Chats Today</p>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <p className="text-2xl font-bold text-purple-600">89%</p>
            <p className="text-sm text-purple-700">Response Rate</p>
          </div>
        </div>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} loading={saving}>
          <Settings className="h-4 w-4 mr-2" />
          Save WhatsApp Settings
        </Button>
      </div>
    </div>
  );
};