import React, { useState, useEffect } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { CreditCard, DollarSign, TrendingUp, Settings, CheckCircle, AlertCircle, Eye, Save, ToggleLeft, ToggleRight } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface PaymentGateway {
  id: string;
  name: string;
  type: 'stripe' | 'razorpay' | 'paypal' | 'square';
  status: 'active' | 'inactive' | 'testing';
  transactionFee: number;
  monthlyVolume: number;
  successRate: number;
  lastTransaction: string;
  enabled: boolean;
}

export const PaymentGateways: React.FC = () => {
  const [gateways, setGateways] = useState<PaymentGateway[]>([]);
  const [loading, setLoading] = useState(true);
  const [stripeKeys, setStripeKeys] = useState({
    publicKey: '',
    secretKey: '',
    webhookSecret: ''
  });
  const [razorpayKeys, setRazorpayKeys] = useState({
    publicKey: '',
    secretKey: '',
    webhookSecret: ''
  });
  const [paypalKeys, setPaypalKeys] = useState({
    publicKey: '',
    secretKey: '',
    webhookSecret: ''
  });
  const [savingStripe, setSavingStripe] = useState(false);
  const [savingRazorpay, setSavingRazorpay] = useState(false);
  const [savingPaypal, setSavingPaypal] = useState(false);

  const [transactions] = useState<Array<any>>([
    { id: '1', amount: 149, gateway: 'Stripe', status: 'success', date: '2024-01-15T10:30:00Z' },
    { id: '2', amount: 49, gateway: 'PayPal', status: 'success', date: '2024-01-15T10:25:00Z' },
    { id: '3', amount: 299, gateway: 'Stripe', status: 'success', date: '2024-01-15T10:20:00Z' },
    { id: '4', amount: 149, gateway: 'Stripe', status: 'failed', date: '2024-01-15T10:15:00Z' },
    { id: '5', amount: 49, gateway: 'PayPal', status: 'success', date: '2024-01-15T10:10:00Z' },
  ]);

  /*const [transactions] = useState<Array<{
    id: string;
    amount: number;
    gateway: string;
    status: string;
    date: string;
  }>>([]);*/

  useEffect(() => {
    fetchPaymentGateways();
  }, []);

  const fetchPaymentGateways = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('payment_gateways')
        .select('*');
      
      if (error) throw error;
      
      // Ensure data is an array before processing
      const safeData = Array.isArray(data) ? data : [];
      
      // Transform data to match our interface
      const transformedGateways = safeData.map(gateway => ({
        id: gateway.id,
        name: gateway.name,
        type: gateway.type,
        status: gateway.enabled ? 'active' : 'inactive',
        enabled: gateway.enabled,
        transactionFee: gateway.type === 'stripe' ? 2.9 : gateway.type === 'razorpay' ? 2.0 : 3.0,
        monthlyVolume: gateway.enabled ? Number((Math.random() * 50000).toFixed(0)) : 0,
        successRate: gateway.enabled ? 95 + (Math.random() * 5) : 0,
        lastTransaction: gateway.enabled ? new Date().toISOString() : '2024-01-01T00:00:00Z'
      }));
      
      setGateways(transformedGateways);
      
      // Set keys for configuration forms
      const stripeGateway = safeData.find(g => g.type === 'stripe') || null;
      if (stripeGateway) {
        setStripeKeys({
          publicKey: stripeGateway.public_key || '',
          secretKey: stripeGateway.secret_key || '',
          webhookSecret: stripeGateway.webhook_secret || ''
        });
      }
      
      const razorpayGateway = safeData.find(g => g.type === 'razorpay') || null;
      if (razorpayGateway) {
        setRazorpayKeys({
          publicKey: razorpayGateway.public_key || '',
          secretKey: razorpayGateway.secret_key || '',
          webhookSecret: razorpayGateway.webhook_secret || ''
        });
      }

      const paypalGateway = safeData.find(g => g.type === 'paypal') || null;
      if (paypalGateway) {
        setPaypalKeys({
          publicKey: paypalGateway.public_key || '',
          secretKey: paypalGateway.secret_key || '',
          webhookSecret: paypalGateway.webhook_secret || ''
        });
      }
      
    } catch (error) {
      console.error('Error fetching payment gateways:', error);
      // Ensure gateways is always an array even on error
      setGateways([]);
    } finally {
      setLoading(false);
    }
  };

  // Ensure gateways is always treated as an array
  const gatewaysArray = gateways || [];
  
  // Calculate stats with null checks
  const totalVolume = gatewaysArray.reduce((sum, gateway) => sum + (gateway.monthlyVolume || 0), 0);
  const avgSuccessRate = gatewaysArray.length > 0 
    ? gatewaysArray.reduce((sum, gateway) => sum + (gateway.successRate || 0), 0) / gatewaysArray.length 
    : 0;
  const activeGateways = gatewaysArray.filter(g => g.enabled === true).length;

  const saveStripeKeys = async () => {
    try {
      setSavingStripe(true);
      
      // Validate keys
      if (!stripeKeys.publicKey || !stripeKeys.secretKey) {
        alert('Please enter both public and secret keys');
        setSavingStripe(false);
        return;
      }
      
      const { data, error } = await supabase
        .from('payment_gateways')
        .update({
          public_key: stripeKeys.publicKey,
          secret_key: stripeKeys.secretKey,
          webhook_secret: stripeKeys.webhookSecret,
          enabled: stripeKeys.publicKey !== '' && stripeKeys.secretKey !== ''
        })
        .eq('type', 'stripe');

      if (error) throw error;
      
      await fetchPaymentGateways();
      alert('Stripe configuration saved successfully!');
    } catch (error) {
      console.error('Error saving Stripe configuration:', error);
      alert('Error saving Stripe configuration');
    } finally {
      setSavingStripe(false);
    }
  };

  const saveRazorpayKeys = async () => {
    try {
      setSavingRazorpay(true);
      
      // Validate keys
      if (!razorpayKeys.publicKey || !razorpayKeys.secretKey) {
        alert('Please enter both public and secret keys');
        setSavingRazorpay(false);
        return;
      }
      
      const { data, error } = await supabase
        .from('payment_gateways')
        .update({
          public_key: razorpayKeys.publicKey,
          secret_key: razorpayKeys.secretKey,
          webhook_secret: razorpayKeys.webhookSecret,
          enabled: razorpayKeys.publicKey !== '' && razorpayKeys.secretKey !== ''
        })
        .eq('type', 'razorpay');

      if (error) throw error;
      
      await fetchPaymentGateways();
      alert('Razorpay configuration saved successfully!');
    } catch (error) {
      console.error('Error saving Razorpay configuration:', error);
      alert('Error saving Razorpay configuration');
    } finally {
      setSavingRazorpay(false);
    }
  };

  const savePaypalKeys = async () => {
    try {
      setSavingPaypal(true);
      
      // Validate keys
      if (!paypalKeys.publicKey || !paypalKeys.secretKey) {
        alert('Please enter both public and secret keys');
        setSavingPaypal(false);
        return;
      }
      
      const { data, error } = await supabase
        .from('payment_gateways')
        .update({
          public_key: paypalKeys.publicKey,
          secret_key: paypalKeys.secretKey,
          webhook_secret: paypalKeys.webhookSecret,
          enabled: paypalKeys.publicKey !== '' && paypalKeys.secretKey !== ''
        })
        .eq('type', 'paypal');

      if (error) throw error;
      
      await fetchPaymentGateways();
      alert('PayPal configuration saved successfully!');
    } catch (error) {
      console.error('Error saving PayPal configuration:', error);
      alert('Error saving PayPal configuration');
    } finally {
      setSavingPaypal(false);
    }
  };

  const toggleGatewayStatus = async (gatewayId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('payment_gateways')
        .update({ enabled: !currentStatus })
        .eq('id', gatewayId);

      if (error) throw error;
      
      await fetchPaymentGateways();
    } catch (error) {
      console.error('Error toggling gateway status:', error);
      alert('Error updating gateway status');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'inactive':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'testing':
        return <Settings className="h-5 w-5 text-yellow-500" />;
      default:
        return <AlertCircle className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-red-100 text-red-800';
      case 'testing':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getGatewayLogo = (type: string) => {
    switch (type) {
      case 'stripe':
        return '💳';
      case 'paypal':
        return '💸';
      case 'square':
        return '⬜';
      case 'authorize':
        return '🔐';
      default:
        return '💰';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Payment Gateways</h1>
        <p className="text-gray-600">Manage payment processing and gateway configurations</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <CreditCard className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Active Gateways</h3>
            <p className="text-2xl font-bold text-gray-900">{activeGateways}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-green-100 p-3 rounded-full">
            <DollarSign className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Monthly Volume</h3>
            <p className="text-2xl font-bold text-gray-900">${totalVolume.toLocaleString()}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-yellow-100 p-3 rounded-full">
            <TrendingUp className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Success Rate</h3>
            <p className="text-2xl font-bold text-gray-900">{avgSuccessRate.toFixed(1)}%</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-purple-100 p-3 rounded-full">
            <Settings className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Transactions</h3>
            <p className="text-2xl font-bold text-gray-900">{transactions.length}</p>
          </div>
        </Card>
      </div>

      {/* Payment Gateways */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Payment Gateway Status</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {gatewaysArray.length > 0 ? gatewaysArray.map((gateway) => (
            <div key={gateway.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{getGatewayLogo(gateway.type)}</span>
                  <div>
                    <h4 className="font-semibold text-gray-900">{gateway.name}</h4>
                    <p className="text-sm text-gray-600">{gateway.transactionFee}% transaction fee</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {getStatusIcon(gateway.status)}
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(gateway.status)}`}>
                    {gateway.status}
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-600">Monthly Volume</p>
                  <p className="font-semibold text-gray-900">${(gateway.monthlyVolume || 0).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Success Rate</p>
                  <p className="font-semibold text-gray-900">{gateway.successRate || 0}%</p>
                </div>
              </div>
              
              <div className="mb-4">
                <p className="text-sm text-gray-600">Last Transaction</p>
                <p className="text-sm text-gray-900">
                  {new Date(gateway.lastTransaction).toLocaleString()}
                </p>
              </div>
              
              <div className="flex space-x-2 justify-between">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => toggleGatewayStatus(gateway.id, gateway.enabled === true)}
                  className="flex items-center"
                >
                  {gateway.enabled ? (
                    <>
                      <ToggleRight className="h-4 w-4 mr-1 text-green-500" />
                      Disable
                    </>
                  ) : (
                    <>
                      <ToggleLeft className="h-4 w-4 mr-1 text-gray-500" />
                      Enable
                    </>
                  )}
                </Button>
                <Button variant="outline" size="sm">
                  <Settings className="h-4 w-4 mr-1" />
                  Configure
                </Button>
              </div>
            </div>
          )) : (
            <div className="col-span-2 text-center py-8 text-gray-500">
              <p>No payment gateways configured. Please add a payment gateway.</p>
            </div>
          )}
        </div>
      </Card>

      {/* Recent Transactions */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Transactions</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Transaction ID</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Amount</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Gateway</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Date</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((transaction) => (
                <tr key={transaction.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-mono text-sm">#{transaction.id}</td>
                  <td className="py-3 px-4 font-medium text-gray-900">${transaction.amount}</td>
                  <td className="py-3 px-4 text-gray-900">{transaction.gateway}</td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      transaction.status === 'success' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {transaction.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-600">
                    {new Date(transaction.date).toLocaleDateString()}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Gateway Configuration */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Stripe Configuration */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Stripe Configuration</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Stripe Public Key
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="pk_test_..."
                  value={stripeKeys.publicKey}
                  onChange={(e) => setStripeKeys({...stripeKeys, publicKey: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5">
                  <span className="text-gray-400">Required</span>
                </div>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Stripe Secret Key
              </label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="sk_test_..."
                  value={stripeKeys.secretKey}
                  onChange={(e) => setStripeKeys({...stripeKeys, secretKey: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5">
                  <span className="text-gray-400">Required</span>
                </div>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Webhook Secret
              </label>
              <input
                type="password"
                placeholder="whsec_..."
                value={stripeKeys.webhookSecret}
                onChange={(e) => setStripeKeys({...stripeKeys, webhookSecret: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <Button onClick={saveStripeKeys} loading={savingStripe}>
              <Save className="h-4 w-4 mr-2" />
              Save Stripe Configuration
            </Button>
          </div>
        </Card>
        
        {/* Razorpay Configuration */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Razorpay Configuration</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Razorpay Key ID
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="rzp_test_..."
                  value={razorpayKeys.publicKey}
                  onChange={(e) => setRazorpayKeys({...razorpayKeys, publicKey: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5">
                  <span className="text-gray-400">Required</span>
                </div>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Razorpay Key Secret
              </label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="Your Razorpay secret key"
                  value={razorpayKeys.secretKey}
                  onChange={(e) => setRazorpayKeys({...razorpayKeys, secretKey: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5">
                  <span className="text-gray-400">Required</span>
                </div>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Webhook Secret
              </label>
              <input
                type="password"
                placeholder="Your Razorpay webhook secret"
                value={razorpayKeys.webhookSecret}
                onChange={(e) => setRazorpayKeys({...razorpayKeys, webhookSecret: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <Button onClick={saveRazorpayKeys} loading={savingRazorpay}>
              <Save className="h-4 w-4 mr-2" />
              Save Razorpay Configuration
            </Button>
          </div>
        </Card>
        
        {/* PayPal Configuration */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">PayPal Configuration</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                PayPal Client ID
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Your PayPal client ID"
                  value={paypalKeys.publicKey}
                  onChange={(e) => setPaypalKeys({...paypalKeys, publicKey: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5">
                  <span className="text-gray-400">Required</span>
                </div>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                PayPal Secret
              </label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="Your PayPal secret"
                  value={paypalKeys.secretKey}
                  onChange={(e) => setPaypalKeys({...paypalKeys, secretKey: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5">
                  <span className="text-gray-400">Required</span>
                </div>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Webhook ID
              </label>
              <input
                type="password"
                placeholder="Your PayPal webhook ID"
                value={paypalKeys.webhookSecret}
                onChange={(e) => setPaypalKeys({...paypalKeys, webhookSecret: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <Button onClick={savePaypalKeys} loading={savingPaypal}>
              <Save className="h-4 w-4 mr-2" />
              Save PayPal Configuration
            </Button>
            <div className="mt-2 text-sm text-gray-600">
              <p>Webhook URL: <code>{import.meta.env.VITE_SUPABASE_URL}/functions/v1/paypal-webhook</code></p>
            </div>
          </div>
        </Card>
      </div>
      
      {/* General Payment Settings */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">General Payment Settings</h3>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Default Gateway
              </label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="stripe">Stripe</option>
                <option value="razorpay">Razorpay</option>
                <option value="paypal">PayPal</option>
                <option value="square">Square</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fallback Gateway
              </label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="razorpay">Razorpay</option>
                <option value="stripe">Stripe</option>
                <option value="paypal">PayPal</option>
                <option value="square">Square</option>
              </select>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <input type="checkbox" id="auto_retry" className="rounded" defaultChecked />
            <label htmlFor="auto_retry" className="text-sm font-medium text-gray-900">
              Enable automatic retry on failed transactions
            </label>
          </div>
          
          <div className="flex items-center space-x-3">
            <input type="checkbox" id="fraud_detection" className="rounded" defaultChecked />
            <label htmlFor="fraud_detection" className="text-sm font-medium text-gray-900">
              Enable fraud detection
            </label>
          </div>
          
          <Button>
            <CreditCard className="h-4 w-4 mr-2" />
            Save General Settings
          </Button>
        </div>
      </Card>
    </div>
  );
};