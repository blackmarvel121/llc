import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { MapPin, Edit, Trash2, Plus } from 'lucide-react';

interface State {
  id: string;
  name: string;
  code: string;
  filing_fee: number;
  turnaround_time: string;
  monthly_price: number;
  yearly_price: number;
  one_time_price: number;
  is_active: boolean;
  created_at: string;
}

export const ManageStates: React.FC = () => {
  const [states, setStates] = useState<State[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingState, setEditingState] = useState<State | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    filing_fee: 0,
    turnaround_time: '',
    one_time_price: 49
  });

  useEffect(() => {
    fetchStates();
  }, []);

  const fetchStates = async () => {
    try {
      const { data, error } = await supabase
        .from('states')
        .select('*')
        .order('name', { ascending: true });

      if (error) throw error;
      setStates(data || []);
    } catch (error) {
      console.error('Error fetching states:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateState = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('states')
        .insert([formData]);

      if (error) throw error;
      setShowForm(false);
      setFormData({
        name: '',
        code: '',
        filing_fee: 0,
        turnaround_time: '',
        one_time_price: 49
      });
      fetchStates();
    } catch (error) {
      console.error('Error creating state:', error);
    }
  };

  const handleUpdateState = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingState) return;

    try {
      const { error } = await supabase
        .from('states')
        .update(formData)
        .eq('id', editingState.id);

      if (error) throw error;
      setEditingState(null);
      setShowForm(false);
      setFormData({
        name: '',
        code: '',
        filing_fee: 0,
        turnaround_time: '',
        one_time_price: 49
      });
      fetchStates();
    } catch (error) {
      console.error('Error updating state:', error);
    }
  };

  const startEdit = (state: State) => {
    setEditingState(state);
    setFormData({
      name: state.name,
      code: state.code,
      filing_fee: state.filing_fee,
      turnaround_time: state.turnaround_time,
      one_time_price: state.one_time_price
    });
    setShowForm(true);
  };

  const handleToggleActive = async (id: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('states')
        .update({ is_active: !isActive })
        .eq('id', id);

      if (error) throw error;
      fetchStates();
    } catch (error) {
      console.error('Error updating state:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this state?')) {
      try {
        const { error } = await supabase
          .from('states')
          .delete()
          .eq('id', id);

        if (error) throw error;
        fetchStates();
      } catch (error) {
        console.error('Error deleting state:', error);
      }
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">States & Entities</h1>
          <p className="text-gray-600">Manage state filing information and pricing</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add State
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <MapPin className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total States</h3>
            <p className="text-2xl font-bold text-gray-900">{states.length}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-green-100 p-3 rounded-full">
            <MapPin className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Active States</h3>
            <p className="text-2xl font-bold text-gray-900">
              {states.filter(s => s.is_active).length}
            </p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-yellow-100 p-3 rounded-full">
            <MapPin className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Avg Filing Fee</h3>
            <p className="text-2xl font-bold text-gray-900">
              ${Math.round(states.reduce((sum, s) => sum + s.filing_fee, 0) / states.length)}
            </p>
          </div>
        </Card>
      </div>

      {/* State Form */}
      {showForm && (
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            {editingState ? 'Edit State' : 'Add New State'}
          </h3>
          <form onSubmit={editingState ? handleUpdateState : handleCreateState} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  State Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  State Code
                </label>
                <input
                  type="text"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  maxLength={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Filing Fee ($)
                </label>
                <input
                  type="number"
                  value={formData.filing_fee}
                  onChange={(e) => setFormData({ ...formData, filing_fee: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Service Fee ($)
                </label>
                <input
                  type="number"
                  value={formData.one_time_price}
                  onChange={(e) => setFormData({ ...formData, one_time_price: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Turnaround Time
                </label>
                <input
                  type="text"
                  value={formData.turnaround_time}
                  onChange={(e) => setFormData({ ...formData, turnaround_time: e.target.value })}
                  placeholder="e.g., 3-5 business days"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button type="submit">
                {editingState ? 'Update State' : 'Add State'}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => {
                  setShowForm(false);
                  setEditingState(null);
                  setFormData({
                    name: '',
                    code: '',
                    filing_fee: 0,
                    turnaround_time: '',
                    one_time_price: 49
                  });
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      )}

      {/* States Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-900">State</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Code</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Filing Fee</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Service Fee</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Turnaround</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Status</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {states.map((state) => (
                <tr key={state.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">{state.name}</td>
                  <td className="py-3 px-4 text-gray-600 font-mono">{state.code}</td>
                  <td className="py-3 px-4 text-gray-900">${state.filing_fee}</td>
                  <td className="py-3 px-4 text-gray-900">${state.one_time_price}</td>
                  <td className="py-3 px-4 text-gray-600">{state.turnaround_time}</td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => handleToggleActive(state.id, state.is_active)}
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        state.is_active 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {state.is_active ? 'Active' : 'Inactive'}
                    </button>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <Button variant="outline" size="sm" onClick={() => startEdit(state)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleDelete(state.id)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};