import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { Package, Plus, Edit, Trash2, Star } from 'lucide-react';

interface PackageType {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
  is_popular: boolean;
  is_active: boolean;
  includes_ein: boolean;
  includes_registered_agent: boolean;
  same_day_filing: boolean;
}

export const ManagePackages: React.FC = () => {
  const [packages, setPackages] = useState<PackageType[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPackage, setEditingPackage] = useState<PackageType | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: 0,
    features: [''],
    is_popular: false,
    includes_ein: false,
    includes_registered_agent: false,
    same_day_filing: false
  });

  useEffect(() => {
    fetchPackages();
  }, []);

  const fetchPackages = async () => {
    try {
      const { data, error } = await supabase
        .from('packages')
        .select('*')
        .order('price', { ascending: true });

      if (error) throw error;
      setPackages(data || []);
    } catch (error) {
      console.error('Error fetching packages:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePackage = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('packages')
        .insert([{
          ...formData,
          features: formData.features.filter(f => f.trim() !== '')
        }]);

      if (error) throw error;
      setShowForm(false);
      setFormData({
        name: '',
        description: '',
        price: 0,
        features: [''],
        is_popular: false,
        includes_ein: false,
        includes_registered_agent: false,
        same_day_filing: false
      });
      fetchPackages();
    } catch (error) {
      console.error('Error creating package:', error);
    }
  };

  const handleUpdatePackage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPackage) return;

    try {
      const { error } = await supabase
        .from('packages')
        .update({
          ...formData,
          features: formData.features.filter(f => f.trim() !== '')
        })
        .eq('id', editingPackage.id);

      if (error) throw error;
      setEditingPackage(null);
      setFormData({
        name: '',
        description: '',
        price: 0,
        features: [''],
        is_popular: false,
        includes_ein: false,
        includes_registered_agent: false,
        same_day_filing: false
      });
      fetchPackages();
    } catch (error) {
      console.error('Error updating package:', error);
    }
  };

  const startEdit = (pkg: PackageType) => {
    setEditingPackage(pkg);
    setFormData({
      name: pkg.name,
      description: pkg.description || '',
      price: pkg.price,
      features: pkg.features.length > 0 ? pkg.features : [''],
      is_popular: pkg.is_popular,
      includes_ein: pkg.includes_ein,
      includes_registered_agent: pkg.includes_registered_agent,
      same_day_filing: pkg.same_day_filing
    });
    setShowForm(true);
  };

  const addFeature = () => {
    setFormData({
      ...formData,
      features: [...formData.features, '']
    });
  };

  const updateFeature = (index: number, value: string) => {
    const newFeatures = [...formData.features];
    newFeatures[index] = value;
    setFormData({
      ...formData,
      features: newFeatures
    });
  };

  const removeFeature = (index: number) => {
    setFormData({
      ...formData,
      features: formData.features.filter((_, i) => i !== index)
    });
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this package?')) {
      try {
        const { error } = await supabase
          .from('packages')
          .delete()
          .eq('id', id);

        if (error) throw error;
        fetchPackages();
      } catch (error) {
        console.error('Error deleting package:', error);
      }
    }
  };

  const handleToggleActive = async (id: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('packages')
        .update({ is_active: !isActive })
        .eq('id', id);

      if (error) throw error;
      fetchPackages();
    } catch (error) {
      console.error('Error updating package:', error);
    }
  };

  const handleTogglePopular = async (id: string, isPopular: boolean) => {
    try {
      const { error } = await supabase
        .from('packages')
        .update({ is_popular: !isPopular })
        .eq('id', id);

      if (error) throw error;
      fetchPackages();
    } catch (error) {
      console.error('Error updating package:', error);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-64 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Manage Packages</h1>
          <p className="text-gray-600">Create and manage LLC formation packages</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Package
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <Package className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Packages</h3>
            <p className="text-2xl font-bold text-gray-900">{packages.length}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-green-100 p-3 rounded-full">
            <Package className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Active Packages</h3>
            <p className="text-2xl font-bold text-gray-900">
              {packages.filter(p => p.is_active).length}
            </p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-yellow-100 p-3 rounded-full">
            <Star className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Popular Packages</h3>
            <p className="text-2xl font-bold text-gray-900">
              {packages.filter(p => p.is_popular).length}
            </p>
          </div>
        </Card>
      </div>

      {/* Package Form */}
      {showForm && (
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            {editingPackage ? 'Edit Package' : 'Create New Package'}
          </h3>
          <form onSubmit={editingPackage ? handleUpdatePackage : handleCreatePackage} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Package Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Price ($)
                </label>
                <input
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Features
              </label>
              {formData.features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-2 mb-2">
                  <input
                    type="text"
                    value={feature}
                    onChange={(e) => updateFeature(index, e.target.value)}
                    placeholder="Enter feature"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  {formData.features.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeFeature(index)}
                    >
                      Remove
                    </Button>
                  )}
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addFeature}
              >
                Add Feature
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="is_popular"
                    checked={formData.is_popular}
                    onChange={(e) => setFormData({ ...formData, is_popular: e.target.checked })}
                    className="rounded"
                  />
                  <label htmlFor="is_popular" className="text-sm font-medium text-gray-700">
                    Mark as Popular
                  </label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="includes_ein"
                    checked={formData.includes_ein}
                    onChange={(e) => setFormData({ ...formData, includes_ein: e.target.checked })}
                    className="rounded"
                  />
                  <label htmlFor="includes_ein" className="text-sm font-medium text-gray-700">
                    Includes EIN
                  </label>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="includes_registered_agent"
                    checked={formData.includes_registered_agent}
                    onChange={(e) => setFormData({ ...formData, includes_registered_agent: e.target.checked })}
                    className="rounded"
                  />
                  <label htmlFor="includes_registered_agent" className="text-sm font-medium text-gray-700">
                    Includes Registered Agent
                  </label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="same_day_filing"
                    checked={formData.same_day_filing}
                    onChange={(e) => setFormData({ ...formData, same_day_filing: e.target.checked })}
                    className="rounded"
                  />
                  <label htmlFor="same_day_filing" className="text-sm font-medium text-gray-700">
                    Same Day Filing
                  </label>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button type="submit">
                {editingPackage ? 'Update Package' : 'Create Package'}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => {
                  setShowForm(false);
                  setEditingPackage(null);
                  setFormData({
                    name: '',
                    description: '',
                    price: 0,
                    features: [''],
                    is_popular: false,
                    includes_ein: false,
                    includes_registered_agent: false,
                    same_day_filing: false
                  });
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      )}

      {/* Packages Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {packages.map((pkg) => (
          <Card key={pkg.id} className={`relative ${pkg.is_popular ? 'ring-2 ring-blue-500' : ''}`}>
            {pkg.is_popular && (
              <div className="absolute top-0 left-0 right-0 bg-blue-500 text-white text-center py-2 text-sm font-bold rounded-t-lg">
                MOST POPULAR
              </div>
            )}
            
            <div className={`${pkg.is_popular ? 'pt-12' : 'pt-6'} pb-6`}>
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">{pkg.name}</h3>
                  <p className="text-gray-600">{pkg.description}</p>
                </div>
                <div className="flex space-x-1">
                  <button
                    onClick={() => handleTogglePopular(pkg.id, pkg.is_popular)}
                    className={`p-1 rounded ${pkg.is_popular ? 'text-yellow-500' : 'text-gray-400'}`}
                  >
                    <Star className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className="mb-4">
                <span className="text-3xl font-bold text-gray-900">${pkg.price}</span>
              </div>

              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-2">Features:</h4>
                <ul className="space-y-1">
                  {pkg.features.slice(0, 4).map((feature, index) => (
                    <li key={index} className="text-sm text-gray-600 flex items-center">
                      <span className="w-1 h-1 bg-gray-400 rounded-full mr-2"></span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mb-4 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Includes EIN:</span>
                  <span className={pkg.includes_ein ? 'text-green-600' : 'text-red-600'}>
                    {pkg.includes_ein ? 'Yes' : 'No'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Registered Agent:</span>
                  <span className={pkg.includes_registered_agent ? 'text-green-600' : 'text-red-600'}>
                    {pkg.includes_registered_agent ? 'Yes' : 'No'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Same Day Filing:</span>
                  <span className={pkg.same_day_filing ? 'text-green-600' : 'text-red-600'}>
                    {pkg.same_day_filing ? 'Yes' : 'No'}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-gray-600">Status:</span>
                <button
                  onClick={() => handleToggleActive(pkg.id, pkg.is_active)}
                  className={`px-2 py-1 rounded-full text-xs font-medium ${
                    pkg.is_active 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}
                >
                  {pkg.is_active ? 'Active' : 'Inactive'}
                </button>
              </div>

              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1"
                  onClick={() => startEdit(pkg)}
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Edit
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleDelete(pkg.id)}
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};