import React, { useEffect, useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { supabase } from '../../lib/supabase';
import { Users, DollarSign, TrendingUp, Eye, Edit, Trash2, Plus } from 'lucide-react';

interface AffiliateLink {
  id: string;
  user_id: string;
  code: string;
  clicks: number;
  conversions: number;
  commission_rate: number;
  total_earned: number;
  is_active: boolean;
  created_at: string;
  profiles?: {
    email: string;
    first_name?: string;
    last_name?: string;
  };
}

export const AffiliateManager: React.FC = () => {
  const [affiliates, setAffiliates] = useState<AffiliateLink[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAffiliates();
  }, []);

  const fetchAffiliates = async () => {
    try {
      const { data, error } = await supabase
        .from('affiliate_links')
        .select(`
          *,
          profiles!affiliate_links_user_id_profiles_fkey(email, first_name, last_name)
        `)
        .order('total_earned', { ascending: false });

      if (error) throw error;
      setAffiliates(data || []);
    } catch (error) {
      console.error('Error fetching affiliates:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleActive = async (id: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('affiliate_links')
        .update({ is_active: !isActive })
        .eq('id', id);

      if (error) throw error;
      fetchAffiliates();
    } catch (error) {
      console.error('Error updating affiliate:', error);
    }
  };

  const handleUpdateCommission = async (id: string, newRate: number) => {
    try {
      const { error } = await supabase
        .from('affiliate_links')
        .update({ commission_rate: newRate })
        .eq('id', id);

      if (error) throw error;
      fetchAffiliates();
    } catch (error) {
      console.error('Error updating commission:', error);
    }
  };

  const totalEarnings = affiliates.reduce((sum, affiliate) => sum + affiliate.total_earned, 0);
  const totalClicks = affiliates.reduce((sum, affiliate) => sum + affiliate.clicks, 0);
  const totalConversions = affiliates.reduce((sum, affiliate) => sum + affiliate.conversions, 0);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Affiliate Manager</h1>
          <p className="text-gray-600">Manage affiliate partners and commissions</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Affiliate
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <Users className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Affiliates</h3>
            <p className="text-2xl font-bold text-gray-900">{affiliates.length}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-green-100 p-3 rounded-full">
            <DollarSign className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Earnings</h3>
            <p className="text-2xl font-bold text-gray-900">${totalEarnings}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-yellow-100 p-3 rounded-full">
            <Eye className="h-6 w-6 text-yellow-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Total Clicks</h3>
            <p className="text-2xl font-bold text-gray-900">{totalClicks}</p>
          </div>
        </Card>
        <Card className="flex items-center space-x-4">
          <div className="bg-purple-100 p-3 rounded-full">
            <TrendingUp className="h-6 w-6 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Conversions</h3>
            <p className="text-2xl font-bold text-gray-900">{totalConversions}</p>
          </div>
        </Card>
      </div>

      {/* Affiliates Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Affiliate</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Code</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Clicks</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Conversions</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Commission</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Earned</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Status</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {affiliates.map((affiliate) => (
                <tr key={affiliate.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <div>
                      <p className="font-medium text-gray-900">
                        {affiliate.profiles?.first_name} {affiliate.profiles?.last_name}
                      </p>
                      <p className="text-sm text-gray-600">{affiliate.profiles?.email}</p>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono text-sm">{affiliate.code}</td>
                  <td className="py-3 px-4 text-gray-900">{affiliate.clicks}</td>
                  <td className="py-3 px-4 text-gray-900">{affiliate.conversions}</td>
                  <td className="py-3 px-4">
                    <input
                      type="number"
                      value={affiliate.commission_rate}
                      onChange={(e) => handleUpdateCommission(affiliate.id, parseFloat(e.target.value))}
                      className="w-16 px-2 py-1 border border-gray-300 rounded text-sm"
                      step="0.1"
                      min="0"
                      max="100"
                    />
                    <span className="text-sm text-gray-600 ml-1">%</span>
                  </td>
                  <td className="py-3 px-4 font-medium text-gray-900">${affiliate.total_earned}</td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => handleToggleActive(affiliate.id, affiliate.is_active)}
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        affiliate.is_active 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {affiliate.is_active ? 'Active' : 'Inactive'}
                    </button>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Performance Chart */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performers</h3>
        <div className="space-y-4">
          {affiliates
            .filter(a => a.total_earned > 0)
            .slice(0, 5)
            .map((affiliate, index) => (
              <div key={affiliate.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-blue-600 font-medium text-sm">#{index + 1}</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">
                      {affiliate.profiles?.first_name} {affiliate.profiles?.last_name}
                    </p>
                    <p className="text-sm text-gray-600">{affiliate.conversions} conversions</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">${affiliate.total_earned}</p>
                  <p className="text-sm text-gray-600">{affiliate.commission_rate}% rate</p>
                </div>
              </div>
            ))}
        </div>
      </Card>
    </div>
  );
};