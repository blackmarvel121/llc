import React from 'react';
import { HeroSection } from '../components/home/HeroSection';
import { TrustSection } from '../components/home/TrustSection';
import { ComparisonTable } from '../components/home/ComparisonTable';
import { PricingSection } from '../components/home/PricingSection';
import { TestimonialsSection } from '../components/home/TestimonialsSection';
import { FAQSection } from '../components/home/FAQSection';
import { WhatsAppButton } from '../components/home/WhatsAppButton';
import { UrgencyPopup } from '../components/home/UrgencyPopup';

export const Home: React.FC = () => {
  return (
    <>
      <HeroSection />
      <TrustSection />
      <ComparisonTable />
      <PricingSection />
      <TestimonialsSection />
      <FAQSection />
      <WhatsAppButton />
      <UrgencyPopup />
    </>
  );
};