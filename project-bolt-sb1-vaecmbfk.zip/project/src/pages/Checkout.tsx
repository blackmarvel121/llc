import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { Package, State, Addon } from '../types';
import { StripePaymentForm } from '../components/checkout/StripePaymentForm';
import { RazorpayPaymentForm } from '../components/checkout/RazorpayPaymentForm';
import { PayPalPaymentForm } from '../components/checkout/PayPalPaymentForm';
import { getEnabledPaymentGateways } from '../lib/payment';
import { 
  CreditCard, 
  Lock, 
  Check, 
  MapPin, 
  DollarSign, 
  Package as PackageIcon, 
  Plus, 
  Building, 
  User, 
  Mail, 
  Phone, 
  Home, 
  FileText, 
  Shield, 
  ArrowRight, 
  ArrowLeft,
  Zap,
  Star,
  Award,
  CreditCard as CreditCardIcon
} from 'lucide-react';

interface OrderSummary {
  package: Package | null;
  state: State | null;
  addons: Addon[];
  subtotal: number;
  stateFee: number;
  total: number;
}

type CheckoutStep = 
  | 'package' 
  | 'state' 
  | 'addons' 
  | 'company' 
  | 'personal' 
  | 'payment' 
  | 'confirmation';

export const Checkout: React.FC = () => {
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'razorpay' | 'paypal'>('stripe');
  const [enabledGateways, setEnabledGateways] = useState<string[]>([]);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, isAuthenticated } = useAuth();
  
  const [orderSummary, setOrderSummary] = useState<OrderSummary>({
    package: null,
    state: null,
    addons: [],
    subtotal: 0,
    stateFee: 0,
    total: 0
  });
  
  const [selectedPackageId, setSelectedPackageId] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [selectedAddons, setSelectedAddons] = useState<string[]>([]);
  const [includedAddons, setIncludedAddons] = useState<string[]>([]);
  const [excludedAddonCategories] = useState<string[]>([
    'tax', 'banking', 'compliance', 'legal'
  ]);
  const [excludedAddonNames] = useState<string[]>([
    'ITIN Application', 
    'Banking Resolution', 
    'Annual Report Filing',
    'Compliance Monitoring',
    'Business License Research',
    'Trademark Search'
  ]);
  const [isCheckingName, setIsCheckingName] = useState(false);
  const [isNameAvailable, setIsNameAvailable] = useState<boolean | null>(null);
  
  const [companyInfo, setCompanyInfo] = useState({
    companyName: '',
    businessType: 'llc',
    businessPurpose: '',
    numberOfMembers: '1'
  });
  
  const [personalInfo, setPersonalInfo] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: ''
  });
  
  const [paymentInfo, setPaymentInfo] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    nameOnCard: '',
    billingAddress: '',
    billingCity: '',
    billingState: '',
    billingZip: ''
  });
  
  const [loading, setLoading] = useState(false);
  const [packages, setPackages] = useState<Package[]>([]);
  const [states, setStates] = useState<State[]>([]);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [addons, setAddons] = useState<Addon[]>([]);
  const [step, setStep] = useState<CheckoutStep>('package');
  const [orderId, setOrderId] = useState<string | null>(null);

  // Featured states
  const featuredStates = [
    { code: 'WY', name: 'Wyoming', icon: <Zap className="h-5 w-5 text-purple-500" /> },
    { code: 'DE', name: 'Delaware', icon: <Star className="h-5 w-5 text-blue-500" /> },
    { code: 'CO', name: 'Colorado', icon: <Award className="h-5 w-5 text-green-500" /> }
  ];

  useEffect(() => {
    fetchData();
    fetchEnabledPaymentGateways();
    
    // Pre-fill personal info if user is logged in
    if (user) {
      setPersonalInfo(prev => ({
        ...prev,
        firstName: user.user_metadata?.first_name || '',
        lastName: user.user_metadata?.last_name || '',
        email: user.email || ''
      }));
    }
    
    // Get package from URL params
    const packageId = searchParams.get('package');
    if (packageId) {
      setSelectedPackageId(packageId);
    }
    
    // Get addon from URL params
    const addonId = searchParams.get('addon');
    if (addonId) {
      setSelectedAddons([addonId]);
    }
  }, [searchParams, user]);

  const fetchEnabledPaymentGateways = async () => {
    try {
      const gateways = await getEnabledPaymentGateways();
      const enabledTypes = gateways
        .filter(gateway => gateway.enabled)
        .map(gateway => gateway.type);
      setEnabledGateways(enabledTypes);
      
      // Set default payment method to the first enabled gateway
      if (enabledTypes.length > 0) {
        setPaymentMethod(enabledTypes[0] as 'stripe' | 'razorpay' | 'paypal');
      }
    } catch (error) {
      console.error('Error fetching enabled payment gateways:', error);
    }
  };

  useEffect(() => {
    if (packages.length > 0 && selectedPackageId) {
      const selectedPackage = packages.find(p => p.id === selectedPackageId);
      if (selectedPackage) {
        // Check for included addons in the package
        const includedAddonIds: string[] = [];
        if (selectedPackage.includes_ein) {
          const einAddon = addons.find(a => a.name.toLowerCase().includes('ein'));
          if (einAddon) includedAddonIds.push(einAddon.id);
        }
        if (selectedPackage.includes_registered_agent) {
          const raAddon = addons.find(a => a.name.toLowerCase().includes('registered agent'));
          if (raAddon) includedAddonIds.push(raAddon.id);
        }
        if (selectedPackage.same_day_filing) {
          const expeditedAddon = addons.find(a => a.name.toLowerCase().includes('expedited'));
          if (expeditedAddon) includedAddonIds.push(expeditedAddon.id);
        }
        setIncludedAddons(includedAddonIds);
        
        updateOrderSummary(selectedPackage, orderSummary.state, selectedAddons);
      }
    }
  }, [selectedPackageId, packages, addons]);

  const fetchData = async () => {
    try {
      const [packagesRes, statesRes, addonsRes] = await Promise.all([
        supabase.from('packages').select('*').eq('is_active', true).order('price', { ascending: true }),
        supabase.from('states').select('*').eq('is_active', true).order('name', { ascending: true }),
        supabase.from('addons')
          .select('*')
          .eq('is_active', true)
          .not('name', 'in', `(${excludedAddonNames.map(name => `"${name}"`).join(',')})`)
      ]);

      setPackages(packagesRes.data || []);
      setStates(statesRes.data || []);
      setAddons(addonsRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const updateOrderSummary = (pkg: Package | null, state: State | null, selectedAddonIds: string[]) => {
    const selectedAddonsData = addons.filter(addon => selectedAddonIds.includes(addon.id));
    const subtotal = (pkg?.price || 0) + selectedAddonsData.reduce((sum, addon) => sum + addon.price, 0);
    const stateFee = state?.filing_fee || 0;
    const total = subtotal + stateFee;

    setOrderSummary({
      package: pkg,
      state,
      addons: selectedAddonsData,
      subtotal,
      stateFee,
      total
    });
  };

  const handleStateChange = (stateId: string) => {
    setSelectedState(stateId);
    const state = states.find(s => s.id === stateId);
    updateOrderSummary(orderSummary.package, state || null, selectedAddons);
  };

  const handleAddonToggle = (addonId: string) => {
    const newSelectedAddons = selectedAddons.includes(addonId)
      ? selectedAddons.filter(id => id !== addonId)
      : [...selectedAddons, addonId];
    
    setSelectedAddons(newSelectedAddons);
    updateOrderSummary(orderSummary.package, orderSummary.state, newSelectedAddons);
  };

  const handlePackageSelect = (packageId: string) => {
    setSelectedPackageId(packageId);
    const pkg = packages.find(p => p.id === packageId);
    if (pkg) {
      updateOrderSummary(pkg, orderSummary.state, selectedAddons);
    }
  };

  const checkCompanyNameAvailability = async (name: string) => {
    if (!name.trim()) return;
    
    setIsCheckingName(true);
    setIsNameAvailable(null);
    
    try {
      // Simulate API call to check name availability
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // For demo purposes, we'll consider names with "LLC" already taken
      const available = !name.toLowerCase().includes('llc');
      setIsNameAvailable(available);
    } catch (error) {
      console.error('Error checking name availability:', error);
    } finally {
      setIsCheckingName(false);
    }
  };

  const handleNextStep = () => {
    switch (step) {
      case 'package':
        if (!selectedPackageId) {
          alert('Please select a package');
          return;
        }
        setStep('state');
        break;
      case 'state':
        if (!selectedState) {
          alert('Please select a state');
          return;
        }
        setStep('addons');
        break;
      case 'addons':
        setStep('company');
        break;
      case 'company':
        if (!companyInfo.companyName) {
          alert('Please enter a company name');
          return;
        }
        setStep('personal');
        break;
      case 'personal':
        if (!personalInfo.firstName || !personalInfo.lastName || !personalInfo.email) {
          alert('Please fill in all required personal information');
          return;
        }
        setStep('payment');
        break;
      case 'payment':
        // Payment is handled by the StripePaymentForm component
        break;
    }
  };

  const handlePreviousStep = () => {
    switch (step) {
      case 'state':
        setStep('package');
        break;
      case 'addons':
        setStep('state');
        break;
      case 'company':
        setStep('addons');
        break;
      case 'personal':
        setStep('company');
        break;
      case 'payment':
        setStep('personal');
        break;
    }
  };
  
  const handlePaymentComplete = async (paymentId: string) => {
    try {
      setPaymentError(null);
      
      // If user is not authenticated, store order info and redirect to auth
      if (!isAuthenticated) {
        // Store company and personal info in localStorage
        localStorage.setItem('checkoutEmail', personalInfo.email);
        localStorage.setItem('checkoutName', `${personalInfo.firstName} ${personalInfo.lastName}`);
        localStorage.setItem('pendingOrder', JSON.stringify({
          packageId: orderSummary.package?.id,
          stateId: selectedState,
          addons: selectedAddons,
          totalAmount: orderSummary.total,
          companyInfo,
          personalInfo
        }));
        
        navigate('/auth');
        return;
      }

      // Simulate payment processing (replace with actual Stripe integration)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Create order in database
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert([{
          user_id: user?.id,
          package_id: orderSummary.package?.id,
          state_id: selectedState,
          status: 'processing',
          payment_status: 'paid',
          total_amount: orderSummary.total * 100, // Store in cents
          company_name: companyInfo.companyName || '',
          payment_method: 'credit_card',
          payment_id: paymentId
        }])
        .select()
        .single();

      if (orderError) throw orderError;

      // Add order addons
      if (selectedAddons.length > 0) {
        const orderAddons = selectedAddons.map(addonId => {
          const addon = addons.find(a => a.id === addonId);
          return {
            order_id: order.id,
            addon_id: addonId,
            price: addon?.price || 0
          };
        });

        await supabase.from('order_addons').insert(orderAddons);
      }

      setOrderId(order.id);
      setStep('confirmation');
      
      // Clear any pending order data
      localStorage.removeItem('pendingOrder');
      localStorage.removeItem('checkoutEmail');
      localStorage.removeItem('checkoutName');
      
    } catch (error) {
      console.error('Order creation error:', error);
      setPaymentError('Failed to create order. Please try again.');
    }
  };

  const renderStepIndicator = () => {
    const steps = [
      { key: 'package', label: 'Package', icon: PackageIcon },
      { key: 'state', label: 'State', icon: MapPin },
      { key: 'addons', label: 'Add-ons', icon: Plus },
      { key: 'company', label: 'Company', icon: Building },
      { key: 'personal', label: 'Personal', icon: User },
      { key: 'payment', label: 'Payment', icon: CreditCard },
      { key: 'confirmation', label: 'Confirm', icon: Check }
    ];

    return (
      <div className="mb-8">
        <div className="hidden md:flex items-center justify-between">
          {steps.map((s, index) => {
            const StepIcon = s.icon;
            const isActive = s.key === step;
            const isCompleted = steps.findIndex(x => x.key === step) > index;
            
            return (
              <React.Fragment key={s.key}>
                {index > 0 && (
                  <div className={`flex-1 h-1 ${isCompleted ? 'bg-blue-500' : 'bg-gray-200'}`}></div>
                )}
                <div className="flex flex-col items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    isActive ? 'bg-blue-500 text-white' : 
                    isCompleted ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {isCompleted ? <Check className="h-5 w-5" /> : <StepIcon className="h-5 w-5" />}
                  </div>
                  <span className={`text-xs mt-1 ${isActive ? 'text-blue-600 font-medium' : 'text-gray-500'}`}>
                    {s.label}
                  </span>
                </div>
              </React.Fragment>
            );
          })}
        </div>
        
        {/* Mobile step indicator */}
        <div className="md:hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">
              Step {steps.findIndex(s => s.key === step) + 1} of {steps.length}
            </span>
            <span className="text-sm font-medium text-blue-600">
              {steps.find(s => s.key === step)?.label}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-blue-500 h-2.5 rounded-full" 
              style={{ width: `${((steps.findIndex(s => s.key === step) + 1) / steps.length) * 100}%` }}
            ></div>
          </div>
        </div>
      </div>
    );
  };

  if (step === 'confirmation') {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="text-center py-12">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Order Confirmed!
            </h1>
            
            <p className="text-lg text-gray-600 mb-6">
              Thank you for your order. We'll begin processing your LLC formation immediately.
            </p>
            
            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <h3 className="font-semibold text-gray-900 mb-4">Order Summary</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Order ID:</span>
                  <span className="font-mono">#{orderId?.slice(0, 8)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Package:</span>
                  <span>{orderSummary.package?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>State:</span>
                  <span>{orderSummary.state?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Company Name:</span>
                  <span>{companyInfo.companyName}</span>
                </div>
                <div className="flex justify-between font-semibold">
                  <span>Total:</span>
                  <span>${orderSummary.total}</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-blue-900 mb-2">What happens next?</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• We'll file your LLC within 24 hours</li>
                  <li>• You'll receive email updates on progress</li>
                  <li>• Track your order in your dashboard</li>
                  <li>• Documents will be available once approved</li>
                </ul>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button onClick={() => navigate('/dashboard')}>
                  Go to Dashboard
                </Button>
                <Button variant="outline" onClick={() => navigate('/')}>
                  Back to Home
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {renderStepIndicator()}
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Card>
              {step === 'package' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">Select Your Package</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {packages.map(pkg => (
                      <div
                        key={pkg.id}
                        className={`border-2 rounded-lg p-6 cursor-pointer transition-all ${
                          selectedPackageId === pkg.id
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => handlePackageSelect(pkg.id)}
                      >
                        <div className="text-center">
                          {pkg.is_popular && (
                            <div className="bg-blue-500 text-white text-xs font-bold py-1 px-2 rounded-full mb-2 inline-block">MOST POPULAR</div>
                          )}
                          <h3 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                          <p className="text-gray-600 text-sm mb-3">{pkg.description}</p>
                          <div className="text-center mb-4">
                            <p className="text-3xl font-bold text-blue-600">${pkg.price}</p>
                            <p className="text-sm text-gray-500">+ state filing fee</p>
                          </div>
                          <div className="space-y-2 mb-4">
                            {pkg.features.slice(0, 3).map((feature, idx) => (
                              <div key={idx} className="flex items-center text-sm">
                                <Check className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                                <span className="text-left">{feature}</span>
                              </div>
                            ))}
                          </div>
                          <Button 
                            size="sm" 
                            className="w-full"
                            variant={selectedPackageId === pkg.id ? "primary" : "outline"}
                            onClick={() => handlePackageSelect(pkg.id)}
                          >
                            {selectedPackageId === pkg.id ? 'Selected' : 'Select'}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {step === 'state' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">Select Your State</h2>
                  <p className="text-gray-600 mb-6">
                    Choose the state where you want to form your LLC. Each state has different filing fees and processing times.
                  </p>
                  
                  {/* Featured States */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    {featuredStates.map((featuredState) => {
                      const stateData = states.find(s => s.code === featuredState.code);
                      if (!stateData) return null;
                      
                      return (
                        <div 
                          key={stateData.id}
                          className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                            selectedState === stateData.id
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          onClick={() => handleStateChange(stateData.id)}
                        >
                          <div className="flex items-center space-x-3 mb-2">
                            {featuredState.icon}
                            <h3 className="font-semibold text-gray-900">{stateData.name}</h3>
                          </div>
                          <div className="space-y-1 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Filing Fee:</span>
                              <span className="font-medium">${stateData.filing_fee}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Processing:</span>
                              <span className="font-medium">{stateData.turnaround_time}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  
                  <p className="text-gray-600 mb-3 font-medium">Other States</p>
                  <div className="mb-6">
                    <select
                      value={selectedState}
                      onChange={(e) => handleStateChange(e.target.value)}
                      className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Choose a state...</option>
                      {states.map(state => (
                        <option key={state.id} value={state.id}>
                          {state.name} - ${state.filing_fee} filing fee
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  {selectedState && (
                    <div className="bg-blue-50 p-4 rounded-lg mb-6">
                      <h3 className="font-semibold text-gray-900 mb-2">State Information</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-600">Filing Fee</p>
                          <p className="font-medium text-gray-900">
                            ${orderSummary.state?.filing_fee}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Processing Time</p>
                          <p className="font-medium text-gray-900">
                            {orderSummary.state?.turnaround_time}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {step === 'addons' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">Add-on Services</h2>
                  <p className="text-gray-600 mb-6">
                    Enhance your LLC formation with these additional services. 
                    {includedAddons.length > 0 && (
                      <span className="text-blue-600 font-medium">
                        Some add-ons are already included in your selected package.
                      </span>
                    )}
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    {addons
                      .filter(addon => {
                        // Filter out excluded add-ons by name or category
                        return !excludedAddonNames.includes(addon.name) && 
                               !excludedAddonCategories.includes(addon.category.toLowerCase());
                      })
                      .map(addon => {
                      const isIncluded = includedAddons.includes(addon.id);
                      return (
                        <div
                          key={addon.id}
                          className={`border-2 rounded-lg p-4 transition-all ${
                            isIncluded 
                              ? 'border-green-500 bg-green-50'
                              : selectedAddons.includes(addon.id)
                                ? 'border-blue-500 bg-blue-50 cursor-pointer'
                                : 'border-gray-200 hover:border-gray-300 cursor-pointer'
                          }`}
                          onClick={() => !isIncluded && handleAddonToggle(addon.id)}
                        >
                          <div className="text-center">
                            <h4 className="font-medium text-gray-900 mb-2">{addon.name}</h4>
                            <p className="text-sm text-gray-600 mb-3">{addon.description}</p>
                            <div className="flex justify-between items-center mb-3">
                              <span className="font-bold text-gray-900">${addon.price}</span>
                              <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded capitalize">
                                {addon.category}
                              </span>
                            </div>
                            {isIncluded ? (
                              <div className="w-full px-3 py-1 rounded-full text-xs font-medium bg-green-500 text-white">
                                Included in Package ✓
                              </div>
                            ) : (
                              <button
                                className={`w-full px-3 py-1 rounded-full text-xs font-medium ${
                                  selectedAddons.includes(addon.id)
                                    ? 'bg-blue-500 text-white'
                                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                }`}
                              >
                                {selectedAddons.includes(addon.id) ? 'Added ✓' : 'Add to Order'}
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {step === 'company' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">Company Information</h2>
                  <p className="text-gray-600 mb-6">
                    Tell us about your new company.
                  </p>
                  
                  <div className="space-y-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Company Name *
                      </label>
                      <div className="flex space-x-2">
                        <div className="flex-1">
                          <input
                            type="text"
                            placeholder="Your LLC Name"
                            value={companyInfo.companyName}
                            onChange={(e) => {
                              setCompanyInfo({...companyInfo, companyName: e.target.value});
                              setIsNameAvailable(null);
                            }}
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                              isNameAvailable === true ? 'border-green-300' :
                              isNameAvailable === false ? 'border-red-300' :
                              'border-gray-300'
                            }`}
                            required
                          />
                          {isNameAvailable !== null && (
                            <div className={`mt-1 text-sm ${isNameAvailable ? 'text-green-600' : 'text-red-600'}`}>
                              {isNameAvailable 
                                ? 'Company name is available!' 
                                : 'This name is already taken. Please try another.'}
                            </div>
                          )}
                        </div>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => checkCompanyNameAvailability(companyInfo.companyName)}
                          disabled={isCheckingName || !companyInfo.companyName}
                          loading={isCheckingName}
                        >
                          Check Availability
                        </Button>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Business Type
                      </label>
                      <select
                        value={companyInfo.businessType}
                        onChange={(e) => setCompanyInfo({...companyInfo, businessType: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="llc">Limited Liability Company (LLC)</option>
                        <option value="corporation">Corporation</option>
                        <option value="nonprofit">Non-Profit</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Business Purpose
                      </label>
                      <textarea
                        placeholder="Describe your business activities"
                        value={companyInfo.businessPurpose}
                        onChange={(e) => setCompanyInfo({...companyInfo, businessPurpose: e.target.value})}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Number of Members/Owners
                      </label>
                      <select
                        value={companyInfo.numberOfMembers}
                        onChange={(e) => setCompanyInfo({...companyInfo, numberOfMembers: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="1">1 (Single Member)</option>
                        <option value="2">2 Members</option>
                        <option value="3-5">3-5 Members</option>
                        <option value="6+">6+ Members</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {step === 'personal' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">Personal Information</h2>
                  <p className="text-gray-600 mb-4">
                    Please provide your contact information.
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        First Name *
                      </label>
                      <input
                        type="text"
                        placeholder="First Name"
                        value={personalInfo.firstName}
                        onChange={(e) => setPersonalInfo({...personalInfo, firstName: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Last Name *
                      </label>
                      <input
                        type="text"
                        placeholder="Last Name"
                        value={personalInfo.lastName}
                        onChange={(e) => setPersonalInfo({...personalInfo, lastName: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        placeholder="Email"
                        value={personalInfo.email}
                        onChange={(e) => setPersonalInfo({...personalInfo, email: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        placeholder="Phone"
                        value={personalInfo.phone}
                        onChange={(e) => setPersonalInfo({...personalInfo, phone: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 'payment' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">Payment Information</h2>
                  
                  {paymentError && (
                    <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg mb-6">
                      {paymentError}
                    </div>
                  )}
                  
                  {/* Payment Method Selection */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Select Payment Method {enabledGateways.length === 0 && '(No payment methods available)'}
                    </label>
                    <div className={`grid grid-cols-${Math.min(enabledGateways.length || 1, 3)} gap-4`}>
                      {enabledGateways.includes('stripe') && (
                        <div
                          className={`border-2 rounded-lg p-4 cursor-pointer flex items-center space-x-3 ${
                            paymentMethod === 'stripe'
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          onClick={() => setPaymentMethod('stripe')}
                        >
                          <CreditCardIcon className="h-5 w-5 text-blue-600" />
                          <div>
                            <p className="font-medium text-gray-900">Credit/Debit Card</p>
                            <p className="text-xs text-gray-600">Pay with Stripe</p>
                          </div>
                        </div>
                      )}
                      
                      {enabledGateways.includes('razorpay') && (
                        <div
                          className={`border-2 rounded-lg p-4 cursor-pointer flex items-center space-x-3 ${
                            paymentMethod === 'razorpay'
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          onClick={() => setPaymentMethod('razorpay')}
                        >
                          <img 
                            src="https://razorpay.com/favicon.png" 
                            alt="Razorpay" 
                            className="h-5 w-5"
                          />
                          <div>
                            <p className="font-medium text-gray-900">Razorpay</p>
                            <p className="text-xs text-gray-600">UPI, Cards, NetBanking</p>
                          </div>
                        </div>
                      )}
                      
                      {enabledGateways.includes('paypal') && (
                        <div
                          className={`border-2 rounded-lg p-4 cursor-pointer flex items-center space-x-3 ${
                            paymentMethod === 'paypal'
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          onClick={() => setPaymentMethod('paypal')}
                        >
                          <img 
                            src="https://cdn.pixabay.com/photo/2015/05/26/09/37/paypal-784404_1280.png" 
                            alt="PayPal" 
                            className="h-5 w-5"
                          />
                          <div>
                            <p className="font-medium text-gray-900">PayPal</p>
                            <p className="text-xs text-gray-600">Fast & Secure</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {enabledGateways.length === 0 ? (
                    <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg text-yellow-800">
                      <p className="font-medium">Payment systems are currently unavailable</p>
                      <p className="text-sm mt-1">Please try again later or contact support for assistance.</p>
                    </div>
                  ) : paymentMethod === 'stripe' ? (
                    <StripePaymentForm 
                      onPaymentComplete={handlePaymentComplete}
                      amount={orderSummary.total}
                      isLoading={loading}
                      setIsLoading={setLoading}
                    />
                  ) : paymentMethod === 'razorpay' ? (
                    <RazorpayPaymentForm 
                      onPaymentComplete={handlePaymentComplete}
                      amount={orderSummary.total}
                      isLoading={loading}
                      setIsLoading={setLoading}
                    />
                  ) : (
                    <PayPalPaymentForm 
                      onPaymentComplete={handlePaymentComplete}
                      amount={orderSummary.total}
                      isLoading={loading}
                      setIsLoading={setLoading}
                    />
                  )}
                </div>
              )}

              <div className="flex justify-between mt-6 pt-4">
                {step !== 'package' && (
                  <Button variant="outline" onClick={handlePreviousStep}>
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Back
                  </Button>
                )}
                <div className={step === 'package' ? 'ml-auto' : ''}>
                  <Button onClick={handleNextStep} loading={loading && step === 'payment'}>
                    {step === 'payment' && enabledGateways.length === 0 ? 'Contact Support' : 'Continue'}
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h3>
              
              {orderSummary.package ? (
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <PackageIcon className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium text-gray-900">{orderSummary.package.name} Package</p>
                      <p className="text-sm text-gray-600">${orderSummary.package.price}</p>
                    </div>
                  </div>
                  
                  {orderSummary.state && (
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <MapPin className="h-5 w-5 text-gray-600" />
                      <div>
                        <p className="font-medium text-gray-900">{orderSummary.state.name} Filing Fee</p>
                        <p className="text-sm text-gray-600">${orderSummary.state.filing_fee}</p>
                      </div>
                    </div>
                  )}
                  
                  {orderSummary.addons.length > 0 && (
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-2">Add-on Services:</p>
                      {orderSummary.addons.map(addon => {
                        const isIncluded = includedAddons.includes(addon.id);
                        return (
                          <div key={addon.id} className={`flex items-center space-x-3 p-3 ${isIncluded ? 'bg-green-50' : 'bg-gray-50'} rounded-lg mb-2`}>
                            <Plus className={`h-5 w-5 ${isIncluded ? 'text-green-600' : 'text-gray-600'}`} />
                            <div>
                              <p className="font-medium text-gray-900">{addon.name}</p>
                              {isIncluded ? (
                                <p className="text-sm text-green-600">Included in package</p>
                              ) : (
                                <p className="text-sm text-gray-600">${addon.price}</p>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                  
                  <div className="border-t pt-4 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Subtotal:</span>
                      <span className="text-gray-900">${orderSummary.subtotal}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">State Filing Fee:</span>
                      <span className="text-gray-900">${orderSummary.stateFee}</span>
                    </div>
                    <div className="flex justify-between text-lg font-semibold">
                      <span>Total:</span>
                      <span>${orderSummary.total}</span>
                    </div>
                  </div>
                  
                  <div className="bg-green-50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Shield className="h-5 w-5 text-green-600" />
                      <span className="text-sm text-green-700 font-medium">100% Satisfaction Guarantee</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <PackageIcon className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                  <p>Select a package to see your order summary</p>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};