import React from 'react';
import { Card } from '../components/ui/Card';

export const Terms: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card className="p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Terms of Service</h1>
          
          <div className="prose prose-gray max-w-none">
            <p className="text-gray-600 mb-6">
              <strong>Last Updated:</strong> January 1, 2024
            </p>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">1. Acceptance of Terms</h2>
              <p className="text-gray-700 mb-4">
                By accessing and using Razorfile's services, you accept and agree to be bound by the terms and provision of this agreement. 
                If you do not agree to abide by the above, please do not use this service.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">2. Services Provided</h2>
              <p className="text-gray-700 mb-4">
                Razorfile provides LLC formation services, including but not limited to:
              </p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Preparation and filing of Articles of Organization</li>
                <li>Registered agent services</li>
                <li>EIN application assistance</li>
                <li>Operating agreement templates</li>
                <li>Compliance monitoring and reminders</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">3. Payment Terms</h2>
              <p className="text-gray-700 mb-4">
                Payment is due at the time of order placement. We accept major credit cards and other payment methods as displayed on our website. 
                State filing fees are separate from our service fees and are paid directly to the respective state agencies.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">4. Refund Policy</h2>
              <p className="text-gray-700 mb-4">
                We offer a 30-day money-back guarantee on our service fees. State filing fees paid to government agencies are non-refundable. 
                Refund requests must be submitted within 30 days of order placement.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">5. Service Timeline</h2>
              <p className="text-gray-700 mb-4">
                We guarantee to file your LLC documents within 24 hours of receiving your completed order and payment. 
                State processing times vary and are beyond our control. Expedited processing options may be available for additional fees.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">6. Limitation of Liability</h2>
              <p className="text-gray-700 mb-4">
                Razorfile's liability is limited to the amount paid for our services. We are not liable for any indirect, incidental, 
                special, or consequential damages arising from the use of our services.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">7. Privacy</h2>
              <p className="text-gray-700 mb-4">
                Your privacy is important to us. Please review our Privacy Policy, which also governs your use of the service, 
                to understand our practices.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">8. Modifications</h2>
              <p className="text-gray-700 mb-4">
                Razorfile reserves the right to modify these terms at any time. Changes will be effective immediately upon posting 
                on our website. Your continued use of the service constitutes acceptance of the modified terms.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">9. Contact Information</h2>
              <p className="text-gray-700 mb-4">
                If you have any questions about these Terms of Service, please contact us at:
              </p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700">
                  <strong>Email:</strong> support@razorfile.com<br />
                  <strong>Phone:</strong> 1-800-RAZORFILE<br />
                  <strong>Address:</strong> 123 Business Ave, Suite 100, Business City, BC 12345
                </p>
              </div>
            </section>
          </div>
        </Card>
      </div>
    </div>
  );
};