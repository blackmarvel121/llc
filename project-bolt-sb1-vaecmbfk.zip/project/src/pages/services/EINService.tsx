import React, { useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Check, CreditCard, Shield, Clock, FileText, DollarSign, Users, Building } from 'lucide-react';
import { Link } from 'react-router-dom';

export const EINService: React.FC = () => {
  const [selectedPackage, setSelectedPackage] = useState<'standard' | 'expedited'>('standard');

  const packages = [
    {
      id: 'standard',
      name: 'Standard EIN',
      price: 49,
      originalPrice: 275,
      timeline: '7-10 business days',
      description: 'Perfect for most businesses',
      features: [
        'IRS EIN Application Filing',
        'Federal Tax ID Number',
        'Email Delivery of EIN',
        'EIN Confirmation Letter',
        'Customer Support',
        'Money-Back Guarantee'
      ],
      popular: false
    },
    {
      id: 'expedited',
      name: 'Expedited EIN',
      price: 149,
      originalPrice: 375,
      timeline: '1-2 business days',
      description: 'Fast-track your EIN application',
      features: [
        'Everything in Standard',
        'Priority Processing',
        'Expedited IRS Filing',
        'Same-Day Application Review',
        'Phone Support',
        'Rush Delivery Guarantee'
      ],
      popular: true
    }
  ];

  const benefits = [
    {
      icon: Building,
      title: 'Open Business Bank Account',
      description: 'Required by most banks to open a business account'
    },
    {
      icon: FileText,
      title: 'File Business Taxes',
      description: 'Essential for tax filing and business operations'
    },
    {
      icon: Users,
      title: 'Hire Employees',
      description: 'Mandatory if you plan to have employees'
    },
    {
      icon: Shield,
      title: 'Separate Business Identity',
      description: 'Keeps your business and personal finances separate'
    }
  ];

  const handleCheckout = (packageType: 'standard' | 'expedited') => {
    const selectedPkg = packages.find(p => p.id === packageType);
    if (selectedPkg) {
      // Navigate to checkout with EIN service parameters
      window.location.href = `/checkout?service=ein&package=${packageType}&price=${selectedPkg.price}`;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <FileText className="h-4 w-4" />
            <span>EIN Number Service</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Get Your Federal Tax ID (EIN) Number
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            An Employer Identification Number (EIN) is required to open business bank accounts, 
            file taxes, and hire employees. Get yours quickly and easily.
          </p>
          
          {/* Trust indicators */}
          <div className="flex justify-center items-center space-x-8 text-sm text-gray-600 mb-8">
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-green-500" />
              <span>IRS Authorized</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-blue-500" />
              <span>Fast Processing</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="h-5 w-5 text-purple-500" />
              <span>Guaranteed Approval</span>
            </div>
          </div>
        </div>

        {/* Why You Need an EIN */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            Why Your Business Needs an EIN
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-all duration-300">
                  <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">
                    {benefit.title}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {benefit.description}
                  </p>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Pricing Packages */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            Choose Your EIN Package
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {packages.map((pkg) => (
              <Card 
                key={pkg.id}
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-2xl ${
                  pkg.popular ? 'ring-2 ring-blue-500 scale-105' : ''
                }`}
              >
                {pkg.popular && (
                  <div className="absolute top-0 left-0 right-0 bg-blue-500 text-white text-center py-2 text-sm font-bold">
                    MOST POPULAR
                  </div>
                )}
                
                <div className={`${pkg.popular ? 'pt-12' : 'pt-6'} pb-6`}>
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      {pkg.name}
                    </h3>
                    <p className="text-gray-600 mb-4">{pkg.description}</p>
                    
                    <div className="mb-4">
                      <div className="flex items-center justify-center mb-2">
                        <span className="text-4xl font-bold text-gray-900">
                          ${pkg.price}
                        </span>
                      </div>
                      <div className="text-gray-600 text-sm">
                        <span className="line-through">${pkg.originalPrice}</span>
                        <span className="text-green-600 font-medium ml-2">
                          Save ${pkg.originalPrice - pkg.price}!
                        </span>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-3 mb-6">
                      <div className="flex items-center justify-center space-x-2">
                        <Clock className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-gray-900">{pkg.timeline}</span>
                      </div>
                    </div>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button 
                    className={`w-full text-lg py-3 ${
                      pkg.popular 
                        ? 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800' 
                        : ''
                    }`}
                    variant={pkg.popular ? 'primary' : 'outline'}
                    onClick={() => handleCheckout(pkg.id as 'standard' | 'expedited')}
                  >
                    Get My EIN Now
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Process Steps */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            How It Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-blue-600 font-bold text-xl">1</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Complete Application</h3>
              <p className="text-gray-600">
                Fill out our simple form with your business information
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-green-600 font-bold text-xl">2</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">We File with IRS</h3>
              <p className="text-gray-600">
                Our experts submit your application to the IRS
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-purple-600 font-bold text-xl">3</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Receive Your EIN</h3>
              <p className="text-gray-600">
                Get your EIN number and official confirmation letter
              </p>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <Card className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                What is an EIN and do I need one?
              </h3>
              <p className="text-gray-600">
                An EIN (Employer Identification Number) is a unique 9-digit number assigned by the IRS to identify your business for tax purposes. You need one to open a business bank account, file taxes, hire employees, or apply for business licenses.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                How long does it take to get an EIN?
              </h3>
              <p className="text-gray-600">
                With our standard service, you'll receive your EIN in 7-10 business days. Our expedited service delivers your EIN in 1-2 business days.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                Can I apply for an EIN myself?
              </h3>
              <p className="text-gray-600">
                Yes, you can apply directly with the IRS, but it can be time-consuming and confusing. Our service handles everything for you and ensures your application is completed correctly the first time.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                Is there a money-back guarantee?
              </h3>
              <p className="text-gray-600">
                Yes! We offer a 100% money-back guarantee. If we can't get your EIN approved, we'll refund your service fee completely.
              </p>
            </div>
          </div>
        </Card>

        {/* CTA Section */}
        <div className="text-center">
          <Card className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Get Your EIN?
            </h2>
            <p className="text-blue-100 mb-6 text-lg">
              Join thousands of businesses who trust us with their EIN applications
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                className="bg-white text-blue-600 hover:bg-gray-100"
                onClick={() => handleCheckout('standard')}
              >
                Get Standard EIN - $49
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-600"
                onClick={() => handleCheckout('expedited')}
              >
                Get Expedited EIN - $149
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};