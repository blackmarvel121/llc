import React, { useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Check, Calculator, TrendingUp, FileText, DollarSign, Clock, Shield, BarChart3 } from 'lucide-react';

export const BookkeepingService: React.FC = () => {
  const [selectedPackage, setSelectedPackage] = useState<'basic' | 'standard' | 'premium'>('standard');

  const packages = [
    {
      id: 'basic',
      name: 'Basic Bookkeeping',
      price: 149,
      period: '/month',
      description: 'Essential bookkeeping for small businesses',
      features: [
        'Monthly Financial Statements',
        'Expense Categorization',
        'Bank Reconciliation',
        'Basic Tax Preparation Support',
        'QuickBooks Setup',
        'Email Support'
      ],
      transactions: 'Up to 50 transactions/month',
      popular: false
    },
    {
      id: 'standard',
      name: 'Standard Bookkeeping',
      price: 249,
      period: '/month',
      description: 'Complete bookkeeping solution',
      features: [
        'Everything in Basic',
        'Accounts Payable/Receivable',
        'Payroll Processing',
        'Sales Tax Returns',
        'Financial Analysis Reports',
        'Phone Support',
        'Quarterly Business Reviews'
      ],
      transactions: 'Up to 200 transactions/month',
      popular: true
    },
    {
      id: 'premium',
      name: 'Premium Bookkeeping',
      price: 399,
      period: '/month',
      description: 'Full-service financial management',
      features: [
        'Everything in Standard',
        'CFO-Level Financial Analysis',
        'Budget Planning & Forecasting',
        'Cash Flow Management',
        'Tax Planning Strategies',
        'Dedicated Account Manager',
        'Weekly Financial Check-ins'
      ],
      transactions: 'Unlimited transactions',
      popular: false
    }
  ];

  const services = [
    {
      icon: Calculator,
      title: 'Accurate Bookkeeping',
      description: 'Professional recording of all business transactions'
    },
    {
      icon: FileText,
      title: 'Financial Statements',
      description: 'Monthly P&L, balance sheets, and cash flow statements'
    },
    {
      icon: TrendingUp,
      title: 'Financial Analysis',
      description: 'Insights to help grow your business profitably'
    },
    {
      icon: BarChart3,
      title: 'Tax Preparation',
      description: 'Year-round tax planning and preparation support'
    }
  ];

  const benefits = [
    'Save 10+ hours per week on bookkeeping',
    'Always tax-ready with organized records',
    'Make better business decisions with accurate data',
    'Reduce stress and focus on growing your business',
    'Professional financial statements for loans/investors',
    'Avoid costly accounting errors and penalties'
  ];

  const handleCheckout = (packageType: 'basic' | 'standard' | 'premium') => {
    const selectedPkg = packages.find(p => p.id === packageType);
    if (selectedPkg) {
      window.location.href = `/checkout?service=bookkeeping&package=${packageType}&price=${selectedPkg.price}`;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Calculator className="h-4 w-4" />
            <span>Professional Bookkeeping</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Professional Bookkeeping Services
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Focus on growing your business while we handle your books. Our certified bookkeepers 
            provide accurate, timely financial records and insights to help your business thrive.
          </p>
          
          {/* Trust indicators */}
          <div className="flex justify-center items-center space-x-8 text-sm text-gray-600 mb-8">
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-green-500" />
              <span>Certified Bookkeepers</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-blue-500" />
              <span>Monthly Reports</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="h-5 w-5 text-purple-500" />
              <span>Tax-Ready Books</span>
            </div>
          </div>
        </div>

        {/* Services Overview */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            What We Do For You
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-all duration-300">
                  <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {service.description}
                  </p>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Benefits */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            Why Choose Our Bookkeeping Service?
          </h2>
          <Card className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{benefit}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Pricing Packages */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            Choose Your Bookkeeping Package
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {packages.map((pkg) => (
              <Card 
                key={pkg.id}
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-2xl ${
                  pkg.popular ? 'ring-2 ring-green-500 scale-105' : ''
                }`}
              >
                {pkg.popular && (
                  <div className="absolute top-0 left-0 right-0 bg-green-500 text-white text-center py-2 text-sm font-bold">
                    MOST POPULAR
                  </div>
                )}
                
                <div className={`${pkg.popular ? 'pt-12' : 'pt-6'} pb-6`}>
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      {pkg.name}
                    </h3>
                    <p className="text-gray-600 mb-4">{pkg.description}</p>
                    
                    <div className="mb-4">
                      <div className="flex items-center justify-center mb-2">
                        <span className="text-4xl font-bold text-gray-900">
                          ${pkg.price}
                        </span>
                        <span className="text-gray-600 ml-1">{pkg.period}</span>
                      </div>
                      <div className="text-sm text-gray-600">
                        {pkg.transactions}
                      </div>
                    </div>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button 
                    className={`w-full text-lg py-3 ${
                      pkg.popular 
                        ? 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800' 
                        : ''
                    }`}
                    variant={pkg.popular ? 'primary' : 'outline'}
                    onClick={() => handleCheckout(pkg.id as 'basic' | 'standard' | 'premium')}
                  >
                    Get Started
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Process */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            How It Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-green-600 font-bold text-xl">1</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Setup & Onboarding</h3>
              <p className="text-gray-600 text-sm">
                We connect to your bank accounts and set up your chart of accounts
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-green-600 font-bold text-xl">2</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Monthly Bookkeeping</h3>
              <p className="text-gray-600 text-sm">
                Our team categorizes transactions and reconciles accounts
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-green-600 font-bold text-xl">3</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Financial Reports</h3>
              <p className="text-gray-600 text-sm">
                Receive detailed financial statements and insights
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-green-600 font-bold text-xl">4</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Ongoing Support</h3>
              <p className="text-gray-600 text-sm">
                Get answers to questions and strategic financial advice
              </p>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <Card className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                What accounting software do you use?
              </h3>
              <p className="text-gray-600">
                We primarily use QuickBooks Online, but we can work with other platforms like Xero, FreshBooks, or Wave depending on your needs and preferences.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                How quickly will I receive my financial reports?
              </h3>
              <p className="text-gray-600">
                Monthly financial statements are typically delivered by the 15th of the following month. We can provide faster turnaround times for premium clients.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                Do you handle sales tax returns?
              </h3>
              <p className="text-gray-600">
                Yes, our Standard and Premium packages include sales tax return preparation and filing for most states. We'll ensure you stay compliant with all tax obligations.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                Can you help with tax preparation?
              </h3>
              <p className="text-gray-600">
                Absolutely! We maintain tax-ready books year-round and can either prepare your taxes or work closely with your CPA to ensure a smooth tax season.
              </p>
            </div>
          </div>
        </Card>

        {/* CTA Section */}
        <div className="text-center">
          <Card className="bg-gradient-to-r from-green-600 to-green-700 text-white">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Get Your Books in Order?
            </h2>
            <p className="text-green-100 mb-6 text-lg">
              Join hundreds of businesses who trust us with their bookkeeping
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                className="bg-white text-green-600 hover:bg-gray-100"
                onClick={() => handleCheckout('basic')}
              >
                Start Basic - $149/mo
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-green-600"
                onClick={() => handleCheckout('standard')}
              >
                Start Standard - $249/mo
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};