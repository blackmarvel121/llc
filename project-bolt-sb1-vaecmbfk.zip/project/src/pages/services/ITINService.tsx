import React, { useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Check, CreditCard, Shield, Clock, FileText, DollarSign, Users, Globe, AlertCircle } from 'lucide-react';

export const ITINService: React.FC = () => {
  const [selectedPackage, setSelectedPackage] = useState<'standard' | 'premium'>('standard');

  const packages = [
    {
      id: 'standard',
      name: 'Standard ITIN',
      price: 199,
      originalPrice: 450,
      timeline: '6-10 weeks',
      description: 'Complete ITIN application service',
      features: [
        'Form W-7 Preparation',
        'Document Review & Certification',
        'IRS Application Submission',
        'Status Tracking',
        'Customer Support',
        'Money-Back Guarantee'
      ],
      popular: false
    },
    {
      id: 'premium',
      name: 'Premium ITIN',
      price: 299,
      originalPrice: 550,
      timeline: '4-6 weeks',
      description: 'Expedited with certified acceptance agent',
      features: [
        'Everything in Standard',
        'Certified Acceptance Agent Review',
        'Priority Processing',
        'Document Return Service',
        'Phone Consultation',
        'Expedited Timeline'
      ],
      popular: true
    }
  ];

  const whoNeedsITIN = [
    {
      icon: Globe,
      title: 'Non-US Residents',
      description: 'Foreign individuals who need to file US tax returns'
    },
    {
      icon: Users,
      title: 'Dependents & Spouses',
      description: 'Family members of US taxpayers who cannot get SSN'
    },
    {
      icon: DollarSign,
      title: 'Investment Income',
      description: 'Foreign investors receiving US-source income'
    },
    {
      icon: FileText,
      title: 'Business Owners',
      description: 'Non-residents starting US businesses'
    }
  ];

  const requirements = [
    'Valid passport or national identification document',
    'Completed Form W-7 (we prepare this for you)',
    'Tax return or other IRS documentation',
    'Proof of foreign status (if applicable)',
    'Supporting identification documents'
  ];

  const handleCheckout = (packageType: 'standard' | 'premium') => {
    const selectedPkg = packages.find(p => p.id === packageType);
    if (selectedPkg) {
      window.location.href = `/checkout?service=itin&package=${packageType}&price=${selectedPkg.price}`;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-purple-100 text-purple-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Globe className="h-4 w-4" />
            <span>ITIN Application Service</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Get Your Individual Taxpayer Identification Number (ITIN)
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            An ITIN is required for non-US residents and others who cannot obtain a Social Security Number 
            but need to file US tax returns or conduct business in the United States.
          </p>
          
          {/* Trust indicators */}
          <div className="flex justify-center items-center space-x-8 text-sm text-gray-600 mb-8">
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-green-500" />
              <span>IRS Authorized</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-blue-500" />
              <span>Expert Processing</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="h-5 w-5 text-purple-500" />
              <span>Document Certified</span>
            </div>
          </div>
        </div>

        {/* Important Notice */}
        <Card className="mb-12 bg-yellow-50 border-yellow-200">
          <div className="flex items-start space-x-3">
            <AlertCircle className="h-6 w-6 text-yellow-600 mt-1" />
            <div>
              <h3 className="font-semibold text-yellow-900 mb-2">
                Important ITIN Information
              </h3>
              <p className="text-yellow-800 text-sm">
                ITIN applications require original documents or certified copies from the issuing agency. 
                We work with certified acceptance agents to help protect your original documents and 
                expedite the process. Processing times are set by the IRS and may vary during peak seasons.
              </p>
            </div>
          </div>
        </Card>

        {/* Who Needs an ITIN */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            Who Needs an ITIN?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {whoNeedsITIN.map((item, index) => {
              const Icon = item.icon;
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-all duration-300">
                  <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-purple-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">
                    {item.title}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {item.description}
                  </p>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Pricing Packages */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            Choose Your ITIN Package
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {packages.map((pkg) => (
              <Card 
                key={pkg.id}
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-2xl ${
                  pkg.popular ? 'ring-2 ring-purple-500 scale-105' : ''
                }`}
              >
                {pkg.popular && (
                  <div className="absolute top-0 left-0 right-0 bg-purple-500 text-white text-center py-2 text-sm font-bold">
                    MOST POPULAR
                  </div>
                )}
                
                <div className={`${pkg.popular ? 'pt-12' : 'pt-6'} pb-6`}>
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      {pkg.name}
                    </h3>
                    <p className="text-gray-600 mb-4">{pkg.description}</p>
                    
                    <div className="mb-4">
                      <div className="flex items-center justify-center mb-2">
                        <span className="text-4xl font-bold text-gray-900">
                          ${pkg.price}
                        </span>
                      </div>
                      <div className="text-gray-600 text-sm">
                        <span className="line-through">${pkg.originalPrice}</span>
                        <span className="text-green-600 font-medium ml-2">
                          Save ${pkg.originalPrice - pkg.price}!
                        </span>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-3 mb-6">
                      <div className="flex items-center justify-center space-x-2">
                        <Clock className="h-4 w-4 text-purple-600" />
                        <span className="font-medium text-gray-900">{pkg.timeline}</span>
                      </div>
                    </div>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button 
                    className={`w-full text-lg py-3 ${
                      pkg.popular 
                        ? 'bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800' 
                        : ''
                    }`}
                    variant={pkg.popular ? 'primary' : 'outline'}
                    onClick={() => handleCheckout(pkg.id as 'standard' | 'premium')}
                  >
                    Get My ITIN Now
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Requirements */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            What You'll Need
          </h2>
          <Card className="max-w-3xl mx-auto">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">
              Required Documents
            </h3>
            <ul className="space-y-3">
              {requirements.map((requirement, index) => (
                <li key={index} className="flex items-start space-x-3">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{requirement}</span>
                </li>
              ))}
            </ul>
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <p className="text-blue-800 text-sm">
                <strong>Note:</strong> We'll provide you with a complete checklist and help you gather 
                all necessary documents. Our certified acceptance agents can review your documents 
                to ensure everything is correct before submission.
              </p>
            </div>
          </Card>
        </div>

        {/* Process Steps */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            How It Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-purple-600 font-bold text-xl">1</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Consultation</h3>
              <p className="text-gray-600 text-sm">
                We review your situation and determine ITIN eligibility
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-purple-600 font-bold text-xl">2</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Document Prep</h3>
              <p className="text-gray-600 text-sm">
                We prepare Form W-7 and review all supporting documents
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-purple-600 font-bold text-xl">3</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">IRS Submission</h3>
              <p className="text-gray-600 text-sm">
                We submit your application to the IRS with certified documents
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-purple-600 font-bold text-xl">4</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Receive ITIN</h3>
              <p className="text-gray-600 text-sm">
                Get your ITIN letter and original documents returned
              </p>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <Card className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                What is an ITIN and who needs one?
              </h3>
              <p className="text-gray-600">
                An ITIN is a tax processing number issued by the IRS for individuals who are required to have a US taxpayer identification number but are not eligible for a Social Security Number. This includes non-resident aliens, their spouses, and dependents.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                How long does the ITIN process take?
              </h3>
              <p className="text-gray-600">
                The IRS typically processes ITIN applications in 6-10 weeks during normal periods, but it can take longer during peak tax season (January-April). Our premium service includes certified acceptance agent review which can help expedite the process.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                Do I need to send original documents?
              </h3>
              <p className="text-gray-600">
                Yes, the IRS requires original documents or certified copies from the issuing agency. With our premium service, we work with certified acceptance agents who can authenticate your documents, so you don't have to mail originals to the IRS.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                Can I use an ITIN to work in the US?
              </h3>
              <p className="text-gray-600">
                No, an ITIN is only for tax purposes and does not authorize you to work in the United States or provide eligibility for Social Security benefits.
              </p>
            </div>
          </div>
        </Card>

        {/* CTA Section */}
        <div className="text-center">
          <Card className="bg-gradient-to-r from-purple-600 to-purple-700 text-white">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Apply for Your ITIN?
            </h2>
            <p className="text-purple-100 mb-6 text-lg">
              Let our experts handle your ITIN application process
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                className="bg-white text-purple-600 hover:bg-gray-100"
                onClick={() => handleCheckout('standard')}
              >
                Get Standard ITIN - $199
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-purple-600"
                onClick={() => handleCheckout('premium')}
              >
                Get Premium ITIN - $299
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};