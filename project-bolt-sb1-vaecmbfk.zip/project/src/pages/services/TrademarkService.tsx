import React, { useState } from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Check, Shield, Search, FileText, Award, Clock, AlertCircle, Globe } from 'lucide-react';

export const TrademarkService: React.FC = () => {
  const [selectedPackage, setSelectedPackage] = useState<'search' | 'basic' | 'comprehensive'>('basic');

  const packages = [
    {
      id: 'search',
      name: 'Trademark Search',
      price: 199,
      originalPrice: 350,
      timeline: '3-5 business days',
      description: 'Comprehensive trademark availability search',
      features: [
        'Federal Trademark Database Search',
        'State Trademark Database Search',
        'Common Law Trademark Search',
        'Domain Name Availability Check',
        'Detailed Search Report',
        'Recommendations & Next Steps'
      ],
      popular: false
    },
    {
      id: 'basic',
      name: 'Basic Trademark Filing',
      price: 599,
      originalPrice: 1200,
      timeline: '12-18 months',
      description: 'Complete trademark application filing',
      features: [
        'Everything in Search Package',
        'USPTO Application Preparation',
        'Application Filing & Submission',
        'Office Action Response (1)',
        'Status Monitoring',
        'Certificate Delivery'
      ],
      popular: true
    },
    {
      id: 'comprehensive',
      name: 'Comprehensive Protection',
      price: 999,
      originalPrice: 2000,
      timeline: '12-18 months',
      description: 'Full-service trademark protection',
      features: [
        'Everything in Basic Package',
        'Multiple Class Filings',
        'Unlimited Office Action Responses',
        'Opposition Monitoring',
        'Renewal Reminders',
        'Dedicated Attorney Support'
      ],
      popular: false
    }
  ];

  const protectionBenefits = [
    {
      icon: Shield,
      title: 'Legal Protection',
      description: 'Exclusive rights to use your trademark nationwide'
    },
    {
      icon: Award,
      title: 'Brand Value',
      description: 'Increase your business value and credibility'
    },
    {
      icon: Globe,
      title: 'Market Expansion',
      description: 'Protect your brand as you grow into new markets'
    },
    {
      icon: FileText,
      title: 'Legal Recourse',
      description: 'Sue infringers and protect your intellectual property'
    }
  ];

  const trademarkTypes = [
    'Business Names & Logos',
    'Product Names & Brands',
    'Service Marks',
    'Slogans & Taglines',
    'Domain Names',
    'App Names & Software'
  ];

  const handleCheckout = (packageType: 'search' | 'basic' | 'comprehensive') => {
    const selectedPkg = packages.find(p => p.id === packageType);
    if (selectedPkg) {
      window.location.href = `/checkout?service=trademark&package=${packageType}&price=${selectedPkg.price}`;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-red-100 text-red-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Shield className="h-4 w-4" />
            <span>Trademark Protection</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Protect Your Brand with Trademark Registration
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Secure exclusive rights to your business name, logo, or slogan. Our trademark attorneys 
            handle the entire process from search to registration, protecting your brand nationwide.
          </p>
          
          {/* Trust indicators */}
          <div className="flex justify-center items-center space-x-8 text-sm text-gray-600 mb-8">
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-green-500" />
              <span>USPTO Registered</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-blue-500" />
              <span>Expert Attorneys</span>
            </div>
            <div className="flex items-center space-x-2">
              <Check className="h-5 w-5 text-purple-500" />
              <span>Success Guarantee</span>
            </div>
          </div>
        </div>

        {/* Important Notice */}
        <Card className="mb-12 bg-yellow-50 border-yellow-200">
          <div className="flex items-start space-x-3">
            <AlertCircle className="h-6 w-6 text-yellow-600 mt-1" />
            <div>
              <h3 className="font-semibold text-yellow-900 mb-2">
                Why Trademark Protection Matters
              </h3>
              <p className="text-yellow-800 text-sm">
                Without trademark protection, competitors can use similar names or logos, potentially 
                confusing customers and diluting your brand. Trademark registration gives you exclusive 
                nationwide rights and legal recourse against infringers.
              </p>
            </div>
          </div>
        </Card>

        {/* Protection Benefits */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            Why Protect Your Trademark?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {protectionBenefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-all duration-300">
                  <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-red-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">
                    {benefit.title}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {benefit.description}
                  </p>
                </Card>
              );
            })}
          </div>
        </div>

        {/* What Can Be Trademarked */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            What Can Be Trademarked?
          </h2>
          <Card className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {trademarkTypes.map((type, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-700 font-medium">{type}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Pricing Packages */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            Choose Your Trademark Package
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {packages.map((pkg) => (
              <Card 
                key={pkg.id}
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-2xl ${
                  pkg.popular ? 'ring-2 ring-red-500 scale-105' : ''
                }`}
              >
                {pkg.popular && (
                  <div className="absolute top-0 left-0 right-0 bg-red-500 text-white text-center py-2 text-sm font-bold">
                    MOST POPULAR
                  </div>
                )}
                
                <div className={`${pkg.popular ? 'pt-12' : 'pt-6'} pb-6`}>
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      {pkg.name}
                    </h3>
                    <p className="text-gray-600 mb-4">{pkg.description}</p>
                    
                    <div className="mb-4">
                      <div className="flex items-center justify-center mb-2">
                        <span className="text-4xl font-bold text-gray-900">
                          ${pkg.price}
                        </span>
                      </div>
                      <div className="text-gray-600 text-sm">
                        <span className="line-through">${pkg.originalPrice}</span>
                        <span className="text-green-600 font-medium ml-2">
                          Save ${pkg.originalPrice - pkg.price}!
                        </span>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-3 mb-6">
                      <div className="flex items-center justify-center space-x-2">
                        <Clock className="h-4 w-4 text-red-600" />
                        <span className="font-medium text-gray-900">{pkg.timeline}</span>
                      </div>
                    </div>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button 
                    className={`w-full text-lg py-3 ${
                      pkg.popular 
                        ? 'bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800' 
                        : ''
                    }`}
                    variant={pkg.popular ? 'primary' : 'outline'}
                    onClick={() => handleCheckout(pkg.id as 'search' | 'basic' | 'comprehensive')}
                  >
                    {pkg.id === 'search' ? 'Start Search' : 'File Trademark'}
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Process Steps */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">
            Trademark Registration Process
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            <div className="text-center">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-red-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Search</h3>
              <p className="text-gray-600 text-sm">
                Comprehensive search for existing trademarks
              </p>
            </div>
            <div className="text-center">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="h-8 w-8 text-red-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Prepare</h3>
              <p className="text-gray-600 text-sm">
                Attorney prepares and reviews application
              </p>
            </div>
            <div className="text-center">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-red-600 font-bold text-xl">3</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">File</h3>
              <p className="text-gray-600 text-sm">
                Submit application to USPTO
              </p>
            </div>
            <div className="text-center">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-red-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Review</h3>
              <p className="text-gray-600 text-sm">
                USPTO examines application (6-12 months)
              </p>
            </div>
            <div className="text-center">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-red-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Register</h3>
              <p className="text-gray-600 text-sm">
                Receive trademark certificate
              </p>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <Card className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                How long does trademark registration take?
              </h3>
              <p className="text-gray-600">
                The entire process typically takes 12-18 months from filing to registration. This includes USPTO examination, potential office actions, and final approval. We monitor your application throughout the process.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                What if my trademark application is rejected?
              </h3>
              <p className="text-gray-600">
                If the USPTO issues an office action (rejection), our attorneys will work with you to address the issues. Our Basic package includes one office action response, while our Comprehensive package includes unlimited responses.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                Do I need a trademark search before filing?
              </h3>
              <p className="text-gray-600">
                Yes, a comprehensive trademark search is essential to avoid conflicts with existing trademarks. Our search identifies potential issues before filing, saving time and money in the long run.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                How long does trademark protection last?
              </h3>
              <p className="text-gray-600">
                Trademark protection lasts indefinitely as long as you continue to use the mark and file required renewal documents. Initial registration is for 10 years, then renewable every 10 years thereafter.
              </p>
            </div>
          </div>
        </Card>

        {/* CTA Section */}
        <div className="text-center">
          <Card className="bg-gradient-to-r from-red-600 to-red-700 text-white">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Protect Your Brand?
            </h2>
            <p className="text-red-100 mb-6 text-lg">
              Don't let competitors steal your brand identity. Start your trademark protection today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                variant="secondary"
                className="bg-white text-red-600 hover:bg-gray-100"
                onClick={() => handleCheckout('search')}
              >
                Start with Search - $199
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-red-600"
                onClick={() => handleCheckout('basic')}
              >
                File Trademark - $599
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};