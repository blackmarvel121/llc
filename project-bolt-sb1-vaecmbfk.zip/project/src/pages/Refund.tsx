import React from 'react';
import { Card } from '../components/ui/Card';

export const Refund: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card className="p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Refund Policy</h1>
          
          <div className="prose prose-gray max-w-none">
            <p className="text-gray-600 mb-6">
              <strong>Last Updated:</strong> January 1, 2024
            </p>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">30-Day Money-Back Guarantee</h2>
              <p className="text-gray-700 mb-4">
                We stand behind our services with a 30-day money-back guarantee. If you're not completely satisfied with our service, 
                we'll refund your service fee within 30 days of your order date.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">What's Covered</h2>
              <p className="text-gray-700 mb-4">Our refund policy covers:</p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li><strong>Service Fees:</strong> Our LLC formation service fees are fully refundable</li>
                <li><strong>Add-on Services:</strong> EIN applications, registered agent services, and other add-ons</li>
                <li><strong>Unused Services:</strong> Any services that haven't been completed or delivered</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">What's Not Covered</h2>
              <p className="text-gray-700 mb-4">The following are not refundable:</p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li><strong>State Filing Fees:</strong> Fees paid directly to state agencies are non-refundable</li>
                <li><strong>Government Fees:</strong> Any fees paid to government agencies (IRS, USPTO, etc.)</li>
                <li><strong>Third-Party Costs:</strong> Fees paid to external service providers</li>
                <li><strong>Completed Filings:</strong> If your LLC has been successfully filed and approved by the state</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Refund Process</h2>
              <p className="text-gray-700 mb-4">To request a refund:</p>
              <ol className="list-decimal pl-6 text-gray-700 mb-4">
                <li>Contact our customer service team within 30 days of your order</li>
                <li>Provide your order number and reason for the refund request</li>
                <li>Our team will review your request within 2 business days</li>
                <li>If approved, refunds will be processed within 5-7 business days</li>
                <li>Refunds will be issued to the original payment method</li>
              </ol>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Partial Refunds</h2>
              <p className="text-gray-700 mb-4">
                In some cases, we may offer partial refunds for services that have been partially completed. 
                This will be determined on a case-by-case basis depending on the work already performed.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Cancellation Policy</h2>
              <p className="text-gray-700 mb-4">
                You may cancel your order at any time before we begin processing your LLC formation. 
                Once we've submitted your documents to the state, cancellation may not be possible, 
                but you may still be eligible for a partial refund of unused services.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Dispute Resolution</h2>
              <p className="text-gray-700 mb-4">
                If you're not satisfied with our refund decision, you may escalate your concern to our management team. 
                We're committed to resolving all customer concerns fairly and promptly.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Contact Information</h2>
              <p className="text-gray-700 mb-4">
                To request a refund or ask questions about our refund policy:
              </p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700">
                  <strong>Email:</strong> refunds@razorfile.com<br />
                  <strong>Phone:</strong> 1-800-RAZORFILE<br />
                  <strong>Support Hours:</strong> Monday-Friday, 9 AM - 6 PM EST<br />
                  <strong>Address:</strong> 123 Business Ave, Suite 100, Business City, BC 12345
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Changes to This Policy</h2>
              <p className="text-gray-700 mb-4">
                We may update this refund policy from time to time. Any changes will be posted on this page with an updated revision date. 
                Your continued use of our services after any changes constitutes acceptance of the new policy.
              </p>
            </section>
          </div>
        </Card>
      </div>
    </div>
  );
};