export interface User {
  id: string;
  email: string;
  role: 'user' | 'admin';
  created_at: string;
  phone?: string;
  first_name?: string;
  last_name?: string;
}

export interface State {
  id: string;
  name: string;
  code: string;
  filing_fee: number;
  turnaround_time: string;
  monthly_price: number;
  yearly_price: number;
  one_time_price: number;
  is_active: boolean;
}

export interface Package {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
  is_popular: boolean;
  is_active: boolean;
  includes_ein: boolean;
  includes_registered_agent: boolean;
  same_day_filing: boolean;
}

export interface Addon {
  id: string;
  name: string;
  description: string;
  price: number;
  is_active: boolean;
  category: string;
}

export interface Order {
  id: string;
  user_id: string;
  package_id: string;
  state_id: string;
  status: 'pending' | 'processing' | 'completed' | 'cancelled';
  total_amount: number;
  payment_status: 'pending' | 'paid' | 'failed';
  payment_method?: string;
  payment_id?: string;
  company_name?: string;
  created_at: string;
  addons: string[];
  packages?: {
    name: string;
  };
  states?: {
    name: string;
    code: string;
  };
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  is_active: boolean;
  order_index: number;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'closed';
  created_at: string;
  admin_response?: string;
}

export interface Settings {
  announcement_enabled: boolean;
  announcement_text: string;
  whatsapp_enabled: boolean;
  whatsapp_number: string;
  whatsapp_message: string;
}