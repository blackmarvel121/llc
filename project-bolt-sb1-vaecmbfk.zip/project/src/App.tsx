import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { Home } from './pages/Home';
import { Auth } from './pages/Auth';
import { ProtectedRoute } from './components/ProtectedRoute';
import { DashboardLayout } from './components/dashboard/DashboardLayout';
import { DashboardHome } from './pages/dashboard/DashboardHome';
import { MyOrders } from './pages/dashboard/MyOrders';
import { MyDocuments } from './pages/dashboard/MyDocuments';
import { AddonsCompliance } from './pages/dashboard/AddonsCompliance';
import { AffiliateProgram } from './pages/dashboard/AffiliateProgram';
import { Support } from './pages/dashboard/Support';
import { Settings } from './pages/dashboard/Settings';
import { AdminLayout } from './components/admin/AdminLayout';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { ManageUsers } from './pages/admin/ManageUsers';
import { ManageOrders } from './pages/admin/ManageOrders';
import { ManagePackages } from './pages/admin/ManagePackages';
import { ManageAddons } from './pages/admin/ManageAddons';
import { ManageStates } from './pages/admin/ManageStates';
import { SupportTickets } from './pages/admin/SupportTickets';
import { WhatsAppSettings } from './pages/admin/WhatsAppSettings';
import { EmailMarketing } from './pages/admin/EmailMarketing';
import { AffiliateManager } from './pages/admin/AffiliateManager';
import { GeoTracking } from './pages/admin/GeoTracking';
import { Compliance } from './pages/admin/Compliance';
import { PaymentGateways } from './pages/admin/PaymentGateways';
import { AdminSettings } from './pages/admin/AdminSettings';
import { Checkout } from './pages/Checkout';
import { Terms } from './pages/Terms';
import { Privacy } from './pages/Privacy';
import { Refund } from './pages/Refund';
import { Support as PublicSupport } from './pages/Support';
import { TidioChat } from './components/TidioChat';

function App() {
  // Lazy load service components
  const EINService = React.lazy(() => import('./pages/services/EINService').then(module => ({ default: module.EINService })));
  const ITINService = React.lazy(() => import('./pages/services/ITINService').then(module => ({ default: module.ITINService })));
  const BookkeepingService = React.lazy(() => import('./pages/services/BookkeepingService').then(module => ({ default: module.BookkeepingService })));
  const TrademarkService = React.lazy(() => import('./pages/services/TrademarkService').then(module => ({ default: module.TrademarkService })));

  return (
    <Router>
      <div className="min-h-screen bg-white">
        <React.Suspense fallback={
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
          </div>
        }>
          <Routes>
            {/* Public routes with header/footer */}
            <Route path="/" element={
              <>
                <Header />
                <main>
                  <Home />
                </main>
                <Footer />
              </>
            } />
            <Route path="/auth" element={
              <>
                <Header />
                <main>
                  <Auth />
                </main>
                <Footer />
              </>
            } />
            <Route path="/checkout" element={
              <>
                <Header />
                <main>
                  <Checkout />
                </main>
                <Footer />
              </>
            } />
            
            {/* Support Page */}
            <Route path="/support" element={
              <>
                <Header />
                <main>
                  <PublicSupport />
                </main>
                <Footer />
              </>
            } />
            
            {/* Legal Pages */}
            <Route path="/terms" element={
              <>
                <Header />
                <main>
                  <Terms />
                </main>
                <Footer />
              </>
            } />
            <Route path="/privacy" element={
              <>
                <Header />
                <main>
                  <Privacy />
                </main>
                <Footer />
              </>
            } />
            <Route path="/refund" element={
              <>
                <Header />
                <main>
                  <Refund />
                </main>
                <Footer />
              </>
            } />
            
            {/* Service Pages */}
            <Route path="/services/ein" element={
              <>
                <Header />
                <main>
                  <EINService />
                </main>
                <Footer />
              </>
            } />
            <Route path="/services/itin" element={
              <>
                <Header />
                <main>
                  <ITINService />
                </main>
                <Footer />
              </>
            } />
            <Route path="/services/bookkeeping" element={
              <>
                <Header />
                <main>
                  <BookkeepingService />
                </main>
                <Footer />
              </>
            } />
            <Route path="/services/trademark" element={
              <>
                <Header />
                <main>
                  <TrademarkService />
                </main>
                <Footer />
              </>
            } />
            
            {/* Dashboard routes */}
            <Route path="/dashboard" element={
              <ProtectedRoute>
                <DashboardLayout />
              </ProtectedRoute>
            }>
              <Route index element={<DashboardHome />} />
              <Route path="orders" element={<MyOrders />} />
              <Route path="documents" element={<MyDocuments />} />
              <Route path="addons" element={<AddonsCompliance />} />
              <Route path="affiliate" element={<AffiliateProgram />} />
              <Route path="support" element={<Support />} />
              <Route path="settings" element={<Settings />} />
            </Route>
            
            {/* Admin routes */}
            <Route path="/admin" element={
              <ProtectedRoute adminOnly>
                <AdminLayout />
              </ProtectedRoute>
            }>
              <Route index element={<AdminDashboard />} />
              <Route path="users" element={<ManageUsers />} />
              <Route path="orders" element={<ManageOrders />} />
              <Route path="packages" element={<ManagePackages />} />
              <Route path="addons" element={<ManageAddons />} />
              <Route path="states" element={<ManageStates />} />
              <Route path="support" element={<SupportTickets />} />
              <Route path="whatsapp" element={<WhatsAppSettings />} />
              <Route path="email" element={<EmailMarketing />} />
              <Route path="affiliates" element={<AffiliateManager />} />
              <Route path="geo" element={<GeoTracking />} />
              <Route path="compliance" element={<Compliance />} />
              <Route path="payments" element={<PaymentGateways />} />
              <Route path="settings" element={<AdminSettings />} />
            </Route>
          </Routes>
        </React.Suspense>
        <TidioChat />
      </div>
    </Router>
  );
}

export default App;