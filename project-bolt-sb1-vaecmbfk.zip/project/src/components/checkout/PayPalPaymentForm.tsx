import React, { useState, useEffect } from 'react';
import { Button } from '../ui/Button';
import { CreditCard, Lock } from 'lucide-react';

interface PayPalPaymentFormProps {
  onPaymentComplete: (paymentId: string) => void;
  amount: number;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

declare global {
  interface Window {
    paypal?: any;
  }
}

export const PayPalPaymentForm: React.FC<PayPalPaymentFormProps> = ({
  onPaymentComplete,
  amount,
  isLoading,
  setIsLoading
}) => {
  const [scriptLoaded, setScriptLoaded] = useState(false);
  const [paypalButtonRendered, setPaypalButtonRendered] = useState(false);
  
  useEffect(() => {
    // Load PayPal script
    const script = document.createElement('script');
    script.src = `https://www.paypal.com/sdk/js?client-id=test&currency=USD`;
    script.async = true;
    script.onload = () => setScriptLoaded(true);
    document.body.appendChild(script);

    return () => {
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
  }, []);

  useEffect(() => {
    if (scriptLoaded && !paypalButtonRendered && window.paypal) {
      try {
        const paypalButtonContainer = document.getElementById('paypal-button-container');
        if (paypalButtonContainer) {
          // Clear any existing buttons
          paypalButtonContainer.innerHTML = '';
          
          window.paypal.Buttons({
            createOrder: (data: any, actions: any) => {
              return actions.order.create({
                purchase_units: [{
                  amount: {
                    value: amount.toString()
                  }
                }]
              });
            },
            onApprove: (data: any, actions: any) => {
              setIsLoading(true);
              return actions.order.capture().then((details: any) => {
                // Handle successful payment
                onPaymentComplete(details.id);
              });
            },
            onError: (err: any) => {
              console.error('PayPal error:', err);
              alert('Payment failed. Please try again.');
              setIsLoading(false);
            }
          }).render('#paypal-button-container');
          
          setPaypalButtonRendered(true);
        }
      } catch (error) {
        console.error('Error rendering PayPal buttons:', error);
      }
    }
  }, [scriptLoaded, amount, onPaymentComplete, setIsLoading, paypalButtonRendered]);

  const handleManualPayment = async () => {
    setIsLoading(true);
    
    try {
      // In a real implementation, this would use PayPal's JS SDK
      // For now, we'll simulate a successful payment
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate a fake payment ID
      const paymentId = `PP_${Math.random().toString(36).substring(2, 15)}`;
      
      onPaymentComplete(paymentId);
    } catch (error) {
      console.error('Payment error:', error);
      alert('Payment failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 mb-4">
        <Lock className="h-5 w-5 text-green-600" />
        <span className="text-sm text-gray-600">Your payment information is secure and encrypted</span>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
        <p className="text-gray-700 mb-2">
          Pay securely using your PayPal account or credit/debit card through PayPal.
        </p>
        <p className="text-sm text-gray-600">
          You'll be redirected to PayPal to complete your payment.
        </p>
      </div>
      
      {/* PayPal Button Container */}
      <div id="paypal-button-container" className="min-h-[50px]"></div>
      
      {/* Fallback button in case PayPal script fails to load */}
      {!scriptLoaded && (
        <div className="pt-4">
          <Button 
            type="button" 
            className="w-full" 
            loading={isLoading}
            onClick={handleManualPayment}
          >
            <CreditCard className="h-4 w-4 mr-2" />
            Pay with PayPal ${amount}
          </Button>
        </div>
      )}
      
      <div className="flex items-center justify-center space-x-4 mt-4">
        <img src="https://cdn.pixabay.com/photo/2015/05/26/09/37/paypal-784404_1280.png" alt="PayPal" className="h-6" />
        <img src="https://cdn.pixabay.com/photo/2021/12/08/05/16/visa-6855547_1280.png" alt="Visa" className="h-6" />
        <img src="https://cdn.pixabay.com/photo/2015/05/26/09/37/master-card-784405_1280.png" alt="MasterCard" className="h-6" />
        <img src="https://cdn.pixabay.com/photo/2022/01/17/09/23/american-express-6944357_1280.png" alt="American Express" className="h-6" />
      </div>
    </div>
  );
};