import React, { useState, useEffect } from 'react';
import { Button } from '../ui/Button';
import { CreditCard, Lock } from 'lucide-react';
import { createRazorpayOrder, verifyRazorpayPayment } from '../../lib/razorpay';

interface RazorpayPaymentFormProps {
  onPaymentComplete: (paymentId: string) => void;
  amount: number;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

declare global {
  interface Window {
    Razorpay: any;
  }
}

export const RazorpayPaymentForm: React.FC<RazorpayPaymentFormProps> = ({
  onPaymentComplete,
  amount,
  isLoading,
  setIsLoading
}) => {
  const [scriptLoaded, setScriptLoaded] = useState(false);

  useEffect(() => {
    // Load Razorpay script
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    script.onload = () => setScriptLoaded(true);
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const handlePayment = async () => {
    if (!scriptLoaded) {
      alert('Payment gateway is loading. Please try again in a moment.');
      return;
    }

    setIsLoading(true);

    try {
      // Create a Razorpay order using our Edge Function
      const orderData = await createRazorpayOrder(amount);
      
      if (!orderData || !orderData.id) {
        throw new Error('Failed to create Razorpay order');
      }

      const options = {
        key: orderData.key, // Use the key from the response
        amount: orderData.amount, // Amount in paise
        currency: 'INR',
        name: 'Razorfile LLC Formation',
        description: 'LLC Formation Services',
        order_id: orderData.id,
        handler: async function(response: any) {
          // Handle successful payment
          try {
            // Verify the payment
            const verificationResult = await verifyRazorpayPayment(
              response.razorpay_payment_id,
              response.razorpay_order_id,
              response.razorpay_signature,
              amount
            );
            
            if (verificationResult.success) {
              onPaymentComplete(response.razorpay_payment_id);
            } else {
              throw new Error('Payment verification failed');
            }
          } catch (error) {
            console.error('Payment verification error:', error);
            alert('Payment verification failed. Please try again.');
            setIsLoading(false);
          }
        },
        prefill: {
          name: '',
          email: '',
          contact: ''
        },
        theme: {
          color: '#3B82F6'
        },
        modal: {
          ondismiss: function() {
            setIsLoading(false);
          }
        }
      };

      if (window.Razorpay) {
        const razorpay = new window.Razorpay(options);
        razorpay.open();
      } else {
        throw new Error('Razorpay SDK not loaded');
      }
    } catch (error) {
      console.error('Payment error:', error);
      alert('Payment initialization failed. Please try again.');
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 mb-4">
        <Lock className="h-5 w-5 text-green-600" />
        <span className="text-sm text-gray-600">Your payment information is secure and encrypted</span>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
        <p className="text-gray-700 mb-2">
          You will be redirected to Razorpay's secure payment page to complete your payment.
        </p>
        <p className="text-sm text-gray-600">
          Razorpay accepts Credit/Debit Cards, NetBanking, UPI, and Wallets.
        </p>
      </div>
      
      <div className="pt-4">
        <Button 
          type="button" 
          className="w-full" 
          loading={isLoading}
          onClick={handlePayment}
        >
          <CreditCard className="h-4 w-4 mr-2" />
          Pay ₹{amount.toFixed(2)}
        </Button>
      </div>
      
      <div className="flex items-center justify-center space-x-4 mt-4">
        <img src="https://cdn.pixabay.com/photo/2021/12/08/05/16/visa-6855547_1280.png" alt="Visa" className="h-6" />
        <img src="https://cdn.pixabay.com/photo/2015/05/26/09/37/master-card-784405_1280.png" alt="MasterCard" className="h-6" />
        <img src="https://cdn.pixabay.com/photo/2022/01/17/09/23/american-express-6944357_1280.png" alt="American Express" className="h-6" />
        <img src="https://cdn.pixabay.com/photo/2018/05/08/21/29/paypal-3384015_1280.png" alt="PayPal" className="h-6" />
      </div>
    </div>
  );
};