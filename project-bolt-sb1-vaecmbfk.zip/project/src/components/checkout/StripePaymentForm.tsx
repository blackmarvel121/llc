import React, { useState, useEffect } from 'react';
import { Button } from '../ui/Button';
import { CreditCard, Lock } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { createPaymentIntent } from '../../lib/stripe';
import { loadStripe } from '@stripe/stripe-js';

interface StripePaymentFormProps {
  onPaymentComplete: (paymentId: string) => void;
  amount: number;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

export const StripePaymentForm: React.FC<StripePaymentFormProps> = ({
  onPaymentComplete,
  amount,
  isLoading,
  setIsLoading
}) => {
  const [stripeLoaded, setStripeLoaded] = useState(false);
  const [stripeError, setStripeError] = useState<string | null>(null);
  const [cardInfo, setCardInfo] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    nameOnCard: '',
    billingZip: ''
  });
  const [stripeLoaded, setStripeLoaded] = useState(false);
  useEffect(() => {
    const loadStripeInstance = async () => {
      try {
        // Get the Stripe gateway
        const { data, error } = await supabase
          .from('payment_gateways')
          .select('public_key, enabled')
          .eq('type', 'stripe')
          .single();
        
        if (error) {
          console.error('Error fetching Stripe gateway:', error);
          setStripeError('Stripe payment gateway not found. Please contact support.');
          return;
        }
        
        if (!data.enabled) {
          setStripeError('Stripe payment gateway is disabled. Please contact support.');
          return;
        }
        
        if (!data.public_key) {
          setStripeError('Stripe is not configured. Please contact support.');
          return;
        }
        
        // Stripe is properly configured
        setStripeLoaded(true);
      } catch (error) {
        console.error('Error loading Stripe:', error);
        setStripeError('Error loading Stripe: ' + (error instanceof Error ? error.message : 'Unknown error'));
      }
    };
    
    loadStripeInstance();
  }, []);

  const [stripePromise, setStripePromise] = useState<Promise<any> | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Load Stripe
    const loadStripeInstance = async () => {
      try {
        // Get the Stripe public key from the payment_gateways table
        const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/rest/v1/payment_gateways?select=public_key,enabled&type=eq.stripe`, {
          headers: {
            'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
            'Content-Type': 'application/json'
          }
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch Stripe configuration');
        }
        
        const data = await response.json();
        
        if (data && data.length > 0 && data[0].public_key && data[0].enabled) {
          const stripePromise = loadStripe(data[0].public_key);
          setStripePromise(stripePromise);
          setStripeLoaded(true);
        } else if (data && data.length > 0 && !data[0].enabled) {
          throw new Error('Stripe payment gateway is disabled. Please contact support.');
        } else if (data && data.length > 0 && !data[0].public_key) {
          throw new Error('Stripe is not configured. Please contact support.');
        } else {
          throw new Error('Stripe payment gateway not found. Please contact support.');
        }
      } catch (error) {
        console.error('Error loading Stripe:', error);
        setError(error instanceof Error ? error.message : 'Failed to load payment processor. Please try again later.');
      }
    };
    
    loadStripeInstance();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    
    try {
      if (!stripePromise) {
        throw new Error('Stripe not initialized');
      }
      
      // Create a payment intent
      const { clientSecret, paymentIntentId } = await createPaymentIntent(amount);
      
      if (!clientSecret) {
        throw new Error('Failed to create payment intent');
      }
      
      const stripe = await stripePromise;
      
      // In a real implementation, we would use Stripe Elements to collect card details
      // For this demo, we'll simulate a successful payment confirmation
      const { error: confirmError } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: {
            number: cardInfo.cardNumber.replace(/\s/g, ''),
            exp_month: parseInt(cardInfo.expiryDate.split('/')[0]),
            exp_year: parseInt('20' + cardInfo.expiryDate.split('/')[1]),
            cvc: cardInfo.cvv,
          },
          billing_details: {
            name: cardInfo.nameOnCard,
            address: {
              postal_code: cardInfo.billingZip,
            },
          },
        },
      });
      
      if (confirmError) {
        throw new Error(confirmError.message);
      }
      
      // Payment successful
      onPaymentComplete(paymentIntentId);
    } catch (error) {
      console.error('Payment error:', error);
      setError(error instanceof Error ? error.message : 'Payment failed. Please try again.');
      setIsLoading(false);
    }
  };

  // Format card number with spaces
  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    
    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };

  // Format expiry date
  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    
    if (v.length >= 2) {
      return `${v.substring(0, 2)}/${v.substring(2, 4)}`;
    }
    
    return v;
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex items-center space-x-2 mb-4">
        <Lock className="h-5 w-5 text-green-600" />
        <span className="text-sm text-gray-600">
          Your payment information is secure and encrypted
        </span>
      </div>
      
      {stripeError && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg mb-4">
          {stripeError}
        </div>
      )}
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg mb-4">
          {error}
        </div>
      )}
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Card Number *
        </label>
        <input
          type="text"
          placeholder="1234 5678 9012 3456"
          value={cardInfo.cardNumber}
          onChange={(e) => setCardInfo({...cardInfo, cardNumber: formatCardNumber(e.target.value)})}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          maxLength={19}
          required
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Expiry Date *
          </label>
          <input
            type="text"
            placeholder="MM/YY"
            value={cardInfo.expiryDate}
            onChange={(e) => setCardInfo({...cardInfo, expiryDate: formatExpiryDate(e.target.value)})}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            maxLength={5}
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            CVV *
          </label>
          <input
            type="text"
            placeholder="123"
            value={cardInfo.cvv}
            onChange={(e) => {
              const value = e.target.value.replace(/\D/g, '');
              setCardInfo({...cardInfo, cvv: value});
            }}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            maxLength={4}
            required
          />
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Name on Card *
        </label>
        <input
          type="text"
          placeholder="John Doe"
          value={cardInfo.nameOnCard}
          onChange={(e) => setCardInfo({...cardInfo, nameOnCard: e.target.value})}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Billing ZIP Code *
        </label>
        <input
          type="text"
          placeholder="12345"
          value={cardInfo.billingZip}
          onChange={(e) => {
            const value = e.target.value.replace(/[^0-9a-zA-Z\-\s]/g, '');
            setCardInfo({...cardInfo, billingZip: value});
          }}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
      </div>
      
      <div className="pt-4">
        <Button 
          type="submit"
          className="w-full" 
          loading={isLoading}
          disabled={loading || !!stripeError}
          disabled={!stripeLoaded}
        >
          <CreditCard className="h-4 w-4 mr-2" />
          Pay ${amount}
        </Button>
      </div>
      
      <div className="flex items-center justify-center space-x-4 mt-4">
        <img src="https://cdn.pixabay.com/photo/2021/12/08/05/16/visa-6855547_1280.png" alt="Visa" className="h-6" />
        <img src="https://cdn.pixabay.com/photo/2015/05/26/09/37/master-card-784405_1280.png" alt="Mastercard" className="h-6" />
        <img src="https://cdn.pixabay.com/photo/2015/05/26/09/37/master-card-784405_1280.png" alt="MasterCard" className="h-6" />
      </div>
    </form>
  );
};