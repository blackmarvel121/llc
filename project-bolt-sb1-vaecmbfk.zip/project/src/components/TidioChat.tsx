import React, { useEffect } from 'react';

export const TidioChat: React.FC = () => {
  useEffect(() => {
    // Load Tidio Chat script
    const script = document.createElement('script');
    script.src = '//code.tidio.co/abcdefghijklmnopqrstuv.js'; // Your Tidio public key
    script.async = true;
    document.body.appendChild(script);

    return () => {
      // Clean up on unmount - only remove if it exists
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
  }, []);

  return null; // This component doesn't render anything
};