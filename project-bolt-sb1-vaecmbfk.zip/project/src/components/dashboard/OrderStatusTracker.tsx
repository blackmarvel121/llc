import React from 'react';
import { CheckCircle, Clock, AlertCircle } from 'lucide-react';

interface OrderStatusTrackerProps {
  status: 'pending' | 'processing' | 'completed' | 'cancelled';
  steps?: {
    key: string;
    label: string;
    description?: string;
  }[];
}

export const OrderStatusTracker: React.FC<OrderStatusTrackerProps> = ({
  status,
  steps = [
    { key: 'pending', label: 'Order Received', description: 'Your order has been received and is being reviewed' },
    { key: 'processing', label: 'Processing', description: 'Your LLC documents are being prepared and filed' },
    { key: 'completed', label: 'Completed', description: 'Your LLC has been successfully formed' }
  ]
}) => {
  const getStepStatus = (stepKey: string) => {
    if (status === 'cancelled') {
      return 'cancelled';
    }
    
    const statusOrder = ['pending', 'processing', 'completed'];
    const currentIndex = statusOrder.indexOf(status);
    const stepIndex = statusOrder.indexOf(stepKey);
    
    if (stepIndex < currentIndex) {
      return 'completed';
    } else if (stepIndex === currentIndex) {
      return 'current';
    } else {
      return 'upcoming';
    }
  };
  
  const getStepIcon = (stepStatus: string) => {
    switch (stepStatus) {
      case 'completed':
        return <CheckCircle className="h-6 w-6 text-green-600" />;
      case 'current':
        return <Clock className="h-6 w-6 text-blue-600" />;
      case 'cancelled':
        return <AlertCircle className="h-6 w-6 text-red-600" />;
      default:
        return <div className="w-6 h-6 border-2 border-gray-300 rounded-full"></div>;
    }
  };
  
  return (
    <div className="py-4">
      <div className="relative">
        {/* Progress bar */}
        <div className="absolute top-5 left-5 right-5 h-1 bg-gray-200">
          <div 
            className={`h-1 bg-green-500 transition-all duration-500 ${
              status === 'cancelled' ? 'w-0' : 
              status === 'pending' ? 'w-0' : 
              status === 'processing' ? 'w-1/2' : 
              'w-full'
            }`}
          ></div>
        </div>
        
        {/* Steps */}
        <div className="relative flex justify-between">
          {steps.map((step, index) => {
            const stepStatus = getStepStatus(step.key);
            return (
              <div key={step.key} className="flex flex-col items-center">
                <div className={`z-10 flex items-center justify-center w-10 h-10 rounded-full ${
                  stepStatus === 'completed' ? 'bg-green-100' :
                  stepStatus === 'current' ? 'bg-blue-100' :
                  stepStatus === 'cancelled' ? 'bg-red-100' :
                  'bg-gray-100'
                }`}>
                  {getStepIcon(stepStatus)}
                </div>
                <div className="mt-2 text-center">
                  <p className={`font-medium ${
                    stepStatus === 'completed' ? 'text-green-600' :
                    stepStatus === 'current' ? 'text-blue-600' :
                    stepStatus === 'cancelled' ? 'text-red-600' :
                    'text-gray-500'
                  }`}>
                    {step.label}
                  </p>
                  {step.description && (
                    <p className="text-xs text-gray-500 max-w-[120px] mt-1">
                      {step.description}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};