import React, { useEffect, useState } from 'react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { supabase } from '../../lib/supabase';
import { Addon } from '../../types';

export const AddonsSection: React.FC = () => {
  const [addons, setAddons] = useState<Addon[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAddons = async () => {
      try {
        const { data, error } = await supabase
          .from('addons')
          .select('*')
          .eq('is_active', true)
          .order('price', { ascending: true });

        if (error) throw error;
        setAddons(data || []);
      } catch (error) {
        console.error('Error fetching addons:', error);
        // Fallback addons if DB query fails
        setAddons([
          { id: '1', name: 'EIN Number', description: 'Get your Federal Tax ID number', price: 49, is_active: true, category: 'tax' },
          { id: '2', name: 'Registered Agent', description: 'Professional registered agent service for 1 year', price: 99, is_active: true, category: 'compliance' },
          { id: '3', name: 'Operating Agreement', description: 'Customized operating agreement for your LLC', price: 79, is_active: true, category: 'legal' },
          { id: '4', name: 'ITIN Application', description: 'Individual Taxpayer Identification Number application', price: 199, is_active: true, category: 'tax' },
          { id: '5', name: 'Banking Resolution', description: 'Corporate banking resolution for business accounts', price: 39, is_active: true, category: 'banking' },
          { id: '6', name: 'Expedited Processing', description: 'Same-day state filing (where available)', price: 149, is_active: true, category: 'service' },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchAddons();
  }, []);

  if (loading) {
    return (
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-1/3 mx-auto mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="addons" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Add-On Services
          </h2>
          <p className="text-xl text-gray-600">
            Enhance your LLC with additional services
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {addons.map((addon) => (
            <Card key={addon.id} className="flex flex-col">
              <div className="flex-1">
                <div className="mb-4">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {addon.name}
                  </h3>
                  <p className="text-gray-600">
                    {addon.description}
                  </p>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl font-bold text-gray-900">
                    ${addon.price}
                  </span>
                  <span className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded">
                    {addon.category}
                  </span>
                </div>
              </div>
              <Button variant="outline" className="w-full">
                Add to Cart
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};