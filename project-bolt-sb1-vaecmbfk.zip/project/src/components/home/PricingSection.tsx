import React, { useEffect, useState } from 'react';
import { Check, Star, Zap, Shield, Clock } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { supabase } from '../../lib/supabase';
import { Package } from '../../types';
import { Link } from 'react-router-dom';

export const PricingSection: React.FC = () => {
  const [packages, setPackages] = useState<Package[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPackages = async () => {
      try {
        const { data, error } = await supabase
          .from('packages')
          .select('*')
          .eq('is_active', true)
          .order('price', { ascending: true });

        if (error) throw error;
        setPackages(data || []);
      } catch (error) {
        console.error('Error fetching packages:', error);
        // Fallback packages if DB query fails
        setPackages([
          {
            id: '1',
            name: 'Starter',
            price: 49,
            description: 'Perfect for getting started quickly',
            features: [
              'LLC Formation & State Filing',
              'Articles of Organization',
              'Email Support',
              'Basic Compliance Guide',
              'Standard Processing'
            ],
            is_popular: false,
            is_active: true,
            includes_ein: false,
            includes_registered_agent: false,
            same_day_filing: false,
          },
          {
            id: '2',
            name: 'Professional',
            price: 149,
            description: 'Most popular - everything you need',
            features: [
              'Everything in Starter',
              'EIN Number Application',
              'Registered Agent Service (1 Year)',
              'Operating Agreement Template',
              'Priority Phone Support',
              'Banking Resolution Letter',
              'Compliance Calendar',
            ],
            is_popular: true,
            is_active: true,
            includes_ein: true,
            includes_registered_agent: true,
            same_day_filing: false,
          },
          {
            id: '3',
            name: 'Premium',
            price: 299,
            description: 'Complete business setup solution',
            features: [
              'Everything in Professional',
              'Same-Day State Filing',
              'Express EIN Processing',
              'Custom Operating Agreement',
              'Business Banking Kit',
              'Tax Election Guidance',
              'Dedicated Account Manager',
              'Lifetime Compliance Support',
            ],
            is_popular: false,
            is_active: true,
            includes_ein: true,
            includes_registered_agent: true,
            same_day_filing: true,
          },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchPackages();
  }, []);

  if (loading) {
    return (
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-1/3 mx-auto mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  const getPackageIcon = (index: number) => {
    const icons = [Zap, Star, Shield];
    return icons[index] || Zap;
  };

  const getPackageBadge = (pkg: Package) => {
    if (pkg.is_popular) return { text: 'MOST POPULAR', color: 'bg-blue-500' };
    if (pkg.same_day_filing) return { text: 'FASTEST', color: 'bg-purple-500' };
    if (pkg.price <= 49) return { text: 'BEST VALUE', color: 'bg-green-500' };
    return null;
  };

  return (
    <section id="pricing" className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-3 py-1.5 rounded-full text-sm font-medium mb-3">
            <Star className="h-4 w-4" />
            <span>Simple Pricing</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Choose Your LLC Package
          </h2>
          <p className="text-gray-600 text-sm">
            All packages include 24-hour filing guarantee
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {packages.map((pkg, index) => {
            const Icon = getPackageIcon(index);
            const badge = getPackageBadge(pkg);
            
            return (
              <Card 
                key={pkg.id} 
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-lg ${
                  pkg.is_popular 
                    ? 'ring-2 ring-blue-500 shadow-md' 
                    : ''
                }`}
                padding="none"
              >
                {badge && (
                  <div className={`absolute top-0 left-0 right-0 ${badge.color} text-white text-center py-1 text-xs font-bold`}>
                    {badge.text}
                  </div>
                )}
                
                <div className={`${badge ? 'pt-8' : 'pt-4'} pb-4 px-4`}>
                  {/* Package Header */}
                  <div className="text-center mb-3">
                    <div className={`w-12 h-12 mx-auto mb-2 rounded-full flex items-center justify-center ${
                      pkg.is_popular ? 'bg-blue-100' : 'bg-gray-100'
                    }`}>
                      <Icon className={`h-6 w-6 ${
                        pkg.is_popular ? 'text-blue-600' : 'text-gray-600'
                      }`} />
                    </div>
                    
                    <h3 className="text-lg font-bold text-gray-900 mb-1">
                      {pkg.name}
                    </h3>
                    <p className="text-gray-600 mb-2 text-xs">{pkg.description}</p>
                    
                    {/* Price */}
                    <div className="mb-3">
                      <div className="flex items-center justify-center mb-1">
                        <span className="text-2xl font-bold text-gray-900">
                          ${pkg.price}
                        </span>
                      </div>
                      <div className="text-gray-600 text-xs">
                        + state filing fee
                      </div>
                    </div>
                  </div>

                  {/* Features */}
                  <ul className="space-y-1.5 mb-4 px-2">
                    {pkg.features.slice(0, 5).map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start space-x-1.5">
                        <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700 text-xs">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA Button */}
                  <Link to={`/checkout?package=${pkg.id}`} className="block px-4">
                    <Button 
                      className={`w-full text-sm py-2 transition-all duration-200 ${
                        pkg.is_popular 
                          ? 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800' 
                          : ''
                      }`}
                      variant={pkg.is_popular ? 'primary' : 'outline'}
                      size="sm"
                    >
                      {pkg.is_popular ? 'Start Now' : 'Get Started'}
                    </Button>
                  </Link>

                  {/* Processing time */}
                  <div className="text-center mt-2">
                    <div className="flex items-center justify-center space-x-1 text-xs text-gray-600">
                      <Clock className="h-3 w-3" />
                      <span>
                        {pkg.same_day_filing ? 'Same-day filing' : 
                         (pkg.id === '1' ? 'Standard processing' : '24-hour guarantee')}
                      </span>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Trust indicators */}
        <div className="flex justify-center mt-6 space-x-4 text-xs">
          <div className="flex items-center space-x-1 text-gray-600">
            <Shield className="h-4 w-4 text-green-500" />
            <span>Money-Back Guarantee</span>
          </div>
          <div className="flex items-center space-x-1 text-gray-600">
            <Clock className="h-4 w-4 text-blue-500" />
            <span>Fast Processing</span>
          </div>
          <div className="flex items-center space-x-1 text-gray-600">
            <Star className="h-4 w-4 text-yellow-500" />
            <span>4.9/5 Rating</span>
          </div>
        </div>
      </div>
    </section>
  );
};