import React, { useEffect, useState } from 'react';
import { MessageCircle, Phone } from 'lucide-react';
import { supabase } from '../../lib/supabase';

export const WhatsAppButton: React.FC = () => {
  const [isEnabled, setIsEnabled] = useState<boolean | null>(null);
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [message, setMessage] = useState('Hi! I need help with LLC formation.');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const fetchWhatsAppSettings = async () => {
      try {
        const { data, error } = await supabase 
          .from('settings')
          .select('whatsapp_enabled, whatsapp_number, whatsapp_message')
          .eq('key', 'global')
          .single();

        if (error) {
          console.error('Error fetching WhatsApp settings:', error);
          setIsEnabled(false);
          return;
        }
        
        if (data && data.whatsapp_enabled !== null) {
          setIsEnabled(data.whatsapp_enabled === true);
          setWhatsappNumber(data.whatsapp_number || '');
          setMessage(data.whatsapp_message || 'Hi! I need help with LLC formation.');
        } else {
          setIsEnabled(false);
        }
      } catch (error) {
        // Fallback settings if DB query fails
        console.error('Error in WhatsApp settings:', error);
        setIsEnabled(false);
        setWhatsappNumber('+1234567890');
        setMessage('Hi! I need help with LLC formation.');
      }
    };

    fetchWhatsAppSettings();

    // Show button after a delay for better UX
    const timer = setTimeout(() => setIsVisible(true), 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleWhatsAppClick = (e: React.MouseEvent) => {
    e.preventDefault();
    
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/\D/g, '')}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  // Don't render anything if explicitly disabled or still loading
  if (isEnabled === false || !whatsappNumber || !isVisible) {
    return null;
  }

  return (
    <>
      {/* Main WhatsApp Button */}
      <button
        onClick={handleWhatsAppClick}
        className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-2xl transition-all duration-300 hover:scale-110 z-50 group animate-pulse"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle className="h-7 w-7" />
        
        {/* Notification dot */}
        <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
        </div>

        {/* Tooltip */}
        <div className="absolute right-full mr-3 top-1/2 transform -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
          Chat with our LLC experts
          <div className="absolute left-full top-1/2 transform -translate-y-1/2 border-4 border-transparent border-l-gray-900"></div>
        </div>
      </button>

      {/* Call-to-action popup */}
      <div className="fixed bottom-24 right-6 bg-white rounded-lg shadow-lg p-4 max-w-xs z-40 border border-gray-200 animate-slide-up">
        <div className="flex items-start space-x-3">
          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
            <Phone className="h-5 w-5 text-green-600" />
          </div>
          <div className="flex-1">
            <h4 className="font-semibold text-gray-900 text-sm mb-1">
              Need Help? Chat Now!
            </h4>
            <p className="text-xs text-gray-600 mb-2">
              Get instant answers about LLC formation
            </p>
            <button
              onClick={handleWhatsAppClick}
              className="text-xs bg-green-500 text-white px-3 py-1 rounded-full hover:bg-green-600 transition-colors"
            >
              Start Chat
            </button>
          </div>
          <button
            onClick={() => setIsVisible(false)}
            className="text-gray-400 hover:text-gray-600 text-xs p-1"
          >
            ×
          </button>
        </div>
      </div>
    </>
  );
};