import React from 'react';
import { CheckCircle, ArrowRight, MessageCircle, Star, Shield, Clock } from 'lucide-react';
import { Button } from '../ui/Button';
import { Link } from 'react-router-dom';
import { useWhatsApp } from '../../hooks/useWhatsApp';

export const HeroSection: React.FC = () => {
  const { openWhatsApp } = useWhatsApp();

  const features = [
    'State Filing Included',
    'Professional Service',
    'All Documents Provided',
    'Lifetime Support',
  ];

  const trustIndicators = [
    { icon: Star, text: '4.9★', subtext: '2,000+ Reviews' },
    { icon: Shield, text: 'Guaranteed', subtext: '24-Hour Filing' },
    { icon: Clock, text: 'Fast Setup', subtext: 'Same Day Available' },
  ];

  return (
    <section className="relative py-8 bg-gradient-to-br from-blue-50 via-white to-indigo-50 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="absolute top-0 right-0 w-64 h-64 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-15 animate-blob"></div>
      <div className="absolute top-0 left-0 w-64 h-64 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-15 animate-blob animation-delay-2000"></div>
      
      {/* 24 Hour Guarantee Card - Top Right */}
      <div className="absolute top-4 right-4 bg-white rounded-lg shadow-md p-3 border border-gray-200 max-w-xs z-10 hidden lg:block">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
            <Clock className="h-5 w-5 text-green-600" />
          </div>
          <div>
            <h4 className="font-bold text-gray-900 text-xs">24-Hour LLC</h4>
            <p className="text-green-600 font-semibold text-xs">Guaranteed</p>
            <p className="text-xs text-gray-500">Filed or money back</p>
          </div>
        </div>
      </div>
      
      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
          {/* Left side - Content */}
          <div className="text-center lg:text-left">
            {/* Social Proof Badge */}
            <div className="inline-flex items-center space-x-2 bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium mb-3">
              <Star className="h-4 w-4 fill-current" />
              <span>1,800+ LLCs Formed</span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-3 leading-tight">
              Start Your LLC in{' '}
              <span className="text-blue-600 relative">
                24 Hours
                <div className="absolute -bottom-1 left-0 right-0 h-2 bg-yellow-300 opacity-30 rounded"></div>
              </span>
              {' '}— Just{' '}
              <span className="text-green-600">$49</span>
            </h1>
            
            <p className="text-base text-gray-600 mb-4 leading-relaxed">
              <strong>Everything included:</strong> State filing, professional service, 
              all documents, and lifetime support. No hidden fees.
            </p>

            {/* Trust Indicators */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              {trustIndicators.map((indicator, index) => {
                const Icon = indicator.icon;
                return (
                  <div key={index} className="text-center">
                    <div className="bg-white rounded-lg p-2 shadow-sm border border-gray-100">
                      <Icon className="h-4 w-4 text-blue-600 mx-auto mb-0.5" />
                      <div className="text-xs font-bold text-gray-900">{indicator.text}</div>
                      <div className="text-xs text-gray-500">{indicator.subtext}</div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-2 mb-4">
              <Link to="/checkout" className="flex-1 sm:flex-none">
                <Button size="md" className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-base px-5 py-2 shadow-md hover:shadow-lg transition-all duration-200 transform hover:scale-105">
                  <span>Start My LLC Now</span>
                  <ArrowRight className="h-5 w-5 ml-2" />
                </Button>
              </Link>
              <Button variant="outline" size="sm" onClick={openWhatsApp} className="border border-gray-300 hover:border-blue-500 hover:text-blue-600 transition-all duration-200">
                <MessageCircle className="h-4 w-4 mr-2" />
                Chat with Expert
              </Button>
            </div>

            {/* Features List */}
            <div className="grid grid-cols-2 gap-1.5">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-1.5 text-xs">
                  <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                  <span className="text-gray-700 font-medium">{feature}</span>
                </div>
              ))}
            </div>

            {/* Urgency Element */}
            <div className="mt-3 p-2 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-center space-x-1.5">
                <Clock className="h-4 w-4 text-yellow-600" />
                <span className="text-yellow-800 font-medium text-xs">
                  Limited Time: Professional LLC formation starting at just $49!
                </span>
              </div>
            </div>
          </div>

          {/* Right side - Visual */}
          <div className="relative">
            <div className="bg-white rounded-xl shadow-xl p-4 border border-gray-100">
              {/* Progress Indicator */}
              <div className="flex items-center justify-between mb-3">
                <div className="text-center">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-0.5">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <span className="text-xs text-gray-500">Filed</span>
                </div>
                <div className="flex-1 h-1 bg-green-200 mx-2 rounded"></div>
                <div className="text-center">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-0.5">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <span className="text-xs text-gray-500">EIN</span>
                </div>
                <div className="flex-1 h-1 bg-green-200 mx-2 rounded"></div>
                <div className="text-center">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-0.5">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <span className="text-xs text-gray-500">Done</span>
                </div>
              </div>

              <div className="text-center mb-3">
                <h3 className="text-base font-semibold text-gray-900 mb-0.5">
                  Your LLC Formation
                </h3>
                <p className="text-xs text-gray-600">Complete in 24 hours guaranteed</p>
              </div>
              
              <div className="space-y-2">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-1.5 p-2 bg-green-50 rounded-lg border border-green-100">
                    <CheckCircle className="h-3.5 w-3.5 text-green-500" />
                    <span className="text-gray-700 font-medium text-xs">{feature}</span>
                  </div>
                ))}
              </div>

              {/* Price Display */}
              <div className="mt-3 p-2 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-center">
                  <div className="text-xl font-bold text-blue-600 mb-0.5">$49</div>
                  <div className="text-xs text-blue-700">+ state filing fee</div>
                </div>
              </div>
            </div>

            {/* Floating testimonial */}
            <div className="absolute -bottom-3 -left-2 bg-white rounded-lg shadow-md p-2 border border-gray-100 max-w-xs z-10">
              <div className="flex items-center space-x-1.5 mb-1">
                <div className="flex text-yellow-400 space-x-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-3 w-3 fill-current" />
                  ))}
                </div>
                <span className="text-xs font-medium text-gray-900">5.0</span>
              </div>
              <p className="text-xs text-gray-600">
                "Filed my LLC in 18 hours! Amazing service."
              </p>
              <p className="text-xs text-gray-500 mt-0.5">- Sarah M., Entrepreneur</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};