import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { FAQ } from '../../types';
import { Card } from '../../components/ui/Card';
import { ChevronDown, ChevronUp, AlertCircle } from 'lucide-react';

export const FAQSection: React.FC = () => {
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchFaqs = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const { data, error } = await supabase
          .from('faqs')
          .select('*')
          .eq('is_active', true)
          .order('order_index', { ascending: true });

        if (error) {
          console.error('Supabase error:', error);
          throw new Error(`Database error: ${error.message}`);
        }
        
        if (data && data.length > 0) {
          setFaqs(data);
        } else {
          // If no data from database, use fallback
          setFaqs(getFallbackFaqs());
        }
      } catch (error) {
        console.error('Error fetching FAQs:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        setError(`Failed to load FAQs: ${errorMessage}`);
        // Use fallback FAQs when there's an error
        setFaqs(getFallbackFaqs());
      } finally {
        setLoading(false);
      }
    };

    fetchFaqs();
  }, []);

  const getFallbackFaqs = (): FAQ[] => [
    {
      id: '1',
      question: 'How long does it take to form an LLC?',
      answer: 'We guarantee your LLC will be filed within 24 hours. State processing times vary from 1-10 business days depending on the state.',
      is_active: true,
      order_index: 1
    },
    {
      id: '2',
      question: 'What is included in the $49 package?',
      answer: 'Our basic package includes state filing, preparation of Articles of Organization, and email support. EIN and Registered Agent services are available as add-ons.',
      is_active: true,
      order_index: 2
    },
    {
      id: '3',
      question: 'Do I need a registered agent?',
      answer: 'Yes, every LLC needs a registered agent. You can serve as your own registered agent or hire our professional registered agent service.',
      is_active: true,
      order_index: 3
    },
    {
      id: '4',
      question: 'What states do you file in?',
      answer: 'We file LLCs in all 50 states. Each state has different filing fees and processing times.',
      is_active: true,
      order_index: 4
    },
    {
      id: '5',
      question: 'What is an EIN and do I need one?',
      answer: 'An EIN (Employer Identification Number) is a federal tax ID for your business. You need one to open a business bank account, hire employees, or file taxes.',
      is_active: true,
      order_index: 5
    }
  ];
  const toggleFaq = (id: string) => {
    setExpandedFaq(expandedFaq === id ? null : id);
  };

  if (loading) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-1/3 mx-auto mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="faq" className="py-16 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-gray-600">
            Get answers to common questions about LLC formation
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-yellow-600 mr-2" />
              <p className="text-sm text-yellow-800">
                {error} - Showing default FAQs below.
              </p>
            </div>
          </div>
        )}
        <Card>
          <div className="divide-y divide-gray-200">
            {faqs.map((faq) => (
              <div key={faq.id} className="py-6">
                <button
                  className="flex justify-between items-center w-full text-left focus:outline-none"
                  onClick={() => toggleFaq(faq.id)}
                >
                  <h3 className="text-lg font-semibold text-gray-900">
                    {faq.question}
                  </h3>
                  {expandedFaq === faq.id ? (
                    <ChevronUp className="h-5 w-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-500" />
                  )}
                </button>
                {expandedFaq === faq.id && (
                  <div className="mt-3 text-gray-600">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </Card>
      </div>
    </section>
  );
};