import React, { useState, useEffect } from 'react';
import { Clock, Zap, Gift, X } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Link } from 'react-router-dom';
import { supabase } from '../../lib/supabase';

interface UrgencySettings {
  popup_enabled: boolean;
  popup_title: string;
  popup_subtitle: string;
  popup_offer_text: string;
  popup_cta_text: string;
  popup_disclaimer: string;
}

export const UrgencyPopup: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [settings, setSettings] = useState<UrgencySettings>({
    popup_enabled: false,
    popup_title: '🔥 Last Chance: FREE EIN Worth $275!',
    popup_subtitle: "Don't miss out! Get your LLC formed with a FREE EIN number (normally $275) when you start today. This exclusive offer expires soon!",
    popup_offer_text: 'FREE EIN Number - Save $275 on federal tax ID',
    popup_cta_text: '🚀 Claim FREE EIN Now - Only $49',
    popup_disclaimer: '* Limited time offer. EIN normally costs $275. Offer valid for new customers only.'
  });
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59
  });

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const { data, error } = await supabase
          .from('settings')
          .select('*')
          .eq('key', 'global')
          .single();

        if (data && data.popup_enabled) {
          setSettings({
            popup_enabled: data.popup_enabled,
            popup_title: data.popup_title || settings.popup_title,
            popup_subtitle: data.popup_subtitle || settings.popup_subtitle,
            popup_offer_text: data.popup_offer_text || settings.popup_offer_text,
            popup_cta_text: data.popup_cta_text || settings.popup_cta_text,
            popup_disclaimer: data.popup_disclaimer || settings.popup_disclaimer
          });
          
          // Show popup after 5 seconds if enabled
          const timer = setTimeout(() => {
            setIsVisible(true);
          }, 5000);
          
          return () => clearTimeout(timer);
        }
      } catch (error) {
        console.error('Error fetching popup settings:', error);
      }
    };

    fetchSettings();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          // Reset to 24 hours when countdown reaches 0
          return { hours: 23, minutes: 59, seconds: 59 };
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isVisible]);

  const handleClose = () => {
    setIsVisible(false);
    // Set a cookie or localStorage to prevent showing again for this session
    localStorage.setItem('urgencyPopupClosed', 'true');
  };

  // Don't show if disabled, already closed this session, or not enabled
  if (!settings.popup_enabled || !isVisible || localStorage.getItem('urgencyPopupClosed')) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="max-w-2xl w-full relative overflow-hidden">
        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 z-10 p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X className="h-5 w-5 text-gray-500" />
        </button>

        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-red-600 via-red-700 to-red-800"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"></div>
        
        <div className="relative p-8 text-white text-center">
          {/* Urgency badge */}
          <div className="inline-flex items-center space-x-2 bg-yellow-400 text-yellow-900 px-4 py-2 rounded-full text-sm font-bold mb-6 animate-pulse">
            <Zap className="h-4 w-4" />
            <span>LIMITED TIME OFFER</span>
          </div>

          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            {settings.popup_title}
          </h2>
          
          <p className="text-xl text-red-100 mb-8 max-w-3xl mx-auto">
            {settings.popup_subtitle}
          </p>

          {/* Countdown timer */}
          <div className="flex justify-center mb-8">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-4">
                <Clock className="h-6 w-6 text-yellow-400" />
                <span className="text-lg font-semibold">Offer expires in:</span>
              </div>
              
              <div className="flex justify-center space-x-4">
                <div className="text-center">
                  <div className="bg-white/20 rounded-lg p-3 min-w-[60px] animate-countdown">
                    <div className="text-2xl font-bold">{timeLeft.hours.toString().padStart(2, '0')}</div>
                    <div className="text-xs text-red-200">HOURS</div>
                  </div>
                </div>
                <div className="text-center">
                  <div className="bg-white/20 rounded-lg p-3 min-w-[60px] animate-countdown">
                    <div className="text-2xl font-bold">{timeLeft.minutes.toString().padStart(2, '0')}</div>
                    <div className="text-xs text-red-200">MINS</div>
                  </div>
                </div>
                <div className="text-center">
                  <div className="bg-white/20 rounded-lg p-3 min-w-[60px] animate-countdown">
                    <div className="text-2xl font-bold">{timeLeft.seconds.toString().padStart(2, '0')}</div>
                    <div className="text-xs text-red-200">SECS</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Value proposition */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="bg-white/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <Gift className="h-8 w-8 text-yellow-400" />
              </div>
              <h3 className="font-semibold mb-2">{settings.popup_offer_text}</h3>
            </div>
            <div className="text-center">
              <div className="bg-white/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <Zap className="h-8 w-8 text-yellow-400" />
              </div>
              <h3 className="font-semibold mb-2">24-Hour Filing</h3>
              <p className="text-red-100 text-sm">Guaranteed fast processing</p>
            </div>
            <div className="text-center">
              <div className="bg-white/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <Clock className="h-8 w-8 text-yellow-400" />
              </div>
              <h3 className="font-semibold mb-2">Complete Setup</h3>
              <p className="text-red-100 text-sm">Everything you need included</p>
            </div>
          </div>

          {/* CTA */}
          <div className="space-y-4">
            <Link to="/checkout" onClick={handleClose}>
              <Button 
                size="xl" 
                className="bg-yellow-400 text-yellow-900 hover:bg-yellow-300 font-bold text-lg px-12 py-4 shadow-2xl hover:shadow-3xl transform hover:scale-105 animate-pulse-glow"
              >
                {settings.popup_cta_text}
              </Button>
            </Link>
            
            <div className="text-sm text-red-200">
              <span className="line-through">Regular price: $324</span>
              <span className="ml-2 font-bold text-yellow-400">Today: $49 (Save $275!)</span>
            </div>
            
            <p className="text-xs text-red-200 max-w-md mx-auto">
              {settings.popup_disclaimer}
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
};