import React from 'react';
import { Check, X, Star, Trophy } from 'lucide-react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Link } from 'react-router-dom';

export const ComparisonTable: React.FC = () => {
  const competitors = [
    {
      name: 'Razorfile',
      price: '$49',
      originalPrice: '$324',
      features: {
        filing: true,
        ein: true,
        support: true,
        guarantee: true,
        speed: '24 hours',
        rating: '4.9/5',
      },
      isOurs: true,
    },
    {
      name: 'ZenBusiness',
      price: '$79',
      originalPrice: '$149',
      features: {
        filing: true,
        ein: false,
        support: true,
        guarantee: false,
        speed: '3-5 days',
        rating: '4.2/5',
      },
      isOurs: false,
    },
    {
      name: 'Bizee',
      price: '$99',
      originalPrice: '$199',
      features: {
        filing: true,
        ein: true,
        support: false,
        guarantee: false,
        speed: '5-7 days',
        rating: '3.8/5',
      },
      isOurs: false,
    },
    {
      name: 'TailorBrands',
      price: '$129',
      originalPrice: '$249',
      features: {
        filing: true,
        ein: false,
        support: true,
        guarantee: false,
        speed: '7-10 days',
        rating: '3.5/5',
      },
      isOurs: false,
    },
  ];

  return (
    <section className="py-12 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-2 bg-yellow-100 text-yellow-800 px-3 py-1.5 rounded-full text-sm font-medium mb-3">
            <Trophy className="h-4 w-4" />
            <span>Industry Comparison</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Why Razorfile Beats the Competition
          </h2>
          <p className="text-gray-600">
            See how we stack up against other LLC formation services
          </p>
        </div>

        <Card className="overflow-hidden shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="text-left py-3 px-3 font-semibold text-gray-900 text-sm">
                    Service
                  </th>
                  {competitors.map((competitor) => (
                    <th
                      key={competitor.name}
                      className={`text-center py-4 px-3 font-bold relative text-sm ${
                        competitor.isOurs 
                          ? 'text-blue-600 bg-blue-50 border-l-2 border-r-2 border-blue-500' 
                          : 'text-gray-900'
                      }`}
                    >
                      {competitor.isOurs && (
                        <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 z-50">
                          <div className="bg-blue-500 text-white px-2 py-0.5 rounded-full text-xs font-bold flex items-center space-x-1">
                            <Star className="h-3 w-3 fill-current" />
                            <span>BEST</span>
                          </div>
                        </div>
                      )}
                      <div className={competitor.isOurs ? 'mt-3' : ''}>
                        {competitor.name}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Pricing Row */}
                <tr className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-3 font-medium text-gray-900 text-sm">
                    Price
                  </td>
                  {competitors.map((competitor) => (
                    <td
                      key={competitor.name}
                      className={`text-center py-3 px-3 ${
                        competitor.isOurs 
                          ? 'text-blue-600 bg-blue-50 border-l-2 border-r-2 border-blue-500' 
                          : 'text-gray-900'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <div className={`text-xl font-bold ${
                          competitor.isOurs ? 'text-blue-600' : 'text-gray-900'
                        }`}>
                          {competitor.price}
                        </div>
                        <div className="text-xs text-gray-500 line-through">
                          {competitor.originalPrice}
                        </div>
                        {competitor.isOurs && (
                          <div className="text-xs text-green-600 font-bold">
                            Best Value!
                          </div>
                        )}
                      </div>
                    </td>
                  ))}
                </tr>

                {/* Features Rows */}
                <tr className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-2.5 px-3 font-medium text-gray-900 text-sm">
                    EIN Application Service
                  </td>
                  {competitors.map((competitor) => (
                    <td
                      key={competitor.name}
                      className={`text-center py-2.5 px-3 ${
                        competitor.isOurs ? 'bg-blue-50 border-l-2 border-r-2 border-blue-500' : ''
                      }`}
                    >
                      {competitor.features.ein ? (
                        <Check className="h-5 w-5 text-green-500 mx-auto" />
                      ) : (
                        <X className="h-5 w-5 text-red-500 mx-auto" />
                      )}
                    </td>
                  ))}
                </tr>

                <tr className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-2.5 px-3 font-medium text-gray-900 text-sm">
                    24/7 Support
                  </td>
                  {competitors.map((competitor) => (
                    <td
                      key={competitor.name}
                      className={`text-center py-2.5 px-3 ${
                        competitor.isOurs ? 'bg-blue-50 border-l-2 border-r-2 border-blue-500' : ''
                      }`}
                    >
                      {competitor.features.support ? (
                        <Check className="h-5 w-5 text-green-500 mx-auto" />
                      ) : (
                        <X className="h-5 w-5 text-red-500 mx-auto" />
                      )}
                    </td>
                  ))}
                </tr>

                <tr className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-2.5 px-3 font-medium text-gray-900 text-sm">
                    24-Hour Guarantee
                  </td>
                  {competitors.map((competitor) => (
                    <td
                      key={competitor.name}
                      className={`text-center py-2.5 px-3 ${
                        competitor.isOurs ? 'bg-blue-50 border-l-2 border-r-2 border-blue-500' : ''
                      }`}
                    >
                      {competitor.features.guarantee ? (
                        <Check className="h-5 w-5 text-green-500 mx-auto" />
                      ) : (
                        <X className="h-5 w-5 text-red-500 mx-auto" />
                      )}
                    </td>
                  ))}
                </tr>

                <tr className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-2.5 px-3 font-medium text-gray-900 text-sm">
                    Processing Time
                  </td>
                  {competitors.map((competitor) => (
                    <td
                      key={competitor.name}
                      className={`text-center py-2.5 px-3 ${
                        competitor.isOurs ? 'bg-blue-50 border-l-2 border-r-2 border-blue-500' : ''
                      }`}
                    >
                      <span className={`font-semibold text-sm ${
                        competitor.isOurs ? 'text-blue-600' : 'text-gray-600'
                      }`}>
                        {competitor.features.speed}
                      </span>
                    </td>
                  ))}
                </tr>

                <tr className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-2.5 px-3 font-medium text-gray-900 text-sm">
                    Rating
                  </td>
                  {competitors.map((competitor) => (
                    <td
                      key={competitor.name}
                      className={`text-center py-2.5 px-3 ${
                        competitor.isOurs ? 'bg-blue-50 border-l-2 border-r-2 border-blue-500' : ''
                      }`}
                    >
                      <div className="flex items-center justify-center space-x-1 min-h-[24px]">
                        <Star className={`h-4 w-4 ${
                          competitor.isOurs ? 'text-yellow-400 fill-current' : 'text-gray-400'
                        }`} />
                        <span className={`font-semibold text-xs ${
                          competitor.isOurs ? 'text-blue-600' : 'text-gray-600'
                        }`}>
                          {competitor.features.rating}
                        </span>
                      </div>
                    </td>
                  ))}
                </tr>

                {/* CTA Row */}
                <tr className="bg-gray-50">
                  <td className="py-3 px-3 font-semibold text-gray-900 text-sm">
                    Get Started
                  </td>
                  {competitors.map((competitor) => (
                    <td
                      key={competitor.name}
                      className={`text-center py-3 px-3 ${
                        competitor.isOurs ? 'bg-blue-50 border-l-2 border-r-2 border-blue-500' : ''
                      }`}
                    >
                      {competitor.isOurs ? (
                        <Link to="/checkout">
                          <Button size="sm" className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-200 text-xs px-3 py-1.5">
                            Start Now
                          </Button>
                        </Link>
                      ) : (
                        <Button variant="outline" size="sm" disabled className="opacity-50 text-xs px-3 py-1.5">
                          Visit Site
                        </Button>
                      )}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </Card>

        {/* Bottom CTA */}
        <div className="text-center mt-8">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg p-5 text-white">
            <h3 className="text-lg font-bold mb-2">
              Ready to Start Your LLC with the Best Service?
            </h3>
            <p className="text-blue-100 mb-3 text-sm">
              Join 10,000+ entrepreneurs who chose Razorfile
            </p>
            <Link to="/checkout">
              <Button size="md" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100 shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-200">
                Start My LLC for $49
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};