import React from 'react';
import { Star, Quote } from 'lucide-react';
import { Card } from '../ui/Card';

export const TestimonialsSection: React.FC = () => {
  const testimonials = [
    {
      id: 1,
      name: 'Sarah Johnson',
      title: 'E-commerce Entrepreneur',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      rating: 5,
      text: "Razorfile made LLC formation incredibly simple. Filed in 18 hours and got my EIN the same day. The support team was amazing throughout the process!",
      highlight: "Filed in 18 hours"
    },
    {
      id: 2,
      name: 'Michael Chen',
      title: 'Tech Startup Founder',
      image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      rating: 5,
      text: "Best decision I made for my startup. The process was seamless, and having everything done in 24 hours let me focus on building my business instead of paperwork.",
      highlight: "Seamless process"
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      title: 'Freelance Designer',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      rating: 5,
      text: "I was worried about the complexity, but Razorfile handled everything. Great value for money and the compliance reminders are a lifesaver!",
      highlight: "Great value"
    },
    {
      id: 4,
      name: 'David Park',
      title: 'Real Estate Investor',
      image: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      rating: 5,
      text: "Used Razorfile for multiple LLCs. Consistent quality, fast turnaround, and excellent customer service. Highly recommend to anyone starting a business.",
      highlight: "Multiple LLCs"
    },
    {
      id: 5,
      name: 'Lisa Thompson',
      title: 'Consultant',
      image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      rating: 5,
      text: "The 24-hour guarantee isn't just marketing - they actually delivered! Professional service and transparent pricing. No hidden fees whatsoever.",
      highlight: "No hidden fees"
    },
    {
      id: 6,
      name: 'James Wilson',
      title: 'Restaurant Owner',
      image: 'https://images.pexels.com/photos/1300402/pexels-photo-1300402.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      rating: 5,
      text: "Needed to get my LLC set up quickly for a business opportunity. Razorfile came through with same-day filing. Couldn't be happier with the service!",
      highlight: "Same-day filing"
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Star className="h-4 w-4 fill-current" />
            <span>1,800+ LLCs Formed</span>
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-3">
            What Our Customers Say
          </h2>
          <p className="text-lg text-gray-600 mb-6">
            Join thousands of entrepreneurs who chose Razorfile
          </p>
          
          {/* Overall rating */}
          <div className="flex items-center justify-center space-x-2 mb-6">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-6 w-6 fill-current" />
              ))}
            </div>
            <span className="text-xl font-bold text-gray-900">4.9</span>
            <span className="text-gray-600 text-sm">out of 5 stars</span>
            <span className="text-gray-500 text-sm">(2,847 reviews)</span>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial) => (
            <Card 
              key={testimonial.id} 
              className="testimonial-card hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              padding="md"
            >
              {/* Quote icon */}
              <div className="flex justify-between items-start mb-3">
                <Quote className="h-6 w-6 text-blue-500 opacity-50" />
                <div className="flex text-yellow-400">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
              </div>

              {/* Testimonial text */}
              <blockquote className="text-gray-700 mb-4 leading-relaxed text-sm">
                "{testimonial.text}"
              </blockquote>

              {/* Highlight badge */}
              <div className="mb-3">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  {testimonial.highlight}
                </span>
              </div>

              {/* Author info */}
              <div className="flex items-center space-x-3">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-10 h-10 rounded-full object-cover border-2 border-gray-200"
                />
                <div>
                  <div className="font-semibold text-gray-900 text-sm">
                    {testimonial.name}
                  </div>
                  <div className="text-xs text-gray-600">
                    {testimonial.title}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Trust indicators */}
        <div className="mt-12 text-center">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600 mb-1">1,800+</div>
              <div className="text-gray-600 text-sm">LLCs Formed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600 mb-1">24hrs</div>
              <div className="text-gray-600 text-sm">Average Filing</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600 mb-1">4.9/5</div>
              <div className="text-gray-600 text-sm">Customer Rating</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600 mb-1">99.9%</div>
              <div className="text-gray-600 text-sm">Success Rate</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};