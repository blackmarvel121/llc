import React, { useEffect, useState } from 'react';
import { CheckCircle, X, Shield, Clock } from 'lucide-react';
import { supabase } from '../../lib/supabase';

export const AnnouncementBanner: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [announcement, setAnnouncement] = useState('');

  useEffect(() => {
    const fetchAnnouncement = async () => {
      try {
        const { data, error } = await supabase
          .from('settings')
          .select('announcement_enabled, announcement_text')
          .eq('key', 'global')
          .single();

        if (data?.announcement_enabled) {
          setAnnouncement(data.announcement_text || '✅ 24-Hour LLC Guarantee by Razorfile');
          setIsVisible(true);
        }
      } catch (error) {
        // Fallback to default announcement if DB query fails
        setAnnouncement('✅ 24-Hour LLC Guarantee by Razorfile');
        setIsVisible(true);
      }
    };

    fetchAnnouncement();
  }, []);

  if (!isVisible) return null;

  return (
    <div className="bg-gradient-to-r from-green-600 to-green-700 text-white py-4 px-4 relative shadow-lg border-b-2 border-green-800">
      <div className="max-w-7xl mx-auto flex items-center justify-center">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 bg-white/20 rounded-full px-3 py-1">
            <Shield className="h-5 w-5 text-green-100" />
            <span className="text-green-100 font-semibold text-xs uppercase tracking-wide">
              Guaranteed
            </span>
          </div>
          <CheckCircle className="h-6 w-6 text-green-200" />
          <span className="font-bold text-base sm:text-lg">
            {announcement}
          </span>
          <div className="flex items-center space-x-1 bg-white/20 rounded-full px-2 py-1">
            <Clock className="h-4 w-4 text-green-100" />
            <span className="text-green-100 font-medium text-xs">
              24HR
            </span>
          </div>
        </div>
        <button
          onClick={() => setIsVisible(false)}
          className="absolute right-4 top-1/2 transform -translate-y-1/2 hover:bg-white/20 rounded-full p-1.5 transition-all duration-200 hover:scale-110"
        >
          <X className="h-4 w-4 text-green-100" />
        </button>
      </div>
      
      {/* Trust indicators */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent animate-pulse"></div>
    </div>
  );
};