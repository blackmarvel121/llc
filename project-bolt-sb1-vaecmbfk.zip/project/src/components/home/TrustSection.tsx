import React from 'react';
import { Shield, Award, Users, Clock, CheckCircle, Star } from 'lucide-react';
import { Card } from '../ui/Card';

export const TrustSection: React.FC = () => {
  const trustIndicators = [
    {
      icon: Shield,
      title: '100% Secure & Compliant',
      description: 'Bank-level security with SSL encryption and SOC 2 compliance',
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      icon: Award,
      title: 'Industry Leading',
      description: 'Rated #1 LLC formation service by TrustPilot and Google Reviews',
      color: 'text-blue-600',
      bgColor: 'bg-blue-100'
    },
    {
      icon: Users,
      title: '10,000+ Customers',
      description: 'Trusted by entrepreneurs, startups, and established businesses',
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    },
    {
      icon: Clock,
      title: '24-Hour Guarantee',
      description: 'Your LLC will be filed within 24 hours or your money back',
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100'
    }
  ];

  const certifications = [
    {
      name: 'Better Business Bureau',
      rating: 'A+',
      logo: '🏆'
    },
    {
      name: 'TrustPilot',
      rating: '4.9/5',
      logo: '⭐'
    },
    {
      name: 'Google Reviews',
      rating: '4.8/5',
      logo: '📱'
    },
    {
      name: 'Yelp',
      rating: '4.7/5',
      logo: '🔥'
    }
  ];

  const guarantees = [
    'Money-back guarantee',
    'No hidden fees',
    '24/7 customer support',
    'Lifetime compliance alerts',
    'Free document revisions',
    'State filing guarantee'
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Shield className="h-4 w-4" />
            <span>Trusted & Secure</span>
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-3">
            Why 1,800+ Entrepreneurs Trust Razorfile
          </h2>
          <p className="text-lg text-gray-600">
            We're committed to providing the most reliable and secure LLC formation service
          </p>
        </div>

        {/* Trust indicators grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {trustIndicators.map((indicator, index) => {
            const Icon = indicator.icon;
            return (
              <Card key={index} className="text-center hover:shadow-lg transition-all duration-300" padding="md">
                <div className={`w-12 h-12 ${indicator.bgColor} rounded-full flex items-center justify-center mx-auto mb-3`}>
                  <Icon className={`h-6 w-6 ${indicator.color}`} />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2 text-sm">
                  {indicator.title}
                </h3>
                <p className="text-gray-600 text-xs">
                  {indicator.description}
                </p>
              </Card>
            );
          })}
        </div>

        {/* Certifications and ratings */}
        <div className="bg-gray-50 rounded-xl p-6 mb-12">
          <h3 className="text-xl font-bold text-gray-900 text-center mb-6">
            Certified & Highly Rated
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {certifications.map((cert, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl mb-2">{cert.logo}</div>
                <div className="font-semibold text-gray-900 text-sm">{cert.name}</div>
                <div className="flex items-center justify-center space-x-1 mt-1">
                  <Star className="h-4 w-4 text-yellow-400 fill-current" />
                  <span className="text-xs font-medium text-gray-700">{cert.rating}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Guarantees */}
        <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200" padding="lg">
          <div className="text-center mb-6">
            <h3 className="text-xl font-bold text-gray-900 mb-3">
              Our Ironclad Guarantees
            </h3>
            <p className="text-gray-600 text-sm">
              We stand behind our service with these customer-first guarantees
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {guarantees.map((guarantee, index) => (
              <div key={index} className="flex items-center space-x-2 p-2.5 bg-white rounded-lg shadow-sm">
                <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-gray-700 font-medium text-sm">{guarantee}</span>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-6">
            <div className="inline-flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-full font-semibold text-sm">
              <Shield className="h-5 w-5" />
              <span>30-Day Money-Back Guarantee</span>
            </div>
          </div>
        </Card>

        {/* Security badges */}
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4 text-sm">Your information is protected by:</p>
          <div className="flex justify-center items-center space-x-6 text-gray-400">
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5" />
              <span className="font-medium text-sm">256-bit SSL</span>
            </div>
            <div className="flex items-center space-x-2">
              <Award className="h-5 w-5" />
              <span className="font-medium text-sm">SOC 2 Compliant</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5" />
              <span className="font-medium text-sm">GDPR Compliant</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};