import React, { useEffect, useState } from 'react';
import { Card } from '../ui/Card';
import { supabase } from '../../lib/supabase';
import { State } from '../../types';

export const StatesSection: React.FC = () => {
  const [states, setStates] = useState<State[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStates = async () => {
      try {
        const { data, error } = await supabase
          .from('states')
          .select('*')
          .eq('is_active', true)
          .order('name', { ascending: true });

        if (error) throw error;
        setStates(data || []);
      } catch (error) {
        console.error('Error fetching states:', error);
        // Fallback states if DB query fails
        setStates([
          { id: '1', name: 'Delaware', code: 'DE', filing_fee: 90, turnaround_time: '1-2 business days', monthly_price: 49, yearly_price: 499, one_time_price: 49, is_active: true },
          { id: '2', name: 'Nevada', code: 'NV', filing_fee: 75, turnaround_time: '1-3 business days', monthly_price: 49, yearly_price: 499, one_time_price: 49, is_active: true },
          { id: '3', name: 'Wyoming', code: 'WY', filing_fee: 100, turnaround_time: '1-2 business days', monthly_price: 49, yearly_price: 499, one_time_price: 49, is_active: true },
          { id: '4', name: 'Texas', code: 'TX', filing_fee: 300, turnaround_time: '2-3 business days', monthly_price: 49, yearly_price: 499, one_time_price: 49, is_active: true },
          { id: '5', name: 'California', code: 'CA', filing_fee: 70, turnaround_time: '3-5 business days', monthly_price: 49, yearly_price: 499, one_time_price: 49, is_active: true },
          { id: '6', name: 'Florida', code: 'FL', filing_fee: 125, turnaround_time: '2-3 business days', monthly_price: 49, yearly_price: 499, one_time_price: 49, is_active: true },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchStates();
  }, []);

  if (loading) {
    return (
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-1/3 mx-auto mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="states" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            File in Any State
          </h2>
          <p className="text-xl text-gray-600">
            We handle LLC formation in all 50 states with competitive pricing
          </p>
        </div>

        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-4 px-6 font-semibold text-gray-900">
                    State
                  </th>
                  <th className="text-center py-4 px-6 font-semibold text-gray-900">
                    State Filing Fee
                  </th>
                  <th className="text-center py-4 px-6 font-semibold text-gray-900">
                    Our Service Fee
                  </th>
                  <th className="text-center py-4 px-6 font-semibold text-gray-900">
                    Turnaround Time
                  </th>
                </tr>
              </thead>
              <tbody>
                {states.slice(0, 10).map((state) => (
                  <tr key={state.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-4 px-6 font-medium text-gray-900">
                      {state.name}
                    </td>
                    <td className="text-center py-4 px-6 text-gray-700">
                      ${state.filing_fee}
                    </td>
                    <td className="text-center py-4 px-6 text-gray-700">
                      ${state.one_time_price}
                    </td>
                    <td className="text-center py-4 px-6 text-gray-700">
                      {state.turnaround_time}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {states.length > 10 && (
            <div className="text-center py-6 border-t border-gray-200">
              <p className="text-gray-600">
                And {states.length - 10} more states available
              </p>
            </div>
          )}
        </Card>
      </div>
    </section>
  );
};