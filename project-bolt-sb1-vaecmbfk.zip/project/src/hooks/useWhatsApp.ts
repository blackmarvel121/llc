import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

interface WhatsAppSettings {
  enabled: boolean;
  number: string;
  message: string;
}

interface WhatsAppSettings {
  enabled: boolean;
  number: string;
  message: string;
}

export const useWhatsApp = () => {
  const [settings, setSettings] = useState<WhatsAppSettings>({
    enabled: false,
    number: '',
    message: 'Hi! I need help with LLC formation.'
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWhatsAppSettings = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('settings')
          .select('whatsapp_enabled, whatsapp_number, whatsapp_message')
          .eq('key', 'global')
          .single();

        if (error) {
          console.error('Error fetching WhatsApp settings:', error);
          return;
        }
        
        if (data && data.whatsapp_enabled !== null) {
          setSettings({
            enabled: data.whatsapp_enabled === true,
            number: data.whatsapp_number || '',
            message: data.whatsapp_message || 'Hi! I need help with LLC formation.'
          });
        }
      } catch (error) {
        // Fallback settings if DB query fails
        console.error('Error in useWhatsApp hook:', error);
        setSettings({
          enabled: false,
          number: '+1234567890',
          message: 'Hi! I need help with LLC formation.'
        });
      } finally {
        setLoading(false);
      }
    };

    fetchWhatsAppSettings();
  }, []);

  const openWhatsApp = (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    
    if (!settings.enabled || !settings.number || settings.number.trim() === '') {
      // Fallback to a default action if WhatsApp is not configured
      alert('Please contact us for more information!');
      return;
    }

    const encodedMessage = encodeURIComponent(settings.message);
    const whatsappUrl = `https://wa.me/${settings.number.replace(/\D/g, '')}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  return {
    settings,
    openWhatsApp,
    isEnabled: settings.enabled && !!settings.number && settings.number.trim() !== '',
    loading
  };
};