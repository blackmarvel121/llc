/*
  # Create Sample Documents for Testing

  1. New Data
    - Sample documents for testing the documents feature
    - Linked to existing users and orders
    - Different document types for comprehensive testing

  2. Security
    - Maintains existing RLS policies
*/

-- Insert sample documents for testing
-- These will be visible in the documents section of the dashboard
INSERT INTO documents (user_id, order_id, name, type, file_url, uploaded_at)
SELECT 
  orders.user_id,
  orders.id,
  'Articles of Organization',
  'articles',
  'https://www.pdffiller.com/preview/100/58/100058738/large.png',
  orders.created_at + interval '1 day'
FROM orders
WHERE NOT EXISTS (
  SELECT 1 FROM documents 
  WHERE documents.order_id = orders.id 
  AND documents.type = 'articles'
)
LIMIT 5;

INSERT INTO documents (user_id, order_id, name, type, file_url, uploaded_at)
SELECT 
  orders.user_id,
  orders.id,
  'EIN Confirmation Letter',
  'ein',
  'https://www.pdffiller.com/preview/542/395/542395094/large.png',
  orders.created_at + interval '2 days'
FROM orders
WHERE NOT EXISTS (
  SELECT 1 FROM documents 
  WHERE documents.order_id = orders.id 
  AND documents.type = 'ein'
)
LIMIT 5;

INSERT INTO documents (user_id, order_id, name, type, file_url, uploaded_at)
SELECT 
  orders.user_id,
  orders.id,
  'Operating Agreement',
  'operating_agreement',
  'https://www.pdffiller.com/preview/100/56/100056098/large.png',
  orders.created_at + interval '3 days'
FROM orders
WHERE NOT EXISTS (
  SELECT 1 FROM documents 
  WHERE documents.order_id = orders.id 
  AND documents.type = 'operating_agreement'
)
LIMIT 5;

-- Update some orders to completed status to show document availability
UPDATE orders
SET status = 'completed'
WHERE id IN (
  SELECT id FROM orders LIMIT 3
);