/*
  # Fix Payment Gateway Integration

  1. Changes
    - Enable all payment gateways by default for testing
    - Set default public and secret keys for testing
    - Ensure proper indexes and constraints
    
  2. Security
    - Maintains existing RLS policies
*/

-- Update all payment gateways to be enabled for testing
UPDATE payment_gateways
SET enabled = true
WHERE type IN ('stripe', 'razorpay', 'paypal');

-- Set default test keys for each gateway
UPDATE payment_gateways
SET public_key = 'pk_test_sample_key',
    secret_key = 'sk_test_sample_key'
WHERE type = 'stripe';

UPDATE payment_gateways
SET public_key = 'rzp_test_sample_key',
    secret_key = 'rzp_test_sample_secret'
WHERE type = 'razorpay';

UPDATE payment_gateways
SET public_key = 'test_client_id',
    secret_key = 'test_client_secret'
WHERE type = 'paypal';

-- Make sure all gateways have proper settings
UPDATE payment_gateways
SET settings = jsonb_build_object(
  'currency', CASE WHEN type = 'razorpay' THEN 'INR' ELSE 'USD' END,
  'description', 'LLC Formation Services',
  'mode', 'sandbox'
)
WHERE settings IS NULL OR settings = '{}'::jsonb;

-- Add indexes for better performance if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'payment_gateways_type_idx'
  ) THEN
    CREATE INDEX payment_gateways_type_idx ON payment_gateways(type);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE indexname = 'payment_gateways_enabled_idx'
  ) THEN
    CREATE INDEX payment_gateways_enabled_idx ON payment_gateways(enabled);
  END IF;
END $$;